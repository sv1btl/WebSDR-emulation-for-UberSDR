// ubersdr-compat.js — lets the RW3PS WebSDR layout run on UberSDR.
// SV1BTL WebSDR layout for UberSDR (websdr_sv1btl), version 5.5.0 (2026-11-04) — the version of
// this layout, not of UberSDR.
//
// The RW3PS websdr-base.js was written for PA3FWM's original sound client (with
// KA7OEI's DSP additions). UberSDR replaces that client with its own Opus player
// (websdr-sound.js, served by UberSDR and left untouched here), which only offers
// setparam / setvolume / smeter / getid / mute / destroy. This file adds the rest
// of what the RW3PS page calls, on top of UberSDR's player:
//
//   audioresume()      unlock audio after a click
//   setdelay1(n)       extra audio buffer ("Buffer" selector)
//   setstereo(v)       left / both / right output ("Out" selector)
//   sethboost(on)      +6 dB high-shelf at 1500 Hz ("Hi-Boost")
//   setnoise(level)    noise reduction, using UberSDR's websdr-nr.js engine
//   rec_start() etc.   audio recording to WAV
//   setnotch(n, on)    adaptive notch filters: 1 = "Autonotch", 2 = "Notch-2"
//   setparam2(on)      the RW3PS name for Notch-2
//   setparam('squelch=…')  squelch, done here because UberSDR's server accepts it but
//                      ignores it (Manual AGC / gain= was removed on 2026-09-30)
//
// It also replaces the single "HF" band button (UberSDR serves one 0–30 MHz band)
// with amateur-band shortcuts, and moves UberSDR's credit line to the bottom.
//
// Load order: tmp/bandinfo.js, this file, websdr-base.js, then
// ubersdr_compat_after_base() — see websdr-head.html.

(function () {
  'use strict';

  // ── Where a visitor starts ──────────────────────────────────────────────────
  // A returning visitor starts where they left off: the last frequency, mode and filter
  // are kept in this browser (localStorage 'ubersdr_last', shared by the desktop and the
  // mobile page). A first visit starts on startKHz/startMode from sv1btl/station.js
  // (7120 kHz LSB if not set). A ?tune=… link always wins.
  var STN = window.STATION || {};   // sv1btl/station.js (loaded just before this file)
  var START_KHZ = Number(STN.startKHz) || 7120, START_MODE = String(STN.startMode || 'lsb').toLowerCase();
  var POS_KEY = 'ubersdr_last';

  // Saved position, or null: { nom: kHz as displayed, mode: 'LSB'…, lo, hi }
  window.ubersdr_lastpos = function () {
    try {
      var p = JSON.parse(localStorage.getItem(POS_KEY));
      if (p && p.nom > 0 && p.nom < 30000 && /^(AM|FM|USB|LSB|CW)$/.test(p.mode) &&
          typeof p.lo === 'number' && typeof p.hi === 'number' && p.hi > p.lo) return p;
    } catch (e) {}
    return null;
  };
  var posTimer = null;
  window.ubersdr_savepos = function (nom, mode, lo, hi) {
    clearTimeout(posTimer);                // tuning by drag/wheel changes fast; save when it settles
    posTimer = setTimeout(function () {
      try {
        localStorage.setItem(POS_KEY, JSON.stringify({ nom: Math.round(nom * 100) / 100,
          mode: String(mode).toUpperCase(), lo: lo, hi: hi }));
      } catch (e) {}
    }, 500);
  };

  // Desktop page: tmp/bandinfo.js (loaded just before this file) comes from UberSDR with
  // no initial frequency (ini_freq=-1), so websdr-base.js would start on 15010 kHz.
  var tuneLink = /[?&]tune=/.test(window.location.search);
  var lastPos = tuneLink ? null : window.ubersdr_lastpos();
  if (window.bandinfo && bandinfo[0] && !tuneLink) {
    if (lastPos) {
      window.ini_freq = null;              // restored after start-up, see bodyonload below
      bandinfo[0].vfo = lastPos.nom;
    } else {
      window.ini_freq = START_KHZ;
      window.ini_mode = START_MODE;
      bandinfo[0].vfo = START_KHZ;         // so the first tune is not to 15010 kHz
    }
  }

  // ── Station details from sv1btl/station.js ──────────────────────────────────
  // Fills the page header (location, locator, callsign, e-mail), the "Switch to another
  // WebSDR" buttons and the mobile page title. Runs when the page has been read.
  window.ubersdr_station_fill = function () {
    function each(sel, fn) { var l = document.querySelectorAll(sel); for (var i = 0; i < l.length; i++) fn(l[i]); }
    if (!window.STATION) {       // station.js missing or not valid JavaScript (a typo): say so
      console.error('sv1btl/station.js is missing or has an error; using placeholders');
      each('[data-station="location"]', function (e) {
        var w = document.createElement('div');
        w.style.cssText = 'color:#c00;font-size:13px;font-weight:bold;';
        w.textContent = 'Station settings not loaded: sv1btl/station.js is missing or has a typo ' +
                        '(check quotes and commas; the browser console, F12, shows the line).';
        e.parentNode.parentNode.insertBefore(w, e.parentNode.nextSibling);
      });
    }
    function txt(v) { return v === undefined || v === null ? '' : String(v); }
    if (STN.location) each('[data-station="location"]', function (e) { e.textContent = txt(STN.location); });
    if (STN.callsign) each('[data-station="callsign"]', function (e) { e.textContent = txt(STN.callsign); });
    if (STN.locator) each('[data-station="locator"]', function (e) {
      e.textContent = txt(STN.locator);
      e.href = 'http://k7fry.com/grid/?qth=' + encodeURIComponent(txt(STN.locator));
    });
    if (STN.email) each('[data-station="email"]', function (e) {
      e.textContent = txt(STN.email);
      e.href = 'mailto:' + txt(STN.email) + '?subject=' + encodeURIComponent(txt(STN.callsign || '') + ' WebSDR');
    });
    var t = document.getElementById('otherwebsdrs');
    if (t) {
      var list = STN.otherWebSDRs || [], labels = ['Switch to', 'another', 'WebSDR'], per = 6;
      t.innerHTML = '';
      for (var r = 0; r * per < list.length; r++) {
        var tr = document.createElement('tr');
        tr.style.fontSize = '13px';
        var th = document.createElement('td');
        th.innerHTML = labels[r] ? '<b><em>' + labels[r] + '</em></b>' : '';
        tr.appendChild(th);
        for (var k = r * per; k < Math.min(list.length, (r + 1) * per); k++) {
          var td = document.createElement('td'), a = document.createElement('a');
          a.href = txt(list[k][1]); a.target = '_blank'; a.className = 'btnNorm';
          a.textContent = ' ' + txt(list[k][0]) + ' ';
          td.appendChild(a); tr.appendChild(td);
        }
        t.appendChild(tr);
      }
    }
    if (!document.getElementById('wfmode') && STN.mobileTitle) document.title = txt(STN.mobileTitle);
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', window.ubersdr_station_fill);
  else window.ubersdr_station_fill();

  // ── Listener location in the users list (as on the RW3PS WebSDR) ─────────────
  // Each visitor's browser looks up its own country and city once a day and adds them
  // to the name it sends, so the users list reads e.g. "SV1ABC GR,Athens 7100.00", or
  // "GR,Athens 7100.00" for someone who has not typed a name. The name field and its
  // cookie are left alone. UberSDR's own GeoIP database is internal-only (no lookup the
  // page can call), so this uses a public HTTPS service; if both fail, no location is
  // shown — nothing else changes. Set GEO_SHOW_CITY = false to show the country only.
  var GEO_SHOW_CITY = STN.showListenerCity !== false, GEO_KEY = 'ubersdr_geo', GEO_MAX_AGE_MS = 24 * 3600 * 1000;
  var GEO_SERVICES = ['https://get.geojs.io/v1/ip/geo.json', 'https://ipwho.is/'];
  var geoTag = null;
  function geoMake(cc, city) {
    if (!/^[A-Z]{2}$/.test(cc || '')) return null;
    city = String(city || '').replace(/[^\w .\-\u00c0-\u024f\u0370-\u03ff]/g, '').trim().slice(0, 12);
    return GEO_SHOW_CITY && city ? cc + ',' + city : cc;
  }
  function geoResend() {
    // send the name again so the users list shows the location without waiting for a retune
    try { if (window.soundapplet && typeof window.send_soundsettings_to_server === 'function') send_soundsettings_to_server(); } catch (e) {}
  }
  (function geoLookup() {
    try {
      var c = JSON.parse(localStorage.getItem(GEO_KEY));
      if (c && Date.now() - c.t < GEO_MAX_AGE_MS) { geoTag = geoMake(c.cc, c.city); return; }
    } catch (e) {}
    function tryService(i) {
      if (i >= GEO_SERVICES.length) return;
      var xhr = new XMLHttpRequest();
      xhr.timeout = 5000;
      xhr.onload = function () {
        var d = null;
        try { d = JSON.parse(xhr.responseText); } catch (e) {}
        var tag = d && geoMake(d.country_code, d.city);
        if (!tag) { tryService(i + 1); return; }
        geoTag = tag;
        try { localStorage.setItem(GEO_KEY, JSON.stringify({ cc: d.country_code, city: d.city || '', t: Date.now() })); } catch (e) {}
        geoResend();
      };
      xhr.onerror = xhr.ontimeout = function () { tryService(i + 1); };
      xhr.open('GET', GEO_SERVICES[i], true);
      xhr.send(null);
    }
    tryService(0);
  })();
  // "SV1ABC 7100.00" → "SV1ABC GR,Athens 7100.00 LSB"; " 7100.00" → "GR,Athens 7100.00 LSB";
  // "mobile/Android" → "mobile/Android GR,Athens LSB". The mode at the end lets other
  // listeners' pages switch to it when they click this name (ubersdr_gotouser); the
  // server itself sends only the name and the position. UberSDR keeps 31 characters:
  // the city goes first, then the country, when the name is too long.
  var NAME_MODES = /\s(CW|LSB|USB|AM|FM)$/;
  function nameWithGeo(qs) {
    return qs.replace(/((?:^|&)name=)([^&]*)/, function (all, key, val) {
      var v; try { v = decodeURIComponent(val); } catch (e) { return all; }
      v = v.replace(NAME_MODES, '');
      var m = /^(.*?)(\s+\d+\.\d{2})?$/.exec(v), base = m[1].trim(), f = m[2] || '';
      if (geoTag) base = base.replace(geoTag, '').trim();
      var md = /^(CW|LSB|USB|AM|FM)$/.test(window.mode) ? ' ' + window.mode : '';
      function build(tag) { return [base, tag].filter(Boolean).join(' ') + f + md; }
      var out = build(geoTag || '');
      if (out.length > 31 && geoTag) out = build(geoTag.split(',')[0]);   // drop the city
      if (out.length > 31) out = build('');                               // drop the country
      if (out.length > 31) out = out.slice(0, 31);
      return key + encodeURIComponent(out);
    });
  }

  // ── Optional on-page error display: add ?ubersdr_debug to the URL ───────────
  if (/[?&]ubersdr_debug/.test(window.location.search)) {
    window.addEventListener('error', function (e) {
      var d = document.getElementById('ubersdr-debug');
      if (!d) {
        d = document.createElement('div');
        d.id = 'ubersdr-debug';
        d.style.cssText = 'position:fixed;bottom:0;left:0;right:0;max-height:40%;overflow:auto;' +
          'background:#300;color:#fff;font:12px monospace;padding:6px;z-index:100000;white-space:pre-wrap';
        (document.body || document.documentElement).appendChild(d);
      }
      d.textContent += (e.filename || '').replace(/^.*\//, '') + ':' + e.lineno + '  ' + e.message + '\n';
    });
  }

  // Buffer selector values from websdr-controls.html → scheduling lead in seconds.
  // UberSDR's player drops packets queued more than 1.5 s ahead, so 1.25 s is the top.
  var LEAD_FOR_DELAY = { 1000: 0.125, 2000: 0.25, 4000: 0.5, 8000: 1.0, 16000: 1.25 };

  // NR levels from the "DSP Noise Reduction" selector → websdr-nr peak-detection strength
  var NR_MULT = { 1: 0.1, 2: 0.3, 3: 0.5, 4: 0.8 };
  // …and how far noise is turned down (residual floor; the engine used to set it to
  // exact zero, which chopped weak speech and pauses into silence): -9/-14/-18/-23 dB
  var NR_FLOOR = { 1: 0.35, 2: 0.2, 3: 0.12, 4: 0.07 };

  // Settings survive a sound restart (the player is recreated on reconnect)
  var state = { lead: 0.125, stereo: -1, hboost: false, nr: 0, notch1: false, notch2: false,
                squelch: false, agcBoost: true };
  try { if (localStorage.getItem('ubersdr_agcboost') === '0') state.agcBoost = false; } catch (e) {}

  // ── Squelch ─────────────────────────────────────────────────────────────────
  // UberSDR's server stores squelch= but never applies it: its audio always comes
  // through radiod's AGC. Each audio packet does carry radiod's measurements from before
  // the AGC — the power in the passband (dB) and the noise density (dB/Hz) — and those
  // are enough to do it here:
  //  • Squelch: open while the (smoothed) passband power is SQL_OPEN_DB above the noise
  //    in the same bandwidth (radiod's noise density × filter width); stay open
  //    SQL_HANG_S after the signal drops.
  // Calibrated on this receiver (29 Sep 2026): ERT 729 kHz read +30…37 dB SNR; empty or
  // quiet bands mostly below +6 dB.
  var SQL_OPEN_DB = 8, SQL_CLOSE_DB = 4, SQL_HANG_S = 0.6;   // band noise reached +6 dB on 40m
  // Soft limiter on the output: peaks held to about -3 dBFS, 20 dB/s recovery, soft clip
  // above 80 % of full scale.
  var LIM_CEIL = 0.7, LIM_RELEASE_DBS = 20, LIM_KNEE = 0.8;

  // chans = decoded.channelData. UberSDR's decoder delivers two identical channels; the
  // level is measured on the first and the same gain is applied to every channel (only
  // the first used to be changed, so squelch left the right channel playing).
  // Weak-signal AGC (2026-09-30; on by default, off with its switch). UberSDR's own AGC keeps the band noise at about -35 dBFS and lets signals come
  // out in proportion to their strength (a strong SSB station ~ -20 dBFS), so a weak
  // station stays quiet. This raises a weak signal towards WAGC_TARGET_DB.
  // Since 2026-10-12 it follows PhantomSDR-Plus's server "Auto" AGC
  // (src/utils/audioprocessing.cpp, AGC(0.1, 100, 30, 100) + configureForSSB/AM):
  //   - the level is the PEAK of the last 100 ms (PhantomSDR's 100 ms window), not RMS;
  //   - attack ~3 ms: the gain drops at once when the peak rises (the limiter catches
  //     the packet that carries it, PhantomSDR's look-ahead does that job there);
  //   - hang only after a sudden jump (wanted gain < 0.15 x present gain, -16.5 dB):
  //     0.4 s in SSB/CW, 1 s in AM;
  //   - release: the gain climbs back exponentially (in linear gain, so a dip after a
  //     crash recovers mostly within ~1 s), time constant 0.75 s SSB/CW, 1 s AM
  //     (30 ms x 5 stretch / 0.20, resp. / 0.15);
  //   - at most +20 dB (PhantomSDR's max_gain 1000 x 0.01).
  // Kept from before (UberSDR's server AGC runs underneath, so this stage only adds):
  //   - up to WAGC_MAX_DB while a signal stands WAGC_SNR_HI dB over the noise (held
  //     4 s, then falls 5 dB/s), at most WAGC_NOISE_MAX_DB on an empty channel (band
  //     hiss stays about where it was);
  //   - it only adds gain: strong signals are left alone (the limiter guards the peaks).
  var WAGC_TARGET_DB = -9;   // peak dBFS; about the old -20 dBFS RMS on speech
  var WAGC_MAX_DB = 20, WAGC_NOISE_MAX_DB = 3, WAGC_SNR_LO = 2, WAGC_SNR_HI = 6;
  var WAGC_PEAK_WIN_S = 0.1, WAGC_HANG_THRESH = 0.15;
  var WAGC_PROFILE = { ssb: { hang: 0.4, rel: 0.75 }, am: { hang: 1.0, rel: 1.0 } };
  var WAGC_SIG_HOLD_S = 4, WAGC_SIG_FALL_DBS = 5, WAGC_SIG_RISE_DBS = 20;
  function weakAgcGain(st, peak, snr, dt) {
    var now = Date.now();
    if (st.agcF !== window.freq) {   // retuned: start afresh
      st.agcF = window.freq; st.sigDb = undefined; st.pk = []; st.agcG = undefined; st.hangUntil = 0;
    }
    // peak of the last 100 ms
    st.pk.push({ t: now, v: peak });
    while (st.pk.length > 1 && now - st.pk[0].t > WAGC_PEAK_WIN_S * 1000) st.pk.shift();
    var pk = 0;
    for (var i = 0; i < st.pk.length; i++) if (st.pk[i].v > pk) pk = st.pk[i].v;
    // how much boost a signal this far over the noise may get
    // rises at most WAGC_SIG_RISE_DBS: a short crash must not open the full boost for
    // the next 4 s (the band hiss came up after one); a real station gets there in ~0.3 s
    if (st.sigDb === undefined) { st.sigDb = Math.min(snr, WAGC_SNR_LO); st.sigT = now; }
    else if (snr >= st.sigDb) { st.sigDb = Math.min(snr, st.sigDb + WAGC_SIG_RISE_DBS * dt); st.sigT = now; }
    else if (now - st.sigT > WAGC_SIG_HOLD_S * 1000) st.sigDb = Math.max(snr, st.sigDb - WAGC_SIG_FALL_DBS * dt);
    var k = Math.max(0, Math.min(1, (st.sigDb - WAGC_SNR_LO) / (WAGC_SNR_HI - WAGC_SNR_LO)));
    var maxDb = WAGC_NOISE_MAX_DB + (WAGC_MAX_DB - WAGC_NOISE_MAX_DB) * k;
    var pkDb = 20 * Math.log(pk + 1e-12) / Math.LN10;
    var want = Math.pow(10, Math.max(0, Math.min(maxDb, WAGC_TARGET_DB - pkDb)) / 20);
    var prof = /^(AM|SAM)/i.test(String(window.mode || '')) ? WAGC_PROFILE.am : WAGC_PROFILE.ssb;
    var g = st.agcG === undefined ? want : st.agcG;
    if (want < g) {                                   // attack: at once
      if (want < g * WAGC_HANG_THRESH) st.hangUntil = now + prof.hang * 1000;
      g = want;
    } else if (now >= st.hangUntil) {                 // release, after any hang
      g += (want - g) * (1 - Math.exp(-dt / prof.rel));
    }
    st.agcG = g;
    st.boostDb = 20 * Math.log(g) / Math.LN10;
    return g;
  }

  function levelProcess(sa, chans) {
    var x = chans[0];
    var st = sa._lvl || (sa._lvl = { rms: 0, g: 1, lim: 1, sqlOpen: false, sqlUntil: 0, sqlGain: 1, bbS: null, f: null });
    var n = x.length, sum = 0, i;
    for (i = 0; i < n; i++) sum += x[i] * x[i];
    var rms = Math.sqrt(sum / Math.max(1, n));
    st.rms = st.rms ? 0.8 * st.rms + 0.2 * rms : rms;           // ~100 ms average
    var bb = sa._basebandPower, nd = sa._noiseDensity;
    var bwHz = Math.max(100, Math.abs((window.hi || 1) - (window.lo || 0)) * 1000);
    var noiseDb = nd + 10 * Math.log(bwHz) / Math.LN10;
    // Squelch: passband power smoothed over ~60 ms (restarts on retune) against the noise
    if (st.f !== window.freq || st.bbS === null) { st.f = window.freq; st.bbS = bb; }
    st.bbS = 0.7 * st.bbS + 0.3 * bb;
    var snr = st.bbS - noiseDb;
    window.ubersdr_level = { bb: bb, noiseDb: noiseDb, snr: snr, rmsDb: 20 * Math.log(st.rms + 1e-12) / Math.LN10 };

    var peak = 0;
    for (i = 0; i < n; i++) { var a = x[i] < 0 ? -x[i] : x[i]; if (a > peak) peak = a; }
    // Weak-signal AGC
    var g = 1;
    if (state.agcBoost && bb > -998 && nd > -998) {
      g = weakAgcGain(st, peak, snr, n / (sa._decoderSR || 12000));
    } else { st.boostDb = 0; st.agcG = undefined; }
    // Squelch
    var sq = 1;
    if (state.squelch && bb > -998 && nd > -998) {
      var now = Date.now();
      if (snr >= SQL_OPEN_DB) { st.sqlOpen = true; st.sqlUntil = now + SQL_HANG_S * 1000; }
      else if (snr < SQL_CLOSE_DB && now > st.sqlUntil) st.sqlOpen = false;
      sq = st.sqlOpen ? 1 : 0;
    }
    // Soft limiter. With AGC off a strong station can come out far above full scale.
    // 1) Gain reduction: if this packet's peak would exceed LIM_CEIL, reduce at once;
    //    recover at LIM_RELEASE_DBS. 2) Soft clip: anything still above LIM_KNEE (fast
    //    peaks inside a packet) is bent smoothly towards full scale instead of cut off.
    var want = peak * g * sq > LIM_CEIL ? LIM_CEIL / (peak * g * sq) : 1;
    var rel = Math.pow(10, LIM_RELEASE_DBS * (n / (sa._decoderSR || 12000)) / 20);
    st.lim = want < st.lim ? want : Math.min(want, st.lim * rel);
    // Ramp gain changes across the packet so there are no clicks; every channel alike
    var g0 = st.g * st.sqlGain * st.limPrev, g1 = g * sq * st.lim, osum = 0, opeak = 0;
    if (!(g0 === g0)) g0 = g1;                                // first packet
    // limiter attack: when the limiter turns the gain down, do it at once (a ramp from the
    // previous, higher gain let the start of loud packets overshoot); ramp only upwards
    if (st.lim < st.limPrev && g1 < g0) g0 = g1;
    if (g < st.g && g1 < g0) g0 = g1;                     // AGC attack: at once too (~3 ms in PhantomSDR-Plus)
    for (var ch = 0; ch < chans.length; ch++) {
      var y = chans[ch], m = y.length;
      for (i = 0; i < m; i++) {
        var v = y[i] * (g0 + (g1 - g0) * (i + 1) / m), av = v < 0 ? -v : v;
        if (av > LIM_KNEE) {
          av = LIM_KNEE + (1 - LIM_KNEE) * Math.tanh((av - LIM_KNEE) / (1 - LIM_KNEE));
          v = v < 0 ? -av : av;
        }
        y[i] = v;
        if (ch === 0) { osum += v * v; if (av > opeak) opeak = av; }
      }
    }
    st.g = g; st.sqlGain = sq; st.limPrev = st.lim;
    window.ubersdr_level.outDb = 10 * Math.log(osum / Math.max(1, n) + 1e-24) / Math.LN10;
    window.ubersdr_level.sqlOpen = st.sqlOpen;
    window.ubersdr_level.outPeakDb = 20 * Math.log(opeak + 1e-12) / Math.LN10;
    window.ubersdr_level.limDb = 20 * Math.log(st.lim) / Math.LN10;
    window.ubersdr_level.boostDb = st.boostDb || 0;
  }


  // Switch for the weak-signal AGC (both pages); the choice is kept in this browser
  // (not with nostore: Receive Diversity turns it off for its run only)
  window.ubersdr_agcboost = function (on, nostore) {
    state.agcBoost = !!on;
    var cb = document.getElementById('agcboostcheckbox');
    if (cb) cb.checked = !!on;
    if (nostore) return;
    try { localStorage.setItem('ubersdr_agcboost', on ? '1' : '0'); } catch (e) {}
  };
  window.addEventListener('DOMContentLoaded', function () {
    var cb = document.getElementById('agcboostcheckbox');
    if (cb) cb.checked = state.agcBoost;
  });

  // ── Adaptive notch (normalised LMS) ─────────────────────────────────────────
  // UberSDR's server has no autonotch, so it runs here, in the browser, as it did in
  // KA7OEI's sound client for the original WebSDR. The filter predicts the input from
  // samples `delay` steps back: a steady tone (carrier, whistle) is predictable and
  // gets cancelled, while speech and noise are not and pass through.
  //   Autonotch: 64 taps, 16-sample delay, fast adaptation — catches a whistle in ~0.1 s
  //   Notch-2:  121 taps, 48-sample delay, slower and deeper (KA7OEI's settings)
  // Measured on noise + two tones: -32/-22 dB and -38/-29 dB on the tones; noise
  // level unchanged (±0.1 dB). Note it also removes a CW tone you are listening to.
  var NOTCH_SETTINGS = {
    1: { taps: 64, delay: 16, mu: 0.05, leak: 0.9999 },
    2: { taps: 121, delay: 48, mu: 0.01, leak: 0.99999 }
  };

  function LmsNotch(o) {
    this.taps = o.taps; this.delay = o.delay; this.mu = o.mu; this.leak = o.leak;
    this.n = o.taps + o.delay + 1;
    this.buf = new Float32Array(this.n);     // past input samples, ring buffer
    this.w = new Float32Array(o.taps);       // filter weights
    this.pos = 0;
    this.pow = 0;                            // sum of squares over the filter's input window
  }
  LmsNotch.prototype.process = function (x, out) {
    var n = this.n, taps = this.taps, d = this.delay, buf = this.buf, w = this.w;
    var mu = this.mu, leak = this.leak, pos = this.pos, pw = this.pow;
    for (var i = 0; i < x.length; i++) {
      var s = x[i], y = 0, k, j;
      j = pos - d; if (j < 0) j += n;
      for (k = 0; k < taps; k++) { y += w[k] * buf[j]; if (--j < 0) j = n - 1; }
      var e = s - y;                         // input minus its predictable (tonal) part
      var g = mu * e / (pw + 1e-6);
      j = pos - d; if (j < 0) j += n;
      for (k = 0; k < taps; k++) { w[k] = leak * w[k] + g * buf[j]; if (--j < 0) j = n - 1; }
      if (++pos >= n) pos = 0;
      buf[pos] = s;
      var jin = pos - d; if (jin < 0) jin += n;
      var jout = jin - taps; if (jout < 0) jout += n;
      pw += buf[jin] * buf[jin] - buf[jout] * buf[jout];
      if (pw < 0) pw = 0;
      out[i] = (e === e) ? e : 0;            // NaN guard
    }
    this.pos = pos; this.pow = pw;
  };


  // ── Audio graph ─────────────────────────────────────────────────────────────
  // UberSDR:  sources → gain → destination
  // here:     sources → gain → [NR] → high-shelf → L/R gains → merger → destination

  function buildChain(sa) {
    var ctx = sa._audioCtx;
    var c = {
      ctx: ctx,
      shelf: ctx.createBiquadFilter(),
      splitter: ctx.createChannelSplitter(2),
      gainL: ctx.createGain(),
      gainR: ctx.createGain(),
      merger: ctx.createChannelMerger(2),
      nr: null
    };
    c.shelf.type = 'highshelf';
    c.shelf.frequency.value = 1500;
    c.shelf.connect(c.splitter);
    c.splitter.connect(c.gainL, 0);
    c.splitter.connect(c.gainR, 1);
    c.gainL.connect(c.merger, 0, 0);
    c.gainR.connect(c.merger, 0, 1);
    c.merger.connect(ctx.destination);
    sa._compat = c;
    applySettings(sa);
  }

  function applySettings(sa) {
    var c = sa._compat;
    if (!c || !sa._gainNode) return;
    c.shelf.gain.value = state.hboost ? 6 : 0;
    c.gainL.gain.value = (state.stereo == 1) ? 0 : 1;              // 1 = right only
    c.gainR.gain.value = (state.stereo == -1 || state.stereo == 1) ? 1 : 0;  // -1 = both, 0 = left only

    var wantNR = state.nr > 0 && window.websdrNR;
    try { sa._gainNode.disconnect(); } catch (e) {}
    if (c.nr) { try { c.nr.disconnect(); } catch (e) {} c.nr = null; }
    if (c.anf) { try { c.anf.disconnect(); } catch (e) {} c.anf = null; }

    // gain → [notch] → [NR] → high-shelf …
    var head = sa._gainNode;
    if (state.notch1 || state.notch2) {
      // The filters keep their state (weights) while the page runs, so switching one
      // back on does not have to adapt from scratch.
      if (!c.notch1) c.notch1 = new LmsNotch(NOTCH_SETTINGS[1]);
      if (!c.notch2) c.notch2 = new LmsNotch(NOTCH_SETTINGS[2]);
      var tmp = new Float32Array(512);
      c.anf = c.ctx.createScriptProcessor(512, 1, 2);    // 512 samples: ~43 ms at 12 kHz
      c.anf.onaudioprocess = function (e) {
        var x = e.inputBuffer.getChannelData(0), out = e.outputBuffer.getChannelData(0);
        if (tmp.length !== x.length) tmp = new Float32Array(x.length);
        var src = x;
        if (state.notch1) { c.notch1.process(src, tmp); src = tmp; }
        if (state.notch2) { c.notch2.process(src, out); src = out; }
        if (src !== out) out.set(src);
        e.outputBuffer.getChannelData(1).set(out);
      };
      head.connect(c.anf);
      head = c.anf;
    }
    if (wantNR) {
      window.websdrNR.reset();
      window.websdrNR.setEnabled(true);
      window.websdrNR.setSquelch(false);
      window.websdrNR.setMult(NR_MULT[state.nr] || 0.3);
      if (window.websdrNR.setFloor) window.websdrNR.setFloor(NR_FLOOR[state.nr] || 0.2);
      syncNRBins(sa, true);
      // 4096-sample blocks are what the NR engine is built for (see websdr-nr.js)
      c.nr = c.ctx.createScriptProcessor(4096, 1, 2);
      c.nr.onaudioprocess = function (e) {
        var input = e.inputBuffer.getChannelData(0);
        var out = window.websdrNR.process(input);
        if (out === null) out = input;
        e.outputBuffer.getChannelData(0).set(out);
        e.outputBuffer.getChannelData(1).set(out);
      };
      head.connect(c.nr);
      c.nr.connect(c.shelf);
    } else {
      if (window.websdrNR) window.websdrNR.setEnabled(false);
      head.connect(c.shelf);
    }
  }

  var nrBW = 0;
  function syncNRBins(sa, force) {
    if (!window.websdrNR || !sa._audioCtx || typeof window.lo !== 'number') return;
    var bw = Math.abs(window.hi - window.lo) * 1000;
    if (!force && bw === nrBW) return;
    nrBW = bw;
    window.websdrNR.syncBins(bw, sa._audioCtx.sampleRate);
  }

  var nrLoading = false;
  function loadNR(cb) {
    if (window.websdrNR) { cb(); return; }
    if (nrLoading) return;
    nrLoading = true;
    var s = document.createElement('script');
    s.src = 'sv1btl/websdr-nr.js?v=20260930a';   // our copy, with the residual floor
    s.onload = cb;
    s.onerror = function () { console.error('ubersdr-compat: could not load sv1btl/websdr-nr.js'); };
    document.head.appendChild(s);
  }

  // ── Recording (mono 16-bit, at the stream's sample rate) ────────────────────
  function recPush(sa, decoded) {
    var r = sa._rec;
    var f = decoded.channelData[0];
    var pcm = new Int16Array(f.length);
    for (var i = 0; i < f.length; i++) {
      var v = f[i] * 32767;
      pcm[i] = v > 32767 ? 32767 : (v < -32768 ? -32768 : v);
    }
    r.chunks.push(pcm.buffer);
    r.bytes += pcm.byteLength;
    if (!r.sr) r.sr = sa._decoderSR;
  }

  // ── Methods added to UberSDR's player ───────────────────────────────────────
  // The hooks below rely on internal functions of UberSDR's websdr-sound.js. After an
  // UberSDR update one of them could be renamed: then that hook is skipped (and named in
  // window.ubersdr_compat_missing and the browser console) while the page itself, and
  // plain listening, keep working. sv1btl/../check-after-update.sh tests for them too.
  function patch(proto) {
    if (proto._ubersdrCompat) return;
    proto._ubersdrCompat = true;
    var missing = [];
    function has(name) { if (typeof proto[name] === 'function') return true; missing.push(name); return false; }

    if (has('_onMessage')) {
    var origOnMessage = proto._onMessage;
    proto._onMessage = function (buf) {
      if (buf.byteLength >= 21) this._noiseDensity = new DataView(buf).getFloat32(17, true);
      origOnMessage.call(this, buf);
    };
    }

    if (has('_ensureAudio')) {
    var origEnsureAudio = proto._ensureAudio;
    proto._ensureAudio = function (sampleRate) {
      origEnsureAudio.call(this, sampleRate);
      // UberSDR makes a new AudioContext whenever the stream's sample rate changes
      if (this._audioCtx && (!this._compat || this._compat.ctx !== this._audioCtx)) buildChain(this);
    };
    }

    if (has('_playDecoded')) {
    var origPlay = proto._playDecoded;
    proto._playDecoded = function (decoded) {
      var ctx = this._audioCtx;
      if (ctx && ctx.state === 'running' && this._nextPlayTime < ctx.currentTime) {
        this._nextPlayTime = ctx.currentTime + state.lead;   // refill to the chosen buffer depth
      }
      if (cwd.on && decoded.channelData.length) cwFeed(decoded.channelData[0], this._decoderSR);   // raw audio, as PhantomSDR-Plus
      if (window.ubersdr_dec_tap && decoded.channelData.length) window.ubersdr_dec_tap(decoded.channelData[0], this._decoderSR);   // sv1btl/decoders.js
      // Receive Diversity (sv1btl/diversity-ui.js): the speaker gets the better of this
      // receiver and a second one; the decoders above keep the local audio. UberSDR
      // decodes its mono stream as two identical channels: channel 0 is combined and the
      // result goes to both.
      if (window.ubersdr_div_process && decoded.channelData.length && decoded.channelData.length <= 2) {
        var dvOut = window.ubersdr_div_process(decoded.channelData[0], this._decoderSR);
        if (dvOut && dvOut !== decoded.channelData[0]) {
          decoded.channelData[0] = dvOut;
          if (decoded.channelData.length === 2) decoded.channelData[1] = dvOut;
        }
      }
      if (state.squelch || state.agcBoost || this._lvl) {
        if (decoded.channelData.length) levelProcess(this, decoded.channelData);
        if (!(state.squelch || state.agcBoost)) this._lvl = null;   // all off again
      }
      if (this._rec) recPush(this, decoded);
      if (state.nr > 0) syncNRBins(this, false);
      if (rade.side || xm.kind) return;      // RADE / IQ / DRM on: their own audio plays instead
      origPlay.call(this, decoded);
    };
    }

    if (has('_connect')) {                 // later audio (re)connections: pair the waterfall again
      var origConnect = proto._connect;
      proto._connect = function () { var r = origConnect.apply(this, arguments); wfPair(); return r; };
    }

    proto.audioresume = function () {
      if (this._audioCtx) this._audioCtx.resume().catch(function () {});
      var b = document.getElementById('audiostartbutton');
      if (b) b.style.display = 'none';
    };

    proto.setdelay1 = function (n) {
      state.lead = LEAD_FOR_DELAY[n] || 0.125;
      // Take effect now rather than at the next underrun
      var ctx = this._audioCtx;
      if (ctx && this._nextPlayTime < ctx.currentTime + state.lead) this._nextPlayTime = ctx.currentTime + state.lead;
    };
    proto.setdelay = proto.setdelay1;

    proto.setstereo = function (v) { state.stereo = Number(v); applySettings(this); };
    proto.sethboost = function (on) { state.hboost = !!Number(on); applySettings(this); };

    proto.setnoise = function (level) {
      var self = this;
      state.nr = Number(level) || 0;
      if (state.nr > 0) loadNR(function () { applySettings(window.soundapplet || self); });
      else applySettings(this);
    };

    // squelch= still goes to the server (harmless) but is acted on here
    var origSetparam = has('setparam') ? proto.setparam : function () {};
    proto.setparam = function (qs) {
      var m;
      if ((m = /(?:^|&)squelch=([0-9]+)/.exec(qs))) state.squelch = m[1] !== '0';
      origSetparam.call(this, nameWithGeo(qs));
    };

    proto.setnotch = function (which, on) {
      state['notch' + which] = !!Number(on);
      applySettings(this);
    };
    proto.setparam2 = function (on) { this.setnotch(2, on); };   // RW3PS: Notch-2

    proto.rec_start = function () { this._rec = { chunks: [], bytes: 0, sr: 0 }; };
    proto.rec_length_kB = function () { return this._rec ? this._rec.bytes / 1024 : 0; };
    proto.rec_finish = function () {
      var r = this._rec || { chunks: [], bytes: 0, sr: 0 };
      this._rec = null;
      return { sr: r.sr || this._decoderSR || 12000, len: r.bytes, wavdata: r.chunks };
    };

    window.ubersdr_compat_missing = missing;
    if (missing.length) console.warn('ubersdr-compat: UberSDR sound player lacks ' + missing.join(', ') +
      ' — the related extras (notch, NR, Hi-Boost, L/R, squelch, weak-signal AGC, recording) may not work');
  }

  // ── Keep the waterfall paired with the audio ────────────────────────────────
  // UberSDR names a WebSDR connection "websdr-<second>-<IP>" from the second it arrives
  // in, and pairs the waterfall with the audio by that name. It closes a waterfall that
  // has no audio of the same name after server.spectrum_only_timeout (60 s here), so a
  // page whose audio connected a second later than its waterfall (the audio waits for
  // its Opus library; about 1 visitor in 15) saw waterfall and spectrum freeze after a
  // minute. So: every time the audio connects, the waterfall reconnects in the same
  // instant (its picture, zoom and position stay). Browsers open connections to one
  // server one after the other, so the two still arrive some milliseconds apart; to keep
  // them inside one second, the page first finds where the server's second begins (from
  // the Date header of a few tiny requests) and connects both just after it. At page
  // load nothing is audible yet, so the first audio connection is simply redone. If
  // UberSDR still closes the waterfall, audio and waterfall reconnect together the same
  // way and the tuning is sent again (at most once every 30 s).
  var WF_PAIR_MARGIN_MS = 60;
  function serverSecondEdge(cb) {          // client time (ms) of a server-second boundary, or null
    var lastDate = null, lastMid = 0, t0 = Date.now(), done = false;
    function finish(v) { if (!done) { done = true; cb(v); } }
    function probe() {
      var x = new XMLHttpRequest(), sent = Date.now();
      x.open('GET', '/~~othersjj?chseq=0&t=' + sent, true);
      x.onload = function () {
        var now = Date.now(), mid = (sent + now) / 2, d = x.getResponseHeader('Date');
        if (!d) { finish(null); return; }
        if (lastDate !== null && d !== lastDate) { finish((lastMid + mid) / 2); return; }
        lastDate = d; lastMid = mid;
        if (now - t0 < 2500) setTimeout(probe, 40); else finish(null);
      };
      x.onerror = x.ontimeout = function () { finish(null); };
      x.send(null);
    }
    probe();
  }
  function wfPairAligned(sa, after) {      // reconnect audio + waterfall just after a server-second boundary
    try { if (sa._ws) { sa._ws.onopen = sa._ws.onclose = null; sa._ws.close(); } } catch (e) {}
    serverSecondEdge(function (edge) {
      var wait = 0;
      if (edge !== null) {
        var now = Date.now(), next = edge;
        while (next < now + 20) next += 1000;
        wait = next - now + WF_PAIR_MARGIN_MS;
      }
      setTimeout(function () {
        sa._connect();                     // the _connect wrapper reopens the waterfall in the same instant
        if (after && sa._ws) sa._ws.addEventListener('open', after);
      }, wait);
    });
  }
  // A setting sent while a renewed waterfall connection is still opening threw
  // InvalidStateError and was lost: hold such messages and send them once it is open.
  function wfSafeSend(w) {
    if (w._ubersdrSafeSend || typeof w.e !== 'function') return;
    w._ubersdrSafeSend = true;
    w.e = function (msg) {
      var ws = this.d;
      if (!ws) return;
      if (ws.readyState === 1) { ws.send(msg); return; }
      if (ws.readyState === 0) {
        if (!ws._ubersdrQueue) {
          ws._ubersdrQueue = [];
          ws.addEventListener('open', function () {
            var q = ws._ubersdrQueue; ws._ubersdrQueue = [];
            for (var k = 0; k < q.length; k++) try { ws.send(q[k]); } catch (e) {}
          });
        }
        ws._ubersdrQueue.push(msg);
      }
    };
  }
  function wfPair() {
    var wa = window.waterfallapplet || [];
    for (var i = 0; i < wa.length; i++) {
      var w = wa[i];
      if (w && w.d && typeof w.startstop === 'function') { wfSafeSend(w); w.startstop(0); w.startstop(1); }
    }
  }
  var wfLastRecover = 0;
  setInterval(function () {
    var sa = window.soundapplet, wa = window.waterfallapplet || [], dead = false;
    for (var i = 0; i < wa.length; i++) if (wa[i] && wa[i].d && wa[i].d.readyState === 3) dead = true;   // closed, not stopped by the page
    if (!dead || !sa || typeof sa._connect !== 'function' || Date.now() - wfLastRecover < 30000) return;
    wfLastRecover = Date.now();
    console.log('ubersdr-compat: the waterfall was closed by the server; reconnecting audio and waterfall together');
    wfPairAligned(sa, function () {
      setTimeout(function () {             // the new audio session starts untuned: send the settings again
        try { if (typeof window.send_soundsettings_to_server === 'function') send_soundsettings_to_server(); } catch (e) {}
        sa._connected = true;
      }, 300);
    });
  }, 5000);

  // websdr-base.js declares `var soundapplet`, and UberSDR's websdr-sound.js assigns
  // window.soundapplet. Catching the assignment lets the player be patched before the
  // page calls any of the methods above.
  var current = null;
  Object.defineProperty(window, 'soundapplet', {
    configurable: true,
    get: function () { return current; },
    set: function (v) {
      current = v;
      if (v && typeof v === 'object' && typeof v.getid === 'function') {
        patch(Object.getPrototypeOf(v));
        if (typeof v._connect === 'function') wfPairAligned(v, null);   // redo its first connection, paired
        else wfPair();
      }
    }
  });

  // ── Amateur-band buttons ────────────────────────────────────────────────────
  // [label, lowest kHz, highest kHz, tune kHz, mode]
  var HAM_BANDS = (STN.hamBands && STN.hamBands.length) ? STN.hamBands : [
    ['MW',   531,   1602,   729,    'AM'],
    ['160m', 1810,  2000,   1910,   'LSB'],
    ['80m',  3500,  3800,   3685,   'LSB'],
    ['60m',  5351.5, 5366.5, 5357,  'USB'],
    ['40m',  7000,  7200,   7120,   'LSB'],
    ['30m',  10100, 10150,  10120,  'CW'],
    ['20m',  14000, 14350,  14280,  'USB'],
    ['17m',  18068, 18168,  18130,  'USB'],
    ['15m',  21000, 21450,  21350,  'USB'],
    ['12m',  24890, 24990,  24940,  'USB'],
    ['10m',  28000, 29700,  28585,  'USB']
  ];

  // Which band a frequency (kHz) is in, for setfreqb in websdr-base.js: the amateur band
  // of HAM_BANDS, else the megahertz it falls in (broadcast and other segments)
  window.ubersdr_bandkey = function (f) {
    for (var i = 0; i < HAM_BANDS.length; i++) if (f >= HAM_BANDS[i][1] && f <= HAM_BANDS[i][2]) return 'ham' + i;
    return 'mhz' + Math.floor(f / 1000);
  };

  // The band-plan mode of an amateur band (kHz), else null: used by sv1btl/decoders.js
  window.ubersdr_bandmode = function (f) {
    for (var i = 0; i < HAM_BANDS.length; i++) if (f >= HAM_BANDS[i][1] && f <= HAM_BANDS[i][2]) return String(HAM_BANDS[i][4]).toUpperCase();
    return null;
  };

  // Band memory, as in PhantomSDR-Plus (App.svelte bandMemory): the last frequency
  // tuned in each amateur band, so its button brings you back where you were instead
  // of the band's default. A second click on the button already selected forgets it,
  // and the button tunes to the default (HAM_BANDS). Kept in this browser
  // (localStorage), keyed by label and edges; the displayed frequency (kHz), the mode
  // and the filter (lo/hi) are kept (mode and filter too, unlike PhantomSDR-Plus: 2026-10-21).
  var BAND_MEM_KEY = 'ubersdr_bandmem', bandMem = {}, bandMemTimer = null, bandMemHold = false;
  try { bandMem = JSON.parse(localStorage.getItem(BAND_MEM_KEY) || '{}') || {}; } catch (e) { bandMem = {}; }
  function bandMemKey(hb) { return hb[0] + '|' + hb[1] + '|' + hb[2]; }
  function bandMemSave() {
    clearTimeout(bandMemTimer);
    bandMemTimer = setTimeout(function () {
      try { localStorage.setItem(BAND_MEM_KEY, JSON.stringify(bandMem)); } catch (e) {}
    }, 1000);
  }
  function bandRemember(fk, mo, l, h) {        // called on every retune, mode and filter change (savePos)
    if (bandMemHold || !(fk > 0)) return;      // not halfway through a band button
    for (var i = 0; i < HAM_BANDS.length; i++)
      if (fk >= HAM_BANDS[i][1] && fk <= HAM_BANDS[i][2]) {
        bandMem[bandMemKey(HAM_BANDS[i])] = { f: Math.round(fk * 100) / 100, m: String(mo).toUpperCase(), lo: l, hi: h };
        bandMemSave();
      }
  }
  function bandRemembered(hb) {                // only if it still lies inside the band
    var r = bandMem[bandMemKey(hb)];
    if (typeof r === 'number') r = { f: r, m: null };   // saved before the mode was kept
    return r && typeof r.f === 'number' && r.f >= hb[1] && r.f <= hb[2] ? r : null;
  }

  window.ubersdr_gotoband = function (i) {
    var hb = HAM_BANDS[i];
    var e = bi[band];
    if (hb[3] < e.centerfreq - e.samplerate / 2 || hb[3] > e.centerfreq + e.samplerate / 2) return;
    var btn = document.getElementById('btnHam-' + i);
    if (btn && btn.classList.contains('btn-selected')) {   // second click: back to the band default
      delete bandMem[bandMemKey(hb)];
      try { localStorage.setItem(BAND_MEM_KEY, JSON.stringify(bandMem)); } catch (x) {}
    }
    var mem = bandRemembered(hb);
    // the old band keeps what it had: nothing is recorded until the new band is tuned
    bandMemHold = true;
    try {
      set_mode(hb[4]);
      if (mem !== null) {
        setfreq(mem.f - (iscw() ? (hi + lo) / 2 : 0));   // displayed → carrier (CW), as applyPos
        var memFilt = typeof mem.lo === 'number' && typeof mem.hi === 'number' && mem.hi > mem.lo;
        if ((mem.m && mem.m !== String(window.mode).toUpperCase()) || (memFilt && (mem.lo !== lo || mem.hi !== hi))) {
          // the visitor's own mode and filter: past the band-plan mode that setfreq has just set
          if (window.ubersdr_listener_mode) window.ubersdr_listener_mode();
          if (mem.m) set_mode(mem.m);
          if (mem.m && memFilt) setmf(mem.m.toLowerCase(), mem.lo, mem.hi);   // as applyPos
          setfreq(mem.f - (iscw() ? (hi + lo) / 2 : 0));   // same displayed frequency in that mode/filter
        }
      } else setfreq(hb[3]);
      // Zoom the waterfall to show the whole band (same arithmetic as wfset(3))
      var width = hb[2] - hb[1], z = 0;
      while (2 * width < e.samplerate && z < e.maxzoom) { z++; width *= 2; }
      wfset_freq(band, z, (hb[1] + hb[2]) / 2);
    } finally { bandMemHold = false; }
    if (typeof nominalfreq === 'function') bandRemember(nominalfreq(), window.mode, lo, hi);
    var btns = document.getElementsByClassName('btnBand');
    for (var k = 0; k < btns.length; k++) btns[k].classList.toggle('btn-selected', btns[k].id === 'btnHam-' + i);
  };

  // QSY: the button of the band the frequency is in stays selected (none outside the
  // bands). Only the highlight changes: no zoom, no mode change.
  // Fully zoomed out, "All" is the selected button instead.
  function bandLight() {
    if (typeof nominalfreq !== 'function') return;
    var f = nominalfreq(), idx = -1;
    if (bi[band] && bi[band].zoom === 0) idx = 'all';
    else for (var i = 0; i < HAM_BANDS.length; i++) if (f >= HAM_BANDS[i][1] && f <= HAM_BANDS[i][2]) { idx = i; break; }
    var btns = document.getElementsByClassName('btnBand');
    for (var k = 0; k < btns.length; k++) btns[k].classList.toggle('btn-selected', btns[k].id === 'btnHam-' + idx);
  }

  // ── Chatbox ─────────────────────────────────────────────────────────────────
  // UberSDR's WebSDR server takes a new message as a POST to /~~chat (fields name and
  // text) and gives the messages back from GET /~~chat?chseq=N as
  //   chat_chseq=…; chat_msgs=["…", …];
  // The page script still sends a GET with ?name=&msg= (which the server reads as "list
  // the messages", so the message was lost) and waits for chatnewline() calls in the
  // users-list reply, which UberSDR never sends. Both are done the UberSDR way here; the
  // lines still go through the page's chatnewline(), so its spam filter keeps working.
  // At page load the server's last 20 messages are shown.
  var CHAT_POLL_MS = 3000;
  window.addEventListener('load', function () {
    if (!document.getElementById('chatboxnew') || !document.chatform) return;   // desktop page only
    var chseq = 0, busy = false;
    function poll() {
      if (busy) return;
      busy = true;
      var x = new XMLHttpRequest();
      x.open('GET', '/~~chat?chseq=' + chseq, true);
      x.onloadend = function () {
        busy = false;
        if (x.status !== 200 || !x.responseText) return;
        var r;
        try { r = new Function(x.responseText + '\nreturn [chat_chseq, chat_msgs];')(); } catch (e) { return; }
        if (typeof r[0] === 'number') chseq = r[0];
        var msgs = r[1] || [];
        for (var i = 0; i < msgs.length; i++) {
          var line = String(msgs[i]).replace(/\n+$/, '');
          if (line && typeof window.chatnewline === 'function') window.chatnewline(line);
        }
      };
      x.send(null);
    }
    window.sendchat = function () {
      if (typeof window.timeout_idle_restart === 'function') try { timeout_idle_restart(); } catch (e) {}
      var text = document.chatform.chat.value;
      if (!text.trim()) return false;
      var name = (document.usernameform && document.usernameform.username.value) || '';
      var x = new XMLHttpRequest();
      x.open('POST', '/~~chat', true);
      x.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      x.onloadend = function () { setTimeout(poll, 200); };   // show it at once
      x.send('name=' + encodeURIComponent(name) + '&text=' + encodeURIComponent(text));
      document.chatform.chat.value = '';
      return false;
    };
    poll();
    setInterval(poll, CHAT_POLL_MS);
  });

  // ── RADE V1 (FreeDV) — buttons RADEL / RADEU in the Mode row ────────────────
  // UberSDR decodes RADE on the server: its "freedv" audio extension runs the
  // freedv-ka9q decoder on a listener's audio and sends the decoded voice back as
  // Opus frames over the DX-cluster websocket. It can only be attached to a session
  // of UberSDR's own interface (a UUID session), not to a WebSDR (port 8901) one, so
  // for RADE this page opens such a session on UberSDR's main web server itself:
  //   1. POST /connection  {user_session_id}          (registers the session id)
  //   2. /ws               audio session on the same frequency in USB or LSB,
  //                        muted (the decoder is fed before the mute) and in Opus
  //   3. /ws/dxcluster     "audio_extension_attach" freedv → decoded voice frames:
  //        byte 0 = 0x02, 1-8 timestamp, 9-12 sample rate (BE), 13 channels, 14… Opus
  // While RADE is on, the page's normal WebSDR audio is silenced and the decoded
  // voice plays through the same volume, Hi-Boost, notch and NR chain. Tuning on this
  // page follows; any other mode button, or leaving USB/LSB, switches RADE off.
  // The main server's address: window.UBERSDR_MAIN_URL (set in websdr-head.html),
  // else the same host on port 8080. It needs server.enable_cors: true.
  var RADE_SIG_TIMEOUT_MS = 1500;          // "decoding" shown until frames stop this long
  var rade = { side: null, uuid: null, ws: null, dx: null, dec: null, decSR: 0, decCh: 0,
               next: 0, frames: 0, busy: Promise.resolve(), sigTimer: null, pingTimer: null,
               tuneTimer: null, retryTimer: null, gen: 0, lastErr: '' };

  function radeBase() {
    var u = window.UBERSDR_MAIN_URL || (window.STATION && window.STATION.mainServer) || '';
    if (!u) u = location.protocol + '//' + location.hostname + ':8080';
    return u.replace(/\/+$/, '');
  }
  function radeUUID() {                    // crypto.randomUUID needs https; this does not
    var b = new Uint8Array(16);
    (window.crypto || window.msCrypto).getRandomValues(b);
    b[6] = (b[6] & 0x0f) | 0x40; b[8] = (b[8] & 0x3f) | 0x80;
    var h = [];
    for (var i = 0; i < 16; i++) h.push((b[i] + 0x100).toString(16).slice(1));
    return h.slice(0, 4).join('') + '-' + h.slice(4, 6).join('') + '-' + h.slice(6, 8).join('') + '-' +
           h.slice(8, 10).join('') + '-' + h.slice(10).join('');
  }
  function radeStatus(text, cls) {
    var s = document.getElementById('radestatus');
    if (s) { s.textContent = text || ''; s.className = 'radestatus' + (cls ? ' ' + cls : ''); }
  }
  function radeButtons() {
    ['L', 'U'].forEach(function (k) {
      var b = document.getElementById('btn-RADE' + k);
      if (!b) return;
      var on = rade.side === (k === 'L' ? 'lsb' : 'usb');
      b.classList.toggle('btn-selected', on);
      b.classList.toggle('rade-sync', on && !!rade.sigTimer);
    });
    if (rade.side) {                       // the LSB/USB button stays unlit while RADE is on
      var m = document.getElementById('btn-' + rade.side.toUpperCase());
      if (m) m.classList.remove('btn-selected');
    }
  }
  function radeFreqHz() { return Math.round((window.freq || 0) * 1000); }
  // RADE V1 occupies 700-2200 Hz of the audio band (1500 Hz): the decoder's session and
  // the filter shown on this page both use that passband
  var RADE_LO_HZ = 700, RADE_HI_HZ = 2200;
  function radeBW(side) { return side === 'usb' ? [RADE_LO_HZ, RADE_HI_HZ] : [-RADE_HI_HZ, -RADE_LO_HZ]; }
  // also true for the second Mode row (IQ, DRM): decoders stop for them as for RADE
  window.ubersdr_rade_active = function () { return !!rade.side || !!xm.kind; };
  window.ubersdr_rade_side = function () { return rade.side || null; };   // 'lsb' | 'usb' | null (station labels, decoders.js)

  // ── FreeDV Reporter window (shown while RADE is on) ────────────────────────
  // The same live list as UberSDR's FreeDV panel: stations reported to
  // qso.freedv.org, taken from UberSDR's FreeDV Reporter monitor over the DX-cluster
  // websocket the RADE session already uses ("subscribe_freedv_activity" →
  // freedv_activity_snapshot / freedv_activity_update). Kept small: stations on the
  // band being listened to (all when outside the band table), transmitting ones
  // first; a click on a station tunes to it. Built below the RADE status line, on the
  // desktop page only (the mobile page's version was removed at the user's request).
  var REP_MAX_MSG = 22, REP_ONFREQ_HZ = 100;
  var rep = { users: {}, pending: false };
  (function repStyle() {
    var css =
      '.radestatus{font-size:11px;line-height:13px;text-align:center;color:#333}' +
      '.radestatus.sync{color:#0a7d2c;font-weight:bold}.radestatus.err{color:#c00}' +
      '.radereporter{margin:3px 4px 4px;background:#f7f7f7;border:1px solid #bbb;border-radius:6px;' +
        'font:11px/1.3 Arial,sans-serif;color:#222;text-align:left;box-shadow:1px 2px 5px rgba(0,0,0,.15)}' +
      '.radereporter .rr-head{display:flex;justify-content:space-between;gap:6px;padding:3px 6px;' +
        'background:#dfe6e4;border-radius:6px 6px 0 0;font-weight:bold}' +
      '.radereporter .rr-count{font-weight:normal;color:#555}' +
      '.radereporter .rr-status{padding:2px 6px;color:#777;font-style:italic}' +
      '.radereporter .rr-status:empty{display:none}' +
      '.radereporter .rr-wrap{max-height:86px;overflow-y:scroll}' +   // header + 4 rows; scroll for more
      '.radereporter table{border-collapse:collapse;width:100%;table-layout:fixed}' +
      '.radereporter th{position:sticky;top:0;background:#eee;font-weight:bold;color:#444;text-align:left;' +
        'padding:1px 4px;border-bottom:1px solid #ccc}' +
      '.radereporter td{padding:1px 4px;border-bottom:1px solid #e4e4e4;white-space:nowrap;overflow:hidden;' +
        'text-overflow:ellipsis}' +
      '.radereporter tr.rr-tune{cursor:pointer}.radereporter tr.rr-tune:hover td{background:#e3f1ee}' +
      '.radereporter tr.rr-tx td{background:#fff1f0}' +
      '.radereporter .rr-ago{color:#666}.radereporter .rr-txb{background:#d32f2f;color:#fff;border-radius:3px;padding:0 3px;font-size:10px}' +
      '.radereporter .rr-on{color:#0a7d2c}.radereporter .rr-rxo{color:#777;font-size:9px;margin-left:3px}' +
      '.radereporter{width:470px;margin:3px auto 4px;box-sizing:border-box}';   // the desktop middle column
    var st = document.createElement('style');
    st.textContent = css;
    (document.head || document.documentElement).appendChild(st);
  })();

  function repPanel(create) {
    var p = document.getElementById('radereporter');
    if (p || !create) return p;
    var anchor = document.getElementById('radestatus');
    if (!anchor || !document.getElementById('wfmode')) return null;   // desktop page only
    p = document.createElement('div');
    p.id = 'radereporter';
    p.className = 'radereporter';
    p.hidden = true;
    p.innerHTML =
      '<div class="rr-head"><span>FreeDV Reporter — <span class="rr-band"></span></span><span class="rr-count"></span></div>' +
      '<div class="rr-status"></div>' +
      '<div class="rr-wrap"><table><colgroup><col style="width:19%"><col class="rr-c" style="width:15%">' +
      '<col style="width:10%"><col style="width:15%"><col class="rr-m" style="width:18%"><col style="width:7%">' +
      '<col class="rr-r" style="width:16%"></colgroup><thead><tr><th>Callsign</th><th class="rr-c">Country</th>' +
      '<th>km</th><th>kHz</th><th class="rr-m">Message</th><th>TX</th><th class="rr-r">Last RX</th></tr></thead>' +
      '<tbody></tbody></table></div>';
    anchor.parentNode.insertBefore(p, anchor.nextSibling);
    // QSY on a station's row. On the press, from one listener on the table: the rows are
    // rebuilt on every reporter update and retune, and a click (press + release on the
    // same row) was lost whenever that happened in between.
    p.querySelector('tbody').addEventListener('mousedown', function (ev) {
      var tr = ev.button === 0 && ev.target.closest && ev.target.closest('tr.rr-tune');
      if (!tr) return;
      ev.preventDefault();
      repTuneTo(Number(tr.dataset.hz));
    });
    return p;
  }
  function repStatus(t) { var p = repPanel(false); if (p) p.querySelector('.rr-status').textContent = t || ''; }
  var repTimer = null;
  function repShow(on) {
    var p = repPanel(on);
    if (!p) return;
    p.hidden = !on;
    clearInterval(repTimer);
    if (on) repTimer = setInterval(repSchedule, 30000);   // keep the "last TX" ages current
    if (!on) { rep.users = {}; p.querySelector('tbody').innerHTML = ''; }
    else { repStatus('Connecting to FreeDV Reporter…'); repSchedule(); }
  }
  function repSchedule() {
    if (rep.pending) return;
    rep.pending = true;
    requestAnimationFrame(function () { rep.pending = false; repRender(); });
  }
  function repBand() {                      // the band table entry of the tuned frequency
    var f = (window.freq || 0);
    for (var i = 0; i < HAM_BANDS.length; i++) if (f >= HAM_BANDS[i][1] && f <= HAM_BANDS[i][2]) return HAM_BANDS[i];
    return null;
  }
  function repTuneTo(hz) {
    if (!(hz > 0)) return;
    var f = hz / 1000, side = rade.side;
    if (typeof window.setwaterfall === 'function' && window.bi) setwaterfall(band, f);
    setfreq(f);
    // Into another amateur band (the list shows all bands outside them) the band's mode
    // goes in and switches RADE off: RADE stays on, on its sideband
    // (the listener's own choice: past the page's band-mode guard, which ignores software
    // mode changes for a moment after a band change)
    if (side && window.ubersdr_listener_mode) window.ubersdr_listener_mode();
    if (side && rade.side !== side) window.ubersdr_rade(side);
    else if (side && String(window.mode).toLowerCase() !== side) {   // still on, but the band's mode went in
      var bw = radeBW(side);
      rade.switching = true;
      try { set_mode(side); setmf(side, bw[0] / 1000, bw[1] / 1000); } finally { rade.switching = false; }
      radeButtons();
    }
    repSchedule();                          // the on-frequency dot at once
  }
  function repRender() {
    var p = repPanel(false);
    if (!p || p.hidden) return;
    var b = repBand(), list = [], sid, u;
    for (sid in rep.users) {
      u = rep.users[sid];
      if (!b || (u.freq_hz && u.freq_hz >= b[1] * 1000 && u.freq_hz <= b[2] * 1000)) list.push(u);
    }
    // Transmitting now first, then by most recent transmission (last_tx), then the
    // stations that have not transmitted, receive-only stations last
    function lastTx(u) { var t = u.last_tx ? Date.parse(u.last_tx) : NaN; return t === t ? t : 0; }
    list.sort(function (a, c) {
      if (!!a.transmitting !== !!c.transmitting) return a.transmitting ? -1 : 1;
      if (!!a.rx_only !== !!c.rx_only) return a.rx_only ? 1 : -1;
      var ta = lastTx(a), tc = lastTx(c);
      if (ta !== tc) return tc - ta;
      return String(a.callsign || '').localeCompare(String(c.callsign || ''));
    });
    p.querySelector('.rr-band').textContent = b ? b[0] : 'all bands';
    p.querySelector('.rr-count').textContent = list.length + (list.length === 1 ? ' station' : ' stations');
    var tb = p.querySelector('tbody'), dial = Math.round((window.freq || 0) * 1000);
    tb.innerHTML = '';
    if (!list.length) {
      var e = document.createElement('tr'), td = document.createElement('td');
      td.colSpan = 7; td.textContent = 'No FreeDV stations on this band';
      td.style.color = '#888'; e.appendChild(td); tb.appendChild(e);
      return;
    }
    list.forEach(function (u) {
      var tr = document.createElement('tr');
      function cell(text, cls, title) {
        var td = document.createElement('td');
        if (cls) td.className = cls;
        td.textContent = text;
        if (title) td.title = title;
        tr.appendChild(td);
        return td;
      }
      var c = cell(u.callsign || '—');
      if (u.rx_only) { var ro = document.createElement('span'); ro.className = 'rr-rxo'; ro.textContent = 'RX'; c.appendChild(ro); }
      cell(u.country || '—', 'rr-c');
      cell(u.distance_km != null ? String(Math.round(u.distance_km)) : '—');
      var fc = cell(u.freq_hz ? (u.freq_hz / 1000).toFixed(1) : '—');
      if (u.freq_hz && Math.abs(u.freq_hz - dial) <= REP_ONFREQ_HZ) {
        var dot = document.createElement('span'); dot.className = 'rr-on'; dot.textContent = ' ●';
        dot.title = 'You are tuned to this frequency'; fc.appendChild(dot);
      }
      var msg = u.message || '';
      cell(msg.length > REP_MAX_MSG ? msg.slice(0, REP_MAX_MSG) + '…' : (msg || '—'), 'rr-m', msg);
      var tx = cell('');
      if (u.transmitting) { var bx = document.createElement('span'); bx.className = 'rr-txb'; bx.textContent = 'TX'; tx.appendChild(bx); }
      else {                                // how long ago it last transmitted
        var lt = lastTx(u), ago = lt ? Math.max(0, (Date.now() - lt) / 1000) : -1;
        tx.textContent = ago < 0 ? '—' : ago < 60 ? Math.round(ago) + 's' : ago < 3600 ? Math.round(ago / 60) + 'm' :
                         ago < 86400 ? Math.round(ago / 3600) + 'h' : Math.round(ago / 86400) + 'd';
        if (lt) tx.title = 'Last transmitted ' + new Date(lt).toUTCString().replace(' GMT', ' UTC');
        tx.className = 'rr-ago';
      }
      cell(u.last_rx_callsign ? u.last_rx_callsign + (typeof u.last_rx_snr === 'number' ? ' ' + u.last_rx_snr.toFixed(0) + ' dB' : '') : '—', 'rr-r');
      if (u.transmitting) tr.className = 'rr-tx';
      var maxHz = (window.bi && bi[window.band]) ? (bi[band].centerfreq + bi[band].samplerate / 2) * 1000 : 30e6;
      if (u.freq_hz > 0 && u.freq_hz <= maxHz) {
        tr.className += ' rr-tune';
        tr.title = 'Tune to ' + (u.freq_hz / 1000).toFixed(1) + ' kHz';
        tr.dataset.hz = String(u.freq_hz);  // QSY: see repPanel
      }
      tb.appendChild(tr);
    });
  }
  function repMessage(m) {                  // DX-cluster text messages for the reporter
    if (m.type === 'freedv_activity_snapshot') {
      rep.users = {};
      (m.users || []).forEach(function (u) { if (u && u.sid) rep.users[u.sid] = u; });
      repStatus(''); repSchedule(); return true;
    }
    if (m.type === 'freedv_activity_update') {
      var u = m.user, sid = m.sid || (u && u.sid);
      if (m.event === 'remove_connection') delete rep.users[sid];
      else if (m.event === 'disconnected') { rep.users = {}; repStatus('FreeDV Reporter disconnected — reconnecting…'); }
      else if (u && u.sid) rep.users[u.sid] = u;
      repSchedule(); return true;
    }
    if (m.type === 'subscription_status' && m.stream === 'freedv_activity') {
      repStatus(m.enabled ? '' : (m.error || 'FreeDV Reporter is not available on this server'));
      return true;
    }
    return false;
  }

  function radeClose() {
    rade.gen++;
    clearInterval(rade.pingTimer); clearTimeout(rade.tuneTimer); clearTimeout(rade.retryTimer);
    clearTimeout(rade.sigTimer); rade.sigTimer = null;
    if (rade.dx) {
      try { if (rade.dx.readyState === 1) rade.dx.send(JSON.stringify({ type: 'audio_extension_detach' })); } catch (e) {}
      try { rade.dx.close(); } catch (e) {}
    }
    if (rade.ws) try { rade.ws.close(); } catch (e) {}
    rade.ws = rade.dx = null;
    if (rade.dec) { try { rade.dec.free(); } catch (e) {} }
    rade.dec = null; rade.decSR = rade.decCh = 0; rade.next = 0;
  }

  function radeStop() {
    if (!rade.side) return;
    radeClose();
    rade.side = null;
    radeStatus('');
    repShow(false);
    radeButtons();
    if (window.ubersdr_rade_onstop) window.ubersdr_rade_onstop();
    try { if (typeof window.mode === 'string') document.getElementById('btn-' + window.mode).classList.add('btn-selected'); } catch (e) {}
  }
  window.ubersdr_rade_stop = function () { radeStop(); xmStop(); };

  // One decoded-audio frame of an UberSDR audio extension (freedv, drm) → speaker:
  // 0x02, 1-8 timestamp, 9-12 sample rate (BE), 13 channels, 14… Opus. S holds the
  // decoder and play-out clock (rade, xm). False if it is not such a frame.
  function opusPlay(S, buf) {
    var sa = window.soundapplet;
    var ctx = sa && sa._audioCtx;
    if (!ctx || buf.byteLength < 15) return false;
    var v = new DataView(buf);
    if (v.getUint8(0) !== 0x02) return false;
    var sr = v.getUint32(9, false), ch = v.getUint8(13) || 1, data = new Uint8Array(buf, 14).slice();
    var gen = S.gen;
    // the Opus decoder is not re-entrant: frames are decoded strictly one after another
    S.busy = S.busy.then(function () {
      if (gen !== S.gen) return;
      var lib = window['opus-decoder'];
      if (!lib || !lib.OpusDecoder) return;
      var ready = Promise.resolve();
      if (!S.dec || S.decSR !== sr || S.decCh !== ch) {
        if (S.dec) try { S.dec.free(); } catch (e) {}
        S.dec = new lib.OpusDecoder({ sampleRate: sr, channels: ch });
        S.decSR = sr; S.decCh = ch;
        ready = S.dec.ready;
      }
      return ready.then(function () { return S.dec.decodeFrame(data); }).then(function (d) {
        if (gen !== S.gen || !d || !d.channelData || !d.channelData.length || !d.channelData[0].length) return;
        pcmPlay(S, d.channelData, d.sampleRate || sr);
      });
    }).catch(function () {});
    return true;
  }
  // Planar float PCM → speaker, chained after the last block (S.next)
  function pcmPlay(S, planes, sr, raw) {
    var sa = window.soundapplet, ctx = sa && sa._audioCtx;
    if (!ctx || !planes[0].length) return;
    var b = ctx.createBuffer(planes.length, planes[0].length, sr);
    for (var c = 0; c < planes.length; c++) b.copyToChannel(planes[c], c);
    var src = ctx.createBufferSource();
    src.buffer = b;
    if (raw) {
      // IQ, as PhantomSDR-Plus plays it: the stereo goes out as it came in, only the
      // page volume (and mute) applied. Notch and NR work on one channel and would
      // mix I and Q (or two panned demodulators) into one; Hi-Boost / Left-Right too.
      if (!S.rawOut || S.rawOut.context !== ctx) {
        S.rawOut = ctx.createGain();
        S.rawOut.connect(ctx.destination);
      }
      S.rawOut.gain.value = sa._gainNode ? sa._gainNode.gain.value : 1;
      src.connect(S.rawOut);
    } else src.connect(sa._gainNode || ctx.destination);   // volume, Hi-Boost, notch, NR as usual
    var now = ctx.currentTime;
    if (S.next < now) S.next = now + 0.12;          // (re)start with a small buffer
    src.start(S.next);
    S.next += b.duration;
  }
  function radePlay(buf) {                 // one Opus frame (ArrayBuffer) → speaker
    if (!opusPlay(rade, buf)) return;
    rade.frames++;
    if (!rade.sigTimer) { radeStatus('RADE ' + rade.side.toUpperCase() + ': decoding', 'sync'); }
    clearTimeout(rade.sigTimer);
    rade.sigTimer = setTimeout(function () {
      rade.sigTimer = null;
      if (rade.side) radeStatus('RADE ' + rade.side.toUpperCase() + ': waiting for a RADE signal…');
      radeButtons();
    }, RADE_SIG_TIMEOUT_MS);
    radeButtons();
  }

  function radeAttach(gen, retried) {
    if (gen !== rade.gen || !rade.dx || rade.dx.readyState !== 1) return;
    rade.dx.send(JSON.stringify({ type: 'audio_extension_attach', extension_name: 'freedv', params: {} }));
  }

  function radeConnect(side) {
    radeClose();
    var gen = rade.gen, base = radeBase(), uuid = radeUUID(), bw = radeBW(side);
    rade.uuid = uuid;
    radeStatus('RADE ' + side.toUpperCase() + ': connecting…');
    var x = new XMLHttpRequest();
    x.open('POST', base + '/connection', true);
    x.setRequestHeader('Content-Type', 'application/json');
    x.onerror = function () { if (gen === rade.gen) radeFail('cannot reach ' + base); };
    x.onload = function () {
      if (gen !== rade.gen) return;
      var r = null;
      try { r = JSON.parse(x.responseText); } catch (e) {}
      if (x.status !== 200 || !r || !r.allowed) { radeFail((r && r.reason) || ('server answered ' + x.status)); return; }
      var wsBase = base.replace(/^http/, 'ws');
      var q = 'user_session_id=' + uuid + '&frequency=' + radeFreqHz() + '&mode=' + side +
              '&bandwidthLow=' + bw[0] + '&bandwidthHigh=' + bw[1] + '&format=opus&muted=true';
      var ws = rade.ws = new WebSocket(wsBase + '/ws?' + q);
      ws.onmessage = function (ev) {       // only errors matter here; audio is muted
        if (typeof ev.data !== 'string') return;
        try { var m = JSON.parse(ev.data); if (m.type === 'error' && gen === rade.gen) radeStatus('RADE: ' + (m.error || m.message || 'error'), 'err'); } catch (e) {}
      };
      ws.onclose = function () { if (gen === rade.gen && rade.side) radeFail('connection to the receiver closed'); };
      ws.onopen = function () {
        if (gen !== rade.gen) return;
        rade.pingTimer = setInterval(function () { try { ws.send(JSON.stringify({ type: 'ping' })); } catch (e) {} }, 30000);
        var dx = rade.dx = new WebSocket(wsBase + '/ws/dxcluster?user_session_id=' + uuid);
        dx.binaryType = 'arraybuffer';
        dx.onopen = function () {
          if (document.getElementById('wfmode'))           // reporter window (desktop page)
            try { dx.send(JSON.stringify({ type: 'subscribe_freedv_activity' })); } catch (e) {}
          setTimeout(function () { radeAttach(gen, false); }, 500);   // let the audio session settle
        };
        dx.onmessage = function (ev) {
          if (gen !== rade.gen) return;
          if (ev.data instanceof ArrayBuffer) { radePlay(ev.data); return; }
          var m; try { m = JSON.parse(ev.data); } catch (e) { return; }
          if (repMessage(m)) return;
          if (m.type === 'audio_extension_attached') {
            radeStatus('RADE ' + side.toUpperCase() + ': waiting for a RADE signal…');
          } else if (m.type === 'audio_extension_error') {
            var err = m.error || 'decoder error';
            if (/too quickly|wait/i.test(err)) {       // restart cooldown (~2 s): try again once
              radeStatus('RADE ' + side.toUpperCase() + ': starting…');
              rade.retryTimer = setTimeout(function () { radeAttach(gen, true); }, 2500);
            } else if (/no active audio session/i.test(err)) {
              rade.retryTimer = setTimeout(function () { radeAttach(gen, true); }, 1000);
            } else radeFail(err);
          }
        };
        dx.onclose = function () { if (gen === rade.gen && rade.side) radeFail('decoder connection closed'); };
      };
    };
    x.send(JSON.stringify({ user_session_id: uuid }));
  }

  function radeFail(msg) {
    rade.lastErr = msg;
    radeClose();
    radeStatus('RADE unavailable: ' + msg, 'err');
    var side = rade.side;
    rade.side = null;
    repShow(false);
    radeButtons();
    if (window.ubersdr_rade_onstop) window.ubersdr_rade_onstop();
    try { document.getElementById('btn-' + window.mode).classList.add('btn-selected'); } catch (e) {}
    if (side) setTimeout(function () { if (!rade.side) radeStatus(''); }, 8000);
  }

  // Button: RADEL / RADEU. Pressing the active one again switches RADE off.
  window.ubersdr_rade = function (side) {
    side = side === 'usb' ? 'usb' : 'lsb';
    if (rade.side === side) {              // switch off: back to the normal filter of that sideband
      radeStop();
      if (typeof window.set_mode === 'function') set_mode(side);
      return;
    }
    if (!window.soundapplet || !window.soundapplet._audioCtx) {
      radeStatus('RADE: start the audio first', 'err');
      setTimeout(function () { if (!rade.side) radeStatus(''); }, 5000);
      return;
    }
    xmStop();
    rade.side = side;
    var bw = radeBW(side);
    rade.switching = true;
    try {
      if (String(window.mode).toLowerCase() !== side && typeof window.set_mode === 'function') set_mode(side);
      if (typeof window.setmf === 'function') setmf(side, bw[0] / 1000, bw[1] / 1000);   // show the RADE passband
    } finally { rade.switching = false; }
    radeButtons();
    repShow(true);
    radeConnect(side);
  };

  // Called after every tune on this page: the RADE session follows (throttled; the
  // server rate-limits commands)
  function radeFollowTune() {
    if (rade.side) repSchedule();          // band filter and on-frequency dot
    if (!rade.side || !rade.ws || rade.ws.readyState !== 1) return;
    clearTimeout(rade.tuneTimer);
    rade.tuneTimer = setTimeout(function () {
      if (rade.ws && rade.ws.readyState === 1) rade.ws.send(JSON.stringify({ type: 'tune', frequency: radeFreqHz() }));
    }, 300);
  }
  // Called after every mode/filter change: leaving the RADE sideband switches RADE off
  function radeFollowMode() {
    if (!rade.side || rade.switching) return;
    if (String(window.mode).toLowerCase() !== rade.side) radeStop();
    else radeButtons();
  }
  window.addEventListener('beforeunload', radeClose);

  // Mobile page: RADEL / RADEU in the mode list. The page tunes the sideband with its
  // own setmode_sel(), then sets the RADE passband; any other mode switches RADE off.
  window.addEventListener('load', function () {
    var sel = document.getElementById('modesel');
    if (document.getElementById('wfmode') || !sel || typeof window.setmode_sel !== 'function') return;
    var origSel = window.setmode_sel;
    window.setmode_sel = function (s) {
      var v = s.value, m = /^RADE([LU])$/.exec(v);
      if (!m) { if (rade.side) radeStop(); return origSel.apply(this, arguments); }
      var side = m[1] === 'L' ? 'lsb' : 'usb', bw = radeBW(side);
      s.value = side.toUpperCase();
      rade.switching = true;
      try { origSel.call(this, s); } finally { rade.switching = false; }
      s.value = v;
      window.lo = bw[0] / 1000; window.hi = bw[1] / 1000;     // RADE passband
      try { send_soundsettings_to_server(); drawaxis(); } catch (e) {}
      if (rade.side !== side) window.ubersdr_rade(side);
      if (!rade.side) window.ubersdr_rade_onstop();          // did not start (e.g. audio not started yet)
    };
    window.ubersdr_rade_onstop = function () {                  // the list shows the plain sideband again
      var cur = String(window.mode || '').toUpperCase();
      if (/^RADE/.test(sel.value)) sel.value = (cur === 'LSB' || cur === 'USB') ? cur : 'USB';
    };
    var origFreq = window.setfreq;
    window.setfreq = function () { var r = origFreq.apply(this, arguments); radeFollowTune(); return r; };
  });

  // ── Mode row 2: IQ, DRM (desktop; 2026-10-30) ───────────────────────────────
  // The IQ and DRM buttons of the second row of Mode buttons (next to RADE V1), done as
  // PhantomSDR-Plus does them:
  //   IQ        the receiver's raw I/Q (±6 kHz around the dial, 12 kHz complex): a main-UI
  //             session (as RADE V1) in mode iq, lossless PCM (format=pcm-zstd, inflated
  //             with sv1btl/fzstd.js), played I left / Q right; Rec IQ saves it as a
  //             stereo 16-bit WAV (I left, Q right), as PhantomSDR-Plus's IQ recording.
  //   DRM       Digital Radio Mondiale, decoded on the server by UberSDR's drm audio
  //             extension (ubersdr-drm) on an IQ session; Opus frames as freedv's, plus
  //             JSON status frames (0x03: station, text, SNR) shown in the status line.
  // Like RADE V1 the page's own WebSDR audio is silenced meanwhile, tuning follows, and
  // any other Mode button (or a mode change by software) switches it off.
  var XM = {
    iq:    { label: 'IQ',      btn: 'btn-IQ',    mode: 'am',  lo: -6,   hi: 6 },
    drm:   { label: 'DRM',     btn: 'btn-DRM',   mode: 'am',  lo: -4.955, hi: 4.955 }   // shown as 10.00 (-6 dB), as AM Wide
  };
  var XM_SIG_TIMEOUT_MS = 2500;
  var xm = { kind: null, gen: 0, ws: null, dx: null, dec: null, decSR: 0, decCh: 0, next: 0,
             busy: Promise.resolve(), sigTimer: null, pingTimer: null, tuneTimer: null, retryTimer: null,
             switching: false, zstd: null, pcmHdr: null, rec: null, drmStatus: null };

  function xmButtons() {
    Object.keys(XM).forEach(function (k) {
      var b = document.getElementById(XM[k].btn);
      if (!b) return;
      b.classList.toggle('btn-selected', xm.kind === k);
      b.classList.toggle('rade-sync', xm.kind === k && !!xm.sigTimer);
    });
    if (xm.kind) {                         // the AM / USB button stays unlit meanwhile
      var m = document.getElementById('btn-' + XM[xm.kind].mode.toUpperCase());
      if (m) m.classList.remove('btn-selected');
    }
  }
  function xmStatus(text, cls) { radeStatus(text, cls); }
  function xmSignal() {                    // audio arriving: lamp on until it stops
    var was = !!xm.sigTimer;
    clearTimeout(xm.sigTimer);
    xm.sigTimer = setTimeout(function () { xm.sigTimer = null; xmButtons(); xmIdleStatus(); }, XM_SIG_TIMEOUT_MS);
    if (!was) { xmButtons(); xmIdleStatus(); }
  }
  function xmIdleStatus() {
    if (xm.kind === 'drm') drmShow();
  }

  function xmClose() {
    xm.gen++;
    clearInterval(xm.pingTimer); clearTimeout(xm.tuneTimer); clearTimeout(xm.retryTimer);
    clearTimeout(xm.sigTimer); xm.sigTimer = null;
    if (xm.dx) {
      try { if (xm.dx.readyState === 1) xm.dx.send(JSON.stringify({ type: 'audio_extension_detach' })); } catch (e) {}
      try { xm.dx.close(); } catch (e) {}
    }
    if (xm.ws) try { xm.ws.close(); } catch (e) {}
    xm.ws = xm.dx = null;
    if (xm.dec) { try { xm.dec.free(); } catch (e) {} }
    xm.dec = null; xm.decSR = xm.decCh = 0; xm.next = 0; xm.pcmHdr = null; xm.drmStatus = null;
  }
  function xmStop() {
    if (!xm.kind) return;
    var k = xm.kind;
    if (xm.rec) iqRecStop(true);
    xmClose();
    xm.kind = null;
    xmStatus('');
    xmButtons();
    drmWinClose(); iqWinClose();
    xmBack(k);
  }
  // Back to the page's own mode: the band plan's (LSB on 40 m…), else AM
  function xmBack(k) {
    try {
      var bm = window.ubersdr_bandmode ? window.ubersdr_bandmode(window.freq) : null;
      xm.switching = true;
      set_mode(String(bm || 'am').toLowerCase());
    } catch (e) {} finally { xm.switching = false; }
    try { document.getElementById('btn-' + String(window.mode).toUpperCase()).classList.add('btn-selected'); } catch (e) {}
  }
  function xmFail(msg) {
    var k = xm.kind;
    if (xm.rec) iqRecStop(true);
    xmClose();
    xm.kind = null;
    xmStatus((k ? XM[k].label : '') + ' unavailable: ' + msg, 'err');
    xmButtons();
    drmWinClose(); iqWinClose();
    if (k) xmBack(k);
    setTimeout(function () { if (!xm.kind && !rade.side) xmStatus(''); }, 10000);
  }

  // Button: IQ / DRM. Pressing the lit one again switches it off.
  window.ubersdr_xmode = function (k) {
    if (!XM[k]) return;
    if (xm.kind === k) { xmStop(); return; }
    if (!window.soundapplet || !window.soundapplet._audioCtx) {
      xmStatus(XM[k].label + ': start the audio first', 'err');
      setTimeout(function () { if (!xm.kind && !rade.side) xmStatus(''); }, 5000);
      return;
    }
    xmStop();
    radeStop();
    try { if (window.ubersdr_decoders && window.ubersdr_decoders.state().on) window.ubersdr_decoders.stop(true); } catch (e) {}
    xm.kind = k;
    var d = XM[k];
    xm.switching = true;
    try {
      if (window.ubersdr_listener_mode) window.ubersdr_listener_mode();
      if (String(window.mode).toLowerCase() !== d.mode) set_mode(d.mode);
      setmf(d.mode, d.lo, d.hi);           // shows the passband the mode uses
    } catch (e) {} finally { xm.switching = false; }
    xmButtons();
    xmConnect(k);
    if (k === 'drm') drmWinOpen();
    if (k === 'iq') iqWinOpen();
  };

  // Tuning on this page: the main-UI session follows (throttled; the server rate-limits)
  function xmFollowTune() {
    if (!xm.kind || !xm.ws || xm.ws.readyState !== 1) return;
    clearTimeout(xm.tuneTimer);
    xm.tuneTimer = setTimeout(function () {
      if (xm.ws && xm.ws.readyState === 1) xm.ws.send(JSON.stringify({ type: 'tune', frequency: radeFreqHz() }));
      if (xm.kind === 'drm') { xm.drmStatus = null; drmShow(); drmWinFill(); }
    }, 300);
  }
  // A mode change by software (CAT, labels…) away from the mode's own switches it off
  function xmFollowMode() {
    if (!xm.kind || xm.switching) return;
    var d = XM[xm.kind];
    if (String(window.mode).toLowerCase() !== d.mode) { xmStop(); return; }
    // same mode, other width (the band plan's AM ±4.455 kHz on tuning): back to the mode's own
    if (Math.abs(window.lo - d.lo) > 0.01 || Math.abs(window.hi - d.hi) > 0.01) {
      xm.switching = true;
      try { setmf(d.mode, d.lo, d.hi); } catch (e) {} finally { xm.switching = false; }
    }
    xmButtons();
  }
  // Any other Mode button (CW … FM, RADE V1): off
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('#moderow .btnMode');
    if (!b || !xm.kind || b.id === XM[xm.kind].btn || /^btn-RADE[LU]$/.test(b.id)) return;
    if (b.closest('#decrow')) return;      // decoders stop it themselves (ubersdr_rade_stop)
    xmStop();
  }, true);
  window.addEventListener('beforeunload', xmClose);

  // ── IQ and DRM: a main-UI session in mode iq ──
  function xmConnect(k) {
    xmClose();
    var gen = xm.gen, base = radeBase(), uuid = radeUUID(), L = XM[k].label;
    xmStatus(L + ': connecting…');
    var go = function () {
      var x = new XMLHttpRequest();
      x.open('POST', base + '/connection', true);
      x.setRequestHeader('Content-Type', 'application/json');
      x.onerror = function () { if (gen === xm.gen) xmFail('cannot reach ' + base); };
      x.onload = function () {
        if (gen !== xm.gen) return;
        var r = null;
        try { r = JSON.parse(x.responseText); } catch (e) {}
        if (x.status !== 200 || !r || !r.allowed) { xmFail((r && r.reason) || ('server answered ' + x.status)); return; }
        var wsBase = base.replace(/^http/, 'ws');
        // IQ is heard: lossless PCM. DRM is the decoder's: the session stays muted.
        var q = 'user_session_id=' + uuid + '&frequency=' + radeFreqHz() + '&mode=iq' +
                (k === 'iq' ? '&format=pcm-zstd' : '&format=opus&muted=true');
        var ws = xm.ws = new WebSocket(wsBase + '/ws?' + q);
        ws.binaryType = 'arraybuffer';
        ws.onmessage = function (ev) {
          if (gen !== xm.gen) return;
          if (ev.data instanceof ArrayBuffer) { if (k === 'iq') iqFrame(ev.data); return; }
          try { var m = JSON.parse(ev.data); if (m.type === 'error') xmStatus(L + ': ' + (m.error || m.message || 'error'), 'err'); } catch (e) {}
        };
        ws.onclose = function () { if (gen === xm.gen && xm.kind) xmFail('connection to the receiver closed'); };
        ws.onopen = function () {
          if (gen !== xm.gen) return;
          xm.pingTimer = setInterval(function () { try { ws.send(JSON.stringify({ type: 'ping' })); } catch (e) {} }, 30000);
          if (k === 'iq') { iqIdle(); return; }
          var dx = xm.dx = new WebSocket(wsBase + '/ws/dxcluster?user_session_id=' + uuid);
          dx.binaryType = 'arraybuffer';
          var attach = function () {
            if (gen === xm.gen && dx.readyState === 1)
              dx.send(JSON.stringify({ type: 'audio_extension_attach', extension_name: 'drm', params: {} }));
          };
          dx.onopen = function () { setTimeout(attach, 700); };   // let the IQ session settle
          dx.onmessage = function (ev) {
            if (gen !== xm.gen) return;
            if (ev.data instanceof ArrayBuffer) { drmFrame(ev.data); return; }
            var m; try { m = JSON.parse(ev.data); } catch (e) { return; }
            if (m.type === 'audio_extension_attached') drmShow();
            else if (m.type === 'audio_extension_error') {
              var err = m.error || 'decoder error';
              if (/too quickly|wait|no active audio session|mode/i.test(err) && !xm.retried) {
                xm.retried = true; xmStatus('DRM: starting…');
                xm.retryTimer = setTimeout(attach, 2500);
              } else xmFail(err);
            }
          };
          dx.onclose = function () { if (gen === xm.gen && xm.kind) xmFail('decoder connection closed'); };
        };
      };
      x.send(JSON.stringify({ user_session_id: uuid }));
    };
    xm.retried = false;
    if (k === 'iq' && !xm.zstd) {          // the inflater, loaded on first use
      import(new URL('sv1btl/fzstd.js?v=20261030', location.href).href).then(function (mod) {
        xm.zstd = mod.decompress;
        if (gen === xm.gen) go();
      }, function () { if (gen === xm.gen) xmFail('could not load sv1btl/fzstd.js'); });
    } else go();
  }

  // IQ frame (UberSDR pcm_binary.go, zstd-compressed as a whole): full header
  // [magic u16 LE 0x5043][version][format][rtp u64][wall ms u64][rate u32][channels u8]
  // (+ v2/v3: baseband f32, noise f32)[reserved u32] = 29 / 37 bytes, or minimal
  // [0x504D][version][rtp u64][reserved u16] = 13 bytes ("as before"); then big-endian
  // int16 samples, interleaved I,Q.
  function iqFrame(buf) {
    var b;
    try { b = new Uint8Array(buf); if (b.length >= 4 && b[0] === 0x28 && b[1] === 0xB5 && b[2] === 0x2F && b[3] === 0xFD) b = xm.zstd(b); }
    catch (e) { return; }
    if (b.length < 13) return;
    var v = new DataView(b.buffer, b.byteOffset, b.byteLength), magic = v.getUint16(0, true), off;
    if (magic === 0x5043) {
      var ver = b[2];
      xm.pcmHdr = { sr: v.getUint32(20, true) || 12000, ch: b[24] || 2 };
      off = ver >= 2 ? 37 : 29;
    } else if (magic === 0x504D && xm.pcmHdr) off = 13;
    else return;
    var ch = xm.pcmHdr.ch, sr = xm.pcmHdr.sr, n = Math.floor((b.length - off) / 2 / ch);
    if (n <= 0) return;
    var planes = [];
    for (var c = 0; c < ch; c++) planes.push(new Float32Array(n));
    for (var i = 0, p = off; i < n; i++) for (c = 0; c < ch; c++, p += 2) planes[c][i] = v.getInt16(p, false) / 32768;
    if (xm.rec) iqRecPush(planes, sr);
    if (iqw.bank && iqw.el && planes.length === 2) {          // IQ demodulators (PhantomSDR-Plus)
      iqw.bank.setRate(sr);
      var iq = new Float32Array(n * 2);
      for (var k = 0; k < n; k++) { iq[2 * k] = planes[0][k]; iq[2 * k + 1] = planes[1][k]; }
      var out = iqw.bank.process(iq);
      if (out !== iq) for (k = 0; k < n; k++) { planes[0][k] = out[2 * k]; planes[1][k] = out[2 * k + 1]; }
    }
    pcmPlay(xm, planes.length === 1 ? [planes[0], planes[0]] : planes, sr, true);
    var first = !xm.sigTimer;
    clearTimeout(xm.sigTimer);
    xm.sigTimer = setTimeout(function () { xm.sigTimer = null; xmButtons(); iqIdle(); }, XM_SIG_TIMEOUT_MS);
    if (first) iqIdle();
  }
  function iqIdle() {
    if (xm.kind !== 'iq') return;
    var s = document.getElementById('radestatus');
    if (!s) return;
    var h = xm.pcmHdr, txt = !xm.sigTimer ? 'IQ: waiting for the I/Q stream…' :
      'IQ ' + (h ? '±' + (h.sr / 2000) + ' kHz, ' + (h.sr / 1000) + ' kHz ' +
        (iqw.el && iqw.bank && iqw.listening && iqw.bank.demods.length ? '· demodulators' : h.ch === 2 ? 'I left / Q right' : 'mono') : '');
    var rec = xm.rec ? ' ■ Stop IQ rec (' + Math.round(xm.rec.n / xm.rec.sr) + ' s)' : ' ● Rec IQ';
    s.className = 'radestatus' + (xm.sigTimer ? ' sync' : '');
    s.innerHTML = '';
    s.appendChild(document.createTextNode(txt + ' '));
    var a = document.createElement('a');
    a.href = 'javascript:void(0)'; a.textContent = rec; a.style.color = 'inherit';
    a.title = 'Record the I/Q as a WAV file for HDSDR, SDR#, SDR++ or SDRuno (stereo 16-bit, I left, Q right, centre frequency stored); at most 60 minutes';
    a.onclick = function () { if (xm.rec) iqRecStop(false); else iqRecStart(); };
    s.appendChild(a);
    xmButtons();
  }
  var IQ_REC_MAX_S = 3600;            // as PhantomSDR-Plus (maxRecordingDuration)
  function iqRecStart() {
    if (xm.kind !== 'iq') return;
    xm.rec = { chunks: [], n: 0, sr: (xm.pcmHdr && xm.pcmHdr.sr) || 12000, hz: radeFreqHz(), t0: new Date(), shown: 0 };
    iqIdle();
  }
  function iqRecPush(planes, sr) {
    var r = xm.rec, n = planes[0].length, q = planes[1] || planes[0];
    if (sr !== r.sr && r.n) { iqRecStop(false); return; }
    r.sr = sr;
    var out = new Int16Array(n * 2);
    for (var i = 0; i < n; i++) {
      out[2 * i] = Math.max(-32768, Math.min(32767, Math.round(planes[0][i] * 32767)));
      out[2 * i + 1] = Math.max(-32768, Math.min(32767, Math.round(q[i] * 32767)));
    }
    r.chunks.push(out); r.n += n;
    if (r.n / r.sr >= IQ_REC_MAX_S) { iqRecStop(false); return; }
    if (Math.floor(r.n / r.sr) !== r.shown) { r.shown = Math.floor(r.n / r.sr); iqIdle(); }
  }
  // The WAV as PhantomSDR-Plus writes it (audio.js _iqWavBlob): PCM, 2 channels (I left,
  // Q right), 16 bit, plus the "auxi" chunk SpectraVue introduced and HDSDR, SDR# and
  // SDRuno read for the centre frequency, sample rate and start/stop time. SDR++ takes
  // the frequency from the file name instead (the first "<digits>Hz" in it).
  function iqRecStop(discard) {
    var r = xm.rec;
    xm.rec = null;
    if (!r || discard || !r.n) { iqIdle(); return; }
    var data = r.n * 4, AUXI = 164, hdr = new DataView(new ArrayBuffer(12 + 24 + 8 + AUXI + 8)), o = 0;
    var tag = function (t) { for (var i = 0; i < 4; i++) hdr.setUint8(o++, t.charCodeAt(i)); };
    var u32 = function (x) { hdr.setUint32(o, x >>> 0, true); o += 4; };
    var u16 = function (x) { hdr.setUint16(o, x, true); o += 2; };
    var systime = function (d) {         // SYSTEMTIME, UTC
      u16(d.getUTCFullYear()); u16(d.getUTCMonth() + 1); u16(d.getUTCDay()); u16(d.getUTCDate());
      u16(d.getUTCHours()); u16(d.getUTCMinutes()); u16(d.getUTCSeconds()); u16(d.getUTCMilliseconds());
    };
    tag('RIFF'); u32(hdr.byteLength - 8 + data); tag('WAVE');
    tag('fmt '); u32(16); u16(1); u16(2); u32(r.sr); u32(r.sr * 4); u16(4); u16(16);
    tag('auxi'); u32(AUXI);
    systime(r.t0); systime(new Date());
    u32(r.hz);                            // CenterFreq
    u32(r.sr);                            // ADFrequency
    u32(0);                               // IFFrequency
    u32(r.sr);                            // Bandwidth
    u32(0);                               // IQOffset
    o += 4 * 4 + 96;                      // Unused2..5, next file name: zero
    tag('data'); u32(data);
    var stamp = r.t0.toISOString().replace(/[-:]/g, '').replace('T', '_').slice(0, 15);
    var a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([hdr.buffer].concat(r.chunks), { type: 'audio/wav' }));
    a.download = 'UberSDR_' + stamp + 'Z_' + r.hz + 'Hz_IQ.wav';
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
    iqIdle();
  }

  // IQ Demodulators window, as PhantomSDR-Plus's IqDemodPanel.svelte: up to six receivers
  // inside the 12 kHz I/Q stream (its engine sv1btl/psdr/lib/iqDemod.js, unchanged), each
  // with its own offset, mode, width, volume and pan; "Demodulators" plays them, "Raw I/Q"
  // the I/Q itself (I left, Q right). The picture is the 12 kHz around the dial: a click
  // moves the selected demodulator there, the wheel nudges it (Shift = 100 Hz). Settings
  // are kept in the browser; the bank stays for the visit, so IQ comes back as it was left.
  // Rec IQ still records the I/Q itself, not the demodulators.
  var IQW_STORE = 'phantom.iqdemod.v1', IQW_H = 120, IQW_SPAN = 12000;
  var iqw = { el: null, mod: null, bank: null, sel: null, listening: true, raf: 0, last: 0, lastW: 0, floor: null };
  function iqwColor(d) { var ds = iqw.bank.demods; return iqw.mod.DEMOD_COLORS[ds.indexOf(ds.find(function (x) { return x.id === d.id; })) % iqw.mod.DEMOD_COLORS.length]; }
  function iqwKhz(off) { return ((Number(window.freq) || 0) + off / 1000).toFixed(3); }
  function iqwPassband(d) {
    switch (d.mode) {
      case 'USB': return [d.offset + 50, d.offset + d.bw];
      case 'LSB': return [d.offset - d.bw, d.offset - 50];
      default:    return [d.offset - d.bw / 2, d.offset + d.bw / 2];
    }
  }
  function iqwSave() {
    try { localStorage.setItem(IQW_STORE, JSON.stringify({ listening: iqw.listening, demods: iqw.bank.configs() })); } catch (e) {}
  }
  function iqwLoad() {
    try {
      var st = JSON.parse(localStorage.getItem(IQW_STORE) || 'null');
      if (st && Array.isArray(st.demods)) {
        iqw.bank.load(st.demods.map(function (c) { var o = Object.assign({}, c); delete o.id; return o; }));
        iqw.listening = st.listening !== false;
        return true;
      }
    } catch (e) {}
    return false;
  }
  function iqwConfigs() { return iqw.bank.configs(); }
  function iqwAdd(offset) {
    var sel = iqwConfigs().find(function (d) { return d.id === iqw.sel; });
    var id = iqw.bank.add({ mode: sel ? sel.mode : 'AM', offset: offset || 0 });
    if (id != null) iqw.sel = id;
    iqwRows();
  }
  function iqwSet(id, patch, keepRows) {
    iqw.bank.update(id, patch);
    iqwSave();
    if (!keepRows) iqwRows();
  }
  function iqwListen(v) {
    iqw.listening = v; iqw.bank.listening = v; iqwSave(); iqwHead(); iqIdle();
  }
  function iqwHead() {
    var w = iqw.el; if (!w) return;
    var n = iqwConfigs().length;
    w.querySelector('.iq-count').textContent = n + ' of ' + iqw.mod.MAX_DEMODS;
    w.querySelector('.iq-dem').classList.toggle('on', iqw.listening);
    w.querySelector('.iq-raw').classList.toggle('on', !iqw.listening);
    w.querySelector('.iq-add').disabled = n >= iqw.mod.MAX_DEMODS;
  }
  function iqwRows() {
    var w = iqw.el; if (!w) return;
    var M = iqw.mod, ds = iqwConfigs();
    if (!ds.some(function (d) { return d.id === iqw.sel; })) iqw.sel = ds.length ? ds[0].id : null;
    iqwSave(); iqwHead();
    var box = w.querySelector('.iq-rows');
    box.innerHTML = ds.map(function (d) {
      var sel = d.id === iqw.sel, col = iqwColor(d), r = M.BW_RANGE[d.mode];
      var pan = d.pan === 0 ? 'centre' : d.pan < 0 ? 'left ' + Math.round(-d.pan * 100) + ' %' : 'right ' + Math.round(d.pan * 100) + ' %';
      return '<div class="iq-row' + (sel ? ' sel' : '') + '" data-id="' + d.id + '"><div class="iq-line">' +
        '<span class="iq-dot" style="background:' + col + '"></span>' +
        '<select class="iq-mode" title="Mode">' + M.DEMOD_MODES.map(function (m) { return '<option' + (m === d.mode ? ' selected' : '') + '>' + m + '</option>'; }).join('') + '</select>' +
        '<button type="button" data-step="-100" title="−100 Hz">«</button><button type="button" data-step="-10" title="−10 Hz">‹</button>' +
        '<span class="iq-f" title="' + (d.offset >= 0 ? '+' : '') + d.offset + ' Hz from the dial">' + iqwKhz(d.offset) + '</span>' +
        '<button type="button" data-step="10" title="+10 Hz">›</button><button type="button" data-step="100" title="+100 Hz">»</button>' +
        '<span class="iq-lvl" title="Level in the passband"><span style="background:' + col + '"></span></span>' +
        '<button type="button" class="iq-mute' + (d.mute ? ' on' : '') + '" title="' + (d.mute ? 'Unmute' : 'Mute') + '">M</button>' +
        '<button type="button" class="iq-del" title="Remove">✕</button></div>' +
        (sel ? '<div class="iq-sliders">' +
          '<label><span>Width ' + (d.bw / 1000).toFixed(2) + ' kHz</span><input type="range" data-k="bw" min="' + r[0] + '" max="' + r[1] + '" step="50" value="' + d.bw + '"></label>' +
          '<label><span>Volume ' + Math.round(d.vol * 100) + ' %</span><input type="range" data-k="vol" min="0" max="2" step="0.05" value="' + d.vol + '"></label>' +
          '<label><span>Pan ' + pan + '</span><input type="range" data-k="pan" min="-1" max="1" step="0.1" value="' + d.pan + '"></label></div>' : '') +
        '</div>';
    }).join('');
  }
  function iqwSliderLabel(k, v) {
    if (k === 'bw') return 'Width ' + (v / 1000).toFixed(2) + ' kHz';
    if (k === 'vol') return 'Volume ' + Math.round(v * 100) + ' %';
    return 'Pan ' + (v === 0 ? 'centre' : v < 0 ? 'left ' + Math.round(-v * 100) + ' %' : 'right ' + Math.round(v * 100) + ' %');
  }
  function iqwOpenUI() {
    var w = iqw.el;
    w.innerHTML = '<div class="dw-head"><span class="dw-title"><span class="iq-dot" style="background:#22d3ee"></span> IQ Demodulators ' +
      '<span class="iq-count" style="font-weight:normal;color:#555"></span></span>' +
      '<button type="button" class="iq-dem" title="Hear the demodulators below">Demodulators</button>' +
      '<button type="button" class="iq-raw" title="Hear the raw I/Q: I left, Q right">Raw I/Q</button>' +
      '<button type="button" class="iq-add" title="Add a demodulator at the dial">+ Add</button></div>' +
      '<canvas class="iq-cv" style="height:' + IQW_H + 'px" title="Click: move the selected demodulator here · wheel: 10 Hz (Shift 100 Hz)"></canvas>' +
      '<div class="iq-rows"></div>' +
      '<div class="dw-status" style="font-style:normal">Each demodulator listens somewhere in the 12 kHz around the dial, in its own mode, without retuning the receiver; they move with the dial. Recording in IQ records the I/Q itself, not these.</div>';
    w.querySelector('.iq-dem').onclick = function () { iqwListen(true); };
    w.querySelector('.iq-raw').onclick = function () { iqwListen(false); };
    w.querySelector('.iq-add').onclick = function () { iqwAdd(0); };
    var cv = w.querySelector('.iq-cv');
    var xToHz = function (x, wd) { return Math.round(((x / wd) * IQW_SPAN - IQW_SPAN / 2) / 10) * 10; };
    cv.onclick = function (e) {
      var r = cv.getBoundingClientRect(), sx = r.width / cv.offsetWidth || 1;   // the page may be scaled
      var hz = Math.max(-6000, Math.min(6000, xToHz((e.clientX - r.left) / sx, cv.offsetWidth)));
      if (iqw.sel == null) iqwAdd(hz); else iqwSet(iqw.sel, { offset: hz });
    };
    cv.addEventListener('wheel', function (e) {
      if (iqw.sel == null) return;
      e.preventDefault();
      var d = iqwConfigs().find(function (x) { return x.id === iqw.sel; }), step = e.shiftKey ? 100 : 10;
      iqwSet(iqw.sel, { offset: Math.round(d.offset / step) * step + (e.deltaY < 0 ? step : -step) });
    }, { passive: false });
    var rows = w.querySelector('.iq-rows');
    rows.addEventListener('click', function (e) {
      var row = e.target.closest('.iq-row'); if (!row) return;
      var id = +row.dataset.id, d = iqwConfigs().find(function (x) { return x.id === id; }); if (!d) return;
      var b = e.target.closest('button');
      if (b && b.dataset.step) { iqwSet(id, { offset: d.offset + (+b.dataset.step) }); return; }
      if (b && b.classList.contains('iq-mute')) { iqwSet(id, { mute: !d.mute }); return; }
      if (b && b.classList.contains('iq-del')) { iqw.bank.remove(id); iqwRows(); return; }
      if (e.target.closest('select, input')) { if (iqw.sel !== id) { iqw.sel = id; iqwRows(); } return; }
      if (iqw.sel !== id) { iqw.sel = id; iqwRows(); }
    });
    rows.addEventListener('change', function (e) {
      if (!e.target.classList.contains('iq-mode')) return;
      iqwSet(+e.target.closest('.iq-row').dataset.id, { mode: e.target.value, bw: null });
    });
    rows.addEventListener('input', function (e) {
      var k = e.target.dataset && e.target.dataset.k; if (!k) return;
      var v = +e.target.value, patch = {}; patch[k] = v;
      iqwSet(+e.target.closest('.iq-row').dataset.id, patch, true);     // keep the slider under the mouse
      e.target.previousElementSibling.textContent = iqwSliderLabel(k, v);
    });
    iqwRows();
    iqw.raf = requestAnimationFrame(iqwDraw);
  }
  function iqwDraw(t) {
    iqw.raf = requestAnimationFrame(iqwDraw);
    var w = iqw.el; if (!w || !iqw.bank || t - iqw.last < 66) return;    // ~15 frames/s
    iqw.last = t;
    var levels = iqw.bank.levels();
    w.querySelectorAll('.iq-row').forEach(function (row) {
      var v = levels[+row.dataset.id], pct = v == null ? 0 : Math.max(0, Math.min(100, ((v + 60) / 50) * 100));
      row.querySelector('.iq-lvl span').style.width = pct + '%';
    });
    var cv = w.querySelector('.iq-cv'), sp = iqw.bank.spectrum();
    var dpr = window.devicePixelRatio || 1, cssW = cv.offsetWidth;
    if (!cssW) return;
    var W = Math.round(cssW * dpr), H = Math.round(IQW_H * dpr);
    if (W !== iqw.lastW) { cv.width = W; cv.height = H; iqw.lastW = W; }
    var ctx = cv.getContext('2d');
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
    var xOf = function (hz) { return ((hz + IQW_SPAN / 2) / IQW_SPAN) * W; };
    ctx.font = (10 * dpr) + 'px monospace'; ctx.textAlign = 'center';
    for (var hz = -6000; hz <= 6000; hz += 2000) {                        // grid every 2 kHz, real frequencies
      var x = xOf(hz);
      ctx.strokeStyle = hz === 0 ? 'rgba(255,255,255,0.35)' : 'rgba(255,255,255,0.1)';
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H - 12 * dpr); ctx.stroke();
      if (hz > -6000 && hz < 6000) { ctx.fillStyle = 'rgba(200,220,255,0.6)'; ctx.fillText(iqwKhz(hz), x, H - 2 * dpr); }
    }
    iqwConfigs().forEach(function (d) {                                    // passbands under the trace
      var pb = iqwPassband(d), col = iqwColor(d), sel = d.id === iqw.sel;
      ctx.globalAlpha = sel ? 0.28 : 0.14; ctx.fillStyle = col;
      ctx.fillRect(xOf(pb[0]), 0, Math.max(1, xOf(pb[1]) - xOf(pb[0])), H - 12 * dpr);
      ctx.globalAlpha = 1; ctx.strokeStyle = col; ctx.lineWidth = (sel ? 2 : 1) * dpr;
      ctx.beginPath(); ctx.moveTo(xOf(d.offset), 0); ctx.lineTo(xOf(d.offset), H - 12 * dpr); ctx.stroke();
      ctx.lineWidth = 1;
    });
    if (sp) {
      var n = sp.db.length, sorted = Float32Array.from(sp.db).sort(), med = sorted[n >> 1];
      iqw.floor = iqw.floor === null ? med : iqw.floor + 0.1 * (med - iqw.floor);
      var lo = iqw.floor - 6, range = 60, top = H - 14 * dpr;
      ctx.strokeStyle = 'rgba(220,235,255,0.9)'; ctx.beginPath();
      for (var i = 0; i < n; i++) {
        var xx = (i / (n - 1)) * W, y = top - Math.max(0, Math.min(1, (sp.db[i] - lo) / range)) * (top - 4 * dpr);
        if (i === 0) ctx.moveTo(xx, y); else ctx.lineTo(xx, y);
      }
      ctx.stroke();
    }
  }
  function iqWinOpen() {
    iqWinClose();
    var mr = document.getElementById('moderow');
    if (!mr || !document.getElementById('wfmode')) return;              // desktop page only
    if (!document.getElementById('iqwin-style')) {
      var css = document.createElement('style'); css.id = 'iqwin-style';
      css.textContent = '#iqwin .dw-head button.on{background:#0e7490;color:#fff}' +
        '#iqwin .iq-dot{display:inline-block;width:10px;height:10px;border-radius:50%;vertical-align:-1px}' +
        '#iqwin .iq-cv{display:block;width:calc(100% - 12px);margin:4px 6px 0;border:1px solid #555;border-radius:4px;cursor:crosshair}' +
        '#iqwin .iq-rows{display:flex;flex-direction:column;gap:3px;padding:4px 6px}' +
        '#iqwin .iq-row{border:1px solid #ddd;border-radius:4px;padding:2px 4px;cursor:pointer}' +
        '#iqwin .iq-row.sel{border-color:#999;background:#eef3f2}' +
        '#iqwin .iq-line{display:flex;align-items:center;gap:4px}' +
        '#iqwin .iq-line button{padding:0 4px}' +
        '#iqwin .iq-f{font:bold 11px "Courier New",monospace;color:#0e7490;width:72px;text-align:center}' +
        '#iqwin .iq-lvl{flex:1;min-width:40px;height:6px;border-radius:3px;background:#ccc;overflow:hidden}' +
        '#iqwin .iq-lvl span{display:block;height:100%;width:0}' +
        '#iqwin .iq-mute.on{background:#b91c1c;color:#fff}' +
        '#iqwin .iq-sliders{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:3px;font-size:10px;color:#555}' +
        '#iqwin .iq-sliders label{display:flex;flex-direction:column}' +
        '#iqwin .iq-sliders input{width:100%;margin:0}';
      document.head.appendChild(css);
    }
    var w = iqw.el = document.createElement('div');
    w.className = 'decwin'; w.id = 'iqwin';
    w.innerHTML = '<div class="dw-head"><span class="dw-title">IQ Demodulators</span></div><div class="dw-status">Loading…</div>';
    mr.appendChild(w);
    var go = function (M) {
      iqw.mod = M;
      if (iqw.el !== w) return;
      var sr = (xm.pcmHdr && xm.pcmHdr.sr) || 12000;
      if (!iqw.bank) iqw.bank = new M.IQDemodBank(sr);
      else iqw.bank.setRate(sr);
      if (iqw.bank.demods.length) iqw.listening = iqw.bank.listening;    // back in IQ: as it was left
      else { if (!iqwLoad()) iqw.bank.add({ mode: 'AM', offset: 0 }); iqw.bank.listening = iqw.listening; }
      iqwOpenUI();
    };
    if (iqw.mod) go(iqw.mod);
    else import(new URL('sv1btl/psdr/lib/iqDemod.js?v=20261030', location.href).href).then(go, function () {
      if (iqw.el === w) w.querySelector('.dw-status').textContent = 'IQ demodulators unavailable (sv1btl/psdr/lib/iqDemod.js)';
    });
  }
  function iqWinClose() {
    cancelAnimationFrame(iqw.raf); iqw.raf = 0; iqw.lastW = 0;
    if (iqw.el) iqw.el.remove();
    iqw.el = null;
  }

  // DRM schedule, as PhantomSDR-Plus's DRM panel (lib/DrmPanel.svelte): a station
  // selector from the DRM Reception Project's schedule (sv1btl/psdr/lib/drmSchedule.js,
  // PhantomSDR-Plus's own file and its saved copy of the schedule): broadcasts this
  // receiver can tune (±5 kHz around the centre must fit), ranked by this station's
  // locator — beamed here, on air now (nearest first), later (next 24 h), medium wave;
  // "Confirmed only" (on by default) keeps the ones confirmed on air or HFCC-registered;
  // ⇒ Tune puts the dial on the channel centre. The dial line says which listed
  // station is on air there.
  var drmw = { el: null, mod: null, sel: '', confirmed: true, timer: null };
  function drmWinOpen() {
    drmWinClose();
    drmw.sel = ''; drmw.confirmed = true;              // as the panel when DRM starts
    var mr = document.getElementById('moderow');
    if (!mr || !document.getElementById('wfmode')) return;      // desktop page only
    var w = drmw.el = document.createElement('div');
    w.className = 'decwin'; w.id = 'drmwin';
    w.innerHTML = '<div class="dw-head"><span class="dw-title">DRM schedule</span>' +
      '<span class="drm-dial" title="Dial = centre of the DRM channel"></span></div>' +
      '<div style="display:flex;gap:4px;padding:4px 6px"><select class="drm-sel dec-sel" style="flex:1;min-width:0;max-width:none" ' +
      'title="DRM broadcasts this receiver can tune (UTC), from the DRM Reception Project schedule"></select>' +
      '<button type="button" class="drm-go" title="Tune the receiver to this DRM channel">⇒ Tune</button></div>' +
      '<div class="dw-status" style="font-style:normal">Schedule: <a href="https://www.drmrx.org/" target="_blank" rel="noopener noreferrer">DRM Reception Project</a> ' +
      '(saved copy) · ✓ confirmed on air by listeners (KiwiSDR) · HFCC registered by the broadcaster ' +
      '<label title="Show only broadcasts confirmed on air or registered with HFCC"><input type="checkbox" class="drm-conf"' +
      (drmw.confirmed ? ' checked' : '') + '> Confirmed only</label></div>';
    mr.appendChild(w);
    w.querySelector('.drm-sel').onchange = function (e) { drmw.sel = e.target.value; };
    w.querySelector('.drm-conf').onchange = function (e) { drmw.confirmed = e.target.checked; drmw.sel = ''; drmWinFill(); };
    w.querySelector('.drm-go').onclick = function () {
      var khz = Number(String(drmw.sel).split('|')[0]);
      if (!(khz > 0) || xm.kind !== 'drm') return;
      if (window.ubersdr_listener_mode) window.ubersdr_listener_mode();
      xm.switching = true;
      try { setfreqif(khz.toFixed(2)); } catch (e) {} finally { xm.switching = false; }   // the box shows 2 decimals
      drmWinFill();
    };
    var go = function (mod) { drmw.mod = mod; if (drmw.el === w) drmWinFill(); };
    if (drmw.mod) go(drmw.mod);
    else import(new URL('sv1btl/psdr/lib/drmSchedule.js?v=20261106', location.href).href).then(go, function () {
      var d = w.querySelector('.drm-dial'); if (d) d.textContent = 'schedule unavailable';
    });
    drmw.timer = setInterval(drmWinFill, 30000);
  }
  function drmWinClose() {
    clearInterval(drmw.timer); drmw.timer = null;
    if (drmw.el) drmw.el.remove();
    drmw.el = null;
  }
  function drmWinFill() {
    var w = drmw.el, M = drmw.mod;
    if (!w || !M) return;
    var e = (window.bi && bi[0]) || null, now = new Date();
    var minKhz = e ? e.centerfreq - e.samplerate / 2 + 5 : 0, maxKhz = e ? e.centerfreq + e.samplerate / 2 - 5 : Infinity;
    var allRows = M.scheduleRows(M.DRM_SCHEDULE_SNAPSHOT, now, minKhz, maxKhz);
    var rows = drmw.confirmed ? allRows.filter(function (r) { return r.verified || r.registered || r.heard; }) : allRows;
    var locator = (window.STATION && window.STATION.locator) || '';
    var qth = M.gridToLatLon(locator);
    var swOnAir = rows.filter(function (r) { return r.onAir && r.region !== 'MW'; })
      .map(function (r) { return Object.assign({}, r, { far: M.slotRemoteness(r, qth) }); })
      .sort(function (a, b) { return a.far - b.far || a.khz - b.khz; });
    var heardNow = swOnAir.filter(function (r) { return r.heardOnly; });
    var nearNow = qth ? swOnAir.filter(function (r) { return !r.heardOnly && r.far <= M.NEAR_KM; }) : [];
    var swNow = swOnAir.filter(function (r) { return !r.heardOnly && !(qth && r.far <= M.NEAR_KM); });
    var swLater = rows.filter(function (r) { return !r.onAir && r.region !== 'MW' && r.wait < 1440; });
    var mw = rows.filter(function (r) { return r.region === 'MW'; });
    var dial = Number(window.freq) || 0;
    var onSchedule = rows.filter(function (r) { return r.onAir && Math.abs(r.khz - dial) < 0.5; });
    function fmtWait(min) {
      if (min <= 0) return 'on air';
      var h = Math.floor(min / 60), m = min % 60;
      return h ? 'in ' + h + ' h ' + String(m).padStart(2, '0') + ' m' : 'in ' + m + ' m';
    }
    function label(r) {
      return r.khz + ' kHz · ' + r.station + ' · ' + r.start + '–' + r.end + ' UTC' +
        (r.days && r.days !== '1111111' ? ' (' + M.daysText(r.days) + ')' : '') +
        (r.target ? ' → ' + r.target : '') +
        (r.verified ? ' ✓' : '') + (r.registered ? ' · HFCC' : '') + (r.heard ? ' · heard here' : '');
    }
    function keyOf(r) { return r.khz + '|' + r.station + '|' + r.start; }
    if (!drmw.sel && rows.length) {                  // what the dial is on, else the first on air
      var here = rows.find(function (r) { return Math.abs(r.khz - dial) < 0.5; });
      var pick = here || nearNow[0] || swNow[0] || swLater[0] || rows[0];
      if (pick) drmw.sel = keyOf(pick);
    }
    var esc = function (t) { return String(t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
    var html = '';
    function group(title, list, suffix) {
      if (!list.length) return;
      html += '<optgroup label="' + esc(title) + '">' + list.map(function (r) {
        var k = keyOf(r);
        return '<option value="' + esc(k) + '"' + (k === drmw.sel ? ' selected' : '') + '>' + esc(label(r) + (suffix ? suffix(r) : '')) + '</option>';
      }).join('') + '</optgroup>';
    }
    group('Heard on this receiver — on air now, in no schedule', heardNow);
    group('Beamed at this station (' + locator + ') — on air now', nearNow);
    group(qth ? 'On air now — beamed elsewhere, nearest first' : 'On air now', swNow);
    group('Later (next 24 h)', swLater, function (r) { return ' — ' + fmtWait(r.wait); });
    group('Medium wave (India, Asia)', mw, function (r) { return r.onAir ? '' : ' — ' + fmtWait(r.wait); });
    var sel = w.querySelector('.drm-sel');
    if (sel.innerHTML !== html) sel.innerHTML = html;
    var d = w.querySelector('.drm-dial');
    d.innerHTML = 'Dial: <b>' + dial.toFixed(1) + ' kHz</b>' + (onSchedule.length ? '<span style="color:#0a7d2c"> · ' + esc(onSchedule[0].station) + ' on air</span>' : '');
  }

  // DRM frames: 0x02 audio (Opus, as freedv) / 0x03 JSON status, about once a second
  function drmFrame(buf) {
    var b = new Uint8Array(buf);
    if (!b.length) return;
    if (b[0] === 0x03) {
      try { var st = JSON.parse(new TextDecoder().decode(b.subarray(1))); if (st && st.t === 'status') { xm.drmStatus = st; xm.drmAt = Date.now(); drmShow(); } } catch (e) {}
      return;
    }
    if (opusPlay(xm, buf)) xmSignal();
  }
  // Status line, as UberSDR's DRM panel (frame.js progressLabel): searching → synced →
  // station → decoding, with the station label, its text message and the MER (SNR)
  function drmShow() {
    if (xm.kind !== 'drm') return;
    var st = xm.drmStatus, fresh = st && Date.now() - (xm.drmAt || 0) < 5000, t;
    if (!fresh) t = 'DRM: waiting for the decoder…';
    else if (!st.acq) t = 'DRM: searching for a DRM signal…';
    else if (st.fac !== 3) t = 'DRM: signal found, syncing…';
    else if (st.sdc !== 3) t = 'DRM: synced, reading station information…';
    else if (st.audio !== 3) t = 'DRM: station found, audio not decoding yet';
    else t = 'DRM: decoding';
    if (fresh) {
      if (st.service) t += ' · ' + String(st.service).trim() + (st.country ? ' (' + String(st.country).toUpperCase() + ')' : '');
      if (st.acq && typeof st.wmer === 'number') t += ' · MER ' + st.wmer.toFixed(1) + ' dB';
      if (st.text) t += ' · ' + String(st.text).trim().slice(0, 80);
    }
    xmStatus(t, fresh && st.audio === 3 ? 'sync' : '');
  }

  // ── CW decoder window (desktop page; 2026-10-07) ────────────────────────────
  // While the mode is CW (the CW button, CW narrow/wide, a key or CAT software), a
  // window below the Mode buttons shows decoded text. The decoder is PhantomSDR-Plus's
  // (sv1btl/cw-decoder.js: averaged-spectrum tone lock, I/Q envelope, dot-period
  // search, matched filter, dictionary MAP decode), running in this browser on the
  // audio this page receives, in a Web Worker (in the page if Workers are blocked).
  // Like PhantomSDR-Plus it gets the raw received audio, before squelch, AGC boost,
  // notch and NR, so muting or squelch do not stop it. Nothing is sent to the server.
  var CW_MAX_CHARS = 3000;
  var CW_JS = 'sv1btl/cw-decoder.js?v=20261107gh';
  var cwd = { on: false, worker: null, local: null, sr: 0, loading: false, tuned: '', fed: 0,
              browse: false, saved: null, localBr: null, rows: {}, ch: [], archive: [] };
  // CW pitch, as PhantomSDR-Plus's CW window: the audio tone of the CW signal on the shown
  // frequency, 500-800 Hz in 50 Hz steps, default 600, remembered (ubersdr_cwpitch). On
  // this page the tone is the middle of the CW passband, so every CW filter (the CW, CW-N
  // and CW-W buttons, the CW bandwidth presets, the C key, labels, restored positions) is
  // centred on it with its own width, by the setmf wrapper (ubersdr_compat_after_base).
  // Dragging a passband edge still moves only that edge.
  var CW_PITCH_KEY = 'ubersdr_cwpitch', CW_PITCH_DEF = 600;
  function cwPitch() {
    var v = NaN;
    try { v = Number(localStorage.getItem(CW_PITCH_KEY)); } catch (e) {}
    return v >= 500 && v <= 800 && v % 50 === 0 ? v : CW_PITCH_DEF;
  }
  window.ubersdr_cw_pitch_lohi = function (l, h) {       // a CW filter (kHz) centred on the pitch
    var p = cwPitch() / 1000, w = h - l, c = (l + h) <= 0 ? -p : p;
    return [Math.round((c - w / 2) * 10000) / 10000, Math.round((c + w / 2) * 10000) / 10000];
  };
  function cwSetPitch(v) {
    try { localStorage.setItem(CW_PITCH_KEY, String(v)); } catch (e) {}
    var p = cwPanel(false); if (p) p.querySelector('.cw-pv').textContent = v;
    if (String(window.mode || '').toUpperCase() !== 'CW') return;
    var nom = nominalfreq();                             // the same signal, now heard at v Hz
    setmf('cw', lo, hi);
    setfreq(nom - (hi + lo) / 2);
  }
  (function cwStyle() {
    var st = document.createElement('style');
    st.textContent =
      '.cwdec{width:470px;margin:3px auto 4px;box-sizing:border-box;background:#f7f7f7;border:1px solid #bbb;' +
        'border-radius:6px;font:11px/1.3 Arial,sans-serif;color:#222;text-align:left;box-shadow:1px 2px 5px rgba(0,0,0,.15)}' +
      '.cwdec .cw-head{display:flex;align-items:center;gap:8px;padding:3px 6px;background:#dfe6e4;border-radius:6px 6px 0 0}' +
      '.cwdec .cw-title{font-weight:bold;flex:1}' +
      '.cwdec .cw-stat{color:#222}.cwdec .cw-stat b{color:#000}' +
      '.cwdec button{font-size:10px;padding:0 4px;height:17px}' +
      '.cwdec .cw-ps{width:70px;height:12px;margin:0 2px;vertical-align:middle}' +
      '.cwdec .cw-text{height:64px;overflow-y:auto;padding:3px 6px;background:#f7f7f7;color:#000;' +
        'font:13px/16px "Courier New",monospace;white-space:pre-wrap;word-break:break-word}' +
      '.cwdec .cw-status{padding:1px 6px 2px;color:#333;font-style:italic;border-top:1px solid #ddd}' +
      '.cwdec .cw-status.err{color:#c00;font-style:normal}' +
      '.cwdec .cw-pb{max-height:210px;overflow-y:auto;background:#f7f7f7;font:11px/14px "Courier New",monospace}' +
      '.cwdec .br-row{display:flex;align-items:flex-start;gap:6px;padding:1px 4px;border-bottom:1px solid #ddd;cursor:pointer}' +
      '.cwdec .br-row:hover{background:#e3f1ee}.cwdec .br-row .f{flex:none;color:#06305a;font-weight:bold}' +
      '.cwdec .br-row .w{flex:none;width:44px;text-align:right;color:#666}.cwdec .br-row .c{flex:none;width:84px;font-weight:bold;color:#8a6d00}' +
      '.cwdec .br-row .c.cq{color:#0a7a2a}' +
      '.cwdec .br-row .x{flex:1 1 0;min-width:0;max-height:84px;overflow-y:auto;white-space:pre-wrap;overflow-wrap:anywhere;color:#000}' +
      '.cwdec .br-row .ud{flex:none;display:flex;flex-direction:column;line-height:1}' +
      '.cwdec .br-row .ud button{height:12px;padding:0 2px;font-size:9px;border:0;background:none;color:#777;cursor:pointer}' +
      '.cwdec .br-row .ud button:hover{color:#000}.cwdec .br-note{padding:3px 6px;color:#555;font-style:italic}' +
      'html.ubersdr-dark #mainpanel .cwdec .cw-pb{background:#22262a}html.ubersdr-dark #mainpanel .cwdec .br-row{border-color:#3a4046}' +
      'html.ubersdr-dark #mainpanel .cwdec .br-row:hover{background:#2f3d52}html.ubersdr-dark #mainpanel .cwdec .br-row .x{color:#fff}' +
      'html.ubersdr-dark #mainpanel .cwdec .br-row .f{color:#8cc4ff}html.ubersdr-dark #mainpanel .cwdec .br-row .c{color:#f0d060}' +
      'html.ubersdr-dark #mainpanel .cwdec .br-row .c.cq{color:#7fe0a0}html.ubersdr-dark #mainpanel .cwdec .br-note{color:#9aa1a8}';
    (document.head || document.documentElement).appendChild(st);
  })();
  function cwPanel(create) {
    var p = document.getElementById('cwdecoder');
    if (p || !create) return p;
    var anchor = document.getElementById('radestatus');
    if (!anchor || !document.getElementById('wfmode')) return null;   // desktop page only
    p = document.createElement('div');
    p.id = 'cwdecoder'; p.className = 'cwdec'; p.hidden = true;
    p.innerHTML =
      '<div class="cw-head"><span class="cw-title">CW decoder</span>' +
      '<span class="cw-stat cw-one" title="Tone of the CW signal found">≈ <b class="cw-pitch">---</b> Hz</span>' +
      '<span class="cw-stat cw-one"><b class="cw-wpm">---</b> WPM</span>' +
      '<label class="cw-stat cw-one" title="Audio pitch of the CW tone (frequency offset from the dial)">Pitch ' +
        '<input type="range" class="cw-ps" min="500" max="800" step="50"> <b class="cw-pv"></b> Hz</label>' +
      '<label class="cw-stat" title="CW Browser: decode every CW signal between 200 and 3000 Hz at once, one line each (the receiver goes to USB 200-3000 Hz while it runs; your CW mode and filter come back after)">' +
        '<input type="checkbox" class="cw-br"> Browser</label>' +
      '<button type="button" class="cw-save" title="Save the decoded text (CW Browser: every line, also the ones that went quiet)">Save</button>' +
      '<button type="button" class="cw-clear">Clear</button></div>' +
      '<div class="cw-text"></div><div class="cw-pb" hidden></div><div class="cw-status"></div>';
    var rp = document.getElementById('radereporter');
    (rp || anchor).parentNode.insertBefore(p, (rp || anchor).nextSibling);
    p.querySelector('.cw-clear').onclick = function () {
      p.querySelector('.cw-text').textContent = ''; cwd.archive = [];
      if (cwd.browse) cwBrowseRestart();
    };
    p.querySelector('.cw-save').onclick = cwSave;
    p.querySelector('.cw-br').onchange = function (e) { cwBrowse(e.target.checked); };
    var ps = p.querySelector('.cw-ps');
    ps.value = String(cwPitch()); p.querySelector('.cw-pv').textContent = cwPitch();
    ps.oninput = function () { cwSetPitch(Number(ps.value)); };
    return p;
  }
  function cwStatus(t, err) {
    var p = cwPanel(false); if (!p) return;
    var s = p.querySelector('.cw-status'); s.textContent = t || ''; s.className = 'cw-status' + (err ? ' err' : '');
  }
  function cwStats(hz, wpm) {
    var p = cwPanel(false); if (!p) return;
    p.querySelector('.cw-pitch').textContent = hz ? Math.round(hz) : '---';
    p.querySelector('.cw-wpm').textContent = wpm ? Math.round(wpm) : '---';
  }
  function cwText(t) {
    var p = cwPanel(false); if (!p) return;
    var box = p.querySelector('.cw-text'), atEnd = box.scrollTop + box.clientHeight >= box.scrollHeight - 4;
    var last = box.lastChild;
    if (last && last.nodeType === 3 && last.data.length < 500) last.appendData(t);   // few DOM nodes
    else box.appendChild(document.createTextNode(t));
    while (box.textContent.length > CW_MAX_CHARS && box.firstChild) box.removeChild(box.firstChild);
    if (atEnd) box.scrollTop = box.scrollHeight;
  }
  function cwTail() { var p = cwPanel(false); return p ? p.querySelector('.cw-text').textContent.slice(-1) : ''; }
  // The decoder's events, handled as in PhantomSDR-Plus (App.svelte)
  function cwEvent(ev) {
    if (!ev || !cwd.on) return;
    if (ev.type === 'browser') { if (cwd.browse) cwBrowserRows(ev.channels || []); return; }
    if (ev.type === 'browserStatus') { if (cwd.browse) cwStatus(ev.text || ''); return; }
    if (cwd.browse) return;
    if (ev.type === 'char') { cwText(ev.char); cwStatus(''); }
    else if (ev.type === 'word') { var e = cwTail(); if (e && e !== ' ' && e !== '\n') cwText(' '); }
    else if (ev.type === 'freq') { cwStats(ev.hz, ev.wpm); cwStatus(''); }
    else if (ev.type === 'silence') {
      var t = cwTail(); if (t && t !== '\n') cwText('\n');
      cwStats(0, 0); cwStatus('Listening for CW…');
    }
  }
  function cwLocal() {
    if (cwd.local) return;
    if (window.CWDecoder) { cwd.local = new window.CWDecoder({ sampleRate: cwd.sr || 12000, callback: cwEvent }); return; }
    if (cwd.loading) return;
    cwd.loading = true;
    var s = document.createElement('script');
    s.src = CW_JS;
    s.onload = function () { cwd.loading = false; if (cwd.on) cwLocal(); };
    s.onerror = function () { cwd.loading = false; cwStatus('CW decoder could not be loaded', true); };
    document.head.appendChild(s);
  }
  function cwStart() {
    if (cwd.worker || cwd.local) return;
    try {
      var w = cwd.worker = new Worker(CW_JS);
      w.onmessage = function (e) { cwEvent(e.data); };
      w.onerror = function (e) {
        console.error('ubersdr-compat: CW worker failed, decoding in the page', e);
        try { w.terminate(); } catch (x) {}
        if (cwd.worker === w) { cwd.worker = null; if (cwd.on) cwLocal(); }
      };
      w.postMessage({ t: 'init', sampleRate: cwd.sr || 12000 });
    } catch (e) {
      cwd.worker = null;
      cwLocal();
    }
  }
  function cwStop() {
    if (cwd.worker) { try { cwd.worker.postMessage({ t: 'destroy' }); cwd.worker.terminate(); } catch (e) {} }
    cwd.worker = null; cwd.local = null; cwd.localBr = null;
  }
  function cwReset() {
    if (cwd.worker) cwd.worker.postMessage({ t: 'reset', sampleRate: cwd.sr || 12000 });
    else if (cwd.local) cwd.local.reset();
    cwStats(0, 0);
  }
  // Called from _playDecoded with every decoded audio block (raw, before any processing)
  function cwFeed(pcm, sr) {
    if (!pcm || !pcm.length) return;
    cwd.fed += pcm.length;
    if (sr && sr !== cwd.sr) {
      cwd.sr = sr;
      if (cwd.worker) cwd.worker.postMessage({ t: 'sampleRate', sampleRate: sr });
      else if (cwd.local) cwd.local.setSampleRate(sr);
    }
    if (cwd.worker) {
      var copy = new Float32Array(pcm);           // the player still needs its own buffer
      try { cwd.worker.postMessage({ t: 'pcm', pcm: copy, sampleRate: cwd.sr }, [copy.buffer]); } catch (e) {}
    } else if (cwd.local) {
      try { (cwd.localBr || cwd.local).feed(pcm); } catch (e) { console.error('ubersdr-compat: CW decode', e); }
    }
  }
  // ── CW Browser (PhantomSDR-Plus 5.5.0, cwBrowser.js in sv1btl/cw-decoder.js) ──
  // Every CW signal between 200 and 3000 Hz at once, one line each: frequency, speed, the
  // callsign picked out (green with CQ), and the text in a box of about 6 lines that follows
  // new text (its own scrollbar scrolls back; ghost lines, a strong station's keying
  // sidebands, are left out). The receiver goes to USB 200-3000 Hz while it runs; the CW
  // mode and filter come back when it is switched off. A click on a line: that station
  // alone, in CW, with the normal decoder. Save writes every line, also the ones dropped.
  function cwBrowseUI() {
    var p = cwPanel(false); if (!p) return;
    var on = cwd.browse;
    p.querySelector('.cw-br').checked = on;
    p.querySelector('.cw-text').hidden = on;
    p.querySelector('.cw-pb').hidden = !on;
    Array.prototype.forEach.call(p.querySelectorAll('.cw-one'), function (e) { e.style.display = on ? 'none' : ''; });
    p.querySelector('.cw-title').textContent = on ? 'CW Browser · ' + cwd.ch.length + ' signal' + (cwd.ch.length === 1 ? '' : 's') : 'CW decoder';
    if (on && !cwd.ch.length) p.querySelector('.cw-pb').innerHTML = '<div class="br-note">Looking for CW signals between 200 and 3000 Hz… A station appears once its first letters are decoded, a few seconds after it starts.</div>';
  }
  function cwBrowsePost(on) {
    if (cwd.worker) cwd.worker.postMessage({ t: 'browse', on: on });
    else if (cwd.local) {
      cwd.localBr = on && window.CwBrowser ? new window.CwBrowser({ sampleRate: function () { return cwd.sr || 12000; },
        onUpdate: function (ch) { cwEvent({ type: 'browser', channels: ch }); }, onStatus: function (t) { cwEvent({ type: 'browserStatus', text: t }); } }) : null;
      if (!on) cwd.local.reset();
    }
  }
  function cwEntry(c, at) {
    return { at: at, khz: (Number(window.freq) || 0) + c.hz / 1000, wpm: c.wpm, call: c.call, cq: c.cq, text: String(c.text || '').trim() };
  }
  function cwArchiveAll() {
    var at = new Date().toISOString().slice(11, 19);
    cwd.ch.forEach(function (c) { if (c.text && c.text.trim()) cwd.archive.push(cwEntry(c, at)); });
    cwd.archive = cwd.archive.slice(-500);
    cwd.ch = []; cwd.rows = {};
  }
  function cwBrowse(on) {
    on = !!on;
    if (on === cwd.browse || !cwd.on) { cwBrowseUI(); return; }
    try { if (window.ubersdr_listener_mode) window.ubersdr_listener_mode(); } catch (e) {}
    if (on) {
      cwd.saved = { mode: String(window.mode || 'cw').toLowerCase(), lo: Number(window.lo), hi: Number(window.hi) };
      cwd.browse = true; cwd.ch = []; cwd.rows = {};
      cwBrowsePost(true);
      try { set_mode('usb'); setmf('usb', 0.2, 3.0); } catch (e) {}
      cwStatus('');
    } else {
      cwBrowsePost(false);
      cwArchiveAll();
      cwd.browse = false;
      var sv = cwd.saved; cwd.saved = null;
      if (sv) try { set_mode(sv.mode); if (isFinite(sv.lo) && isFinite(sv.hi)) setmf(sv.mode, sv.lo, sv.hi); } catch (e) {}
      cwd.tuned = String(window.freq); cwReset(); cwStatus('Listening for CW…');
    }
    cwBrowseUI();
  }
  function cwBrowseRestart() {
    cwArchiveAll();
    cwBrowsePost(false); cwBrowsePost(true);
    var p = cwPanel(false); if (p) p.querySelector('.cw-pb').innerHTML = '';
    cwBrowseUI();
  }
  // Lines are kept (not rebuilt), so each text box keeps its scroll position
  function cwBrowserRows(ch) {
    var p = cwPanel(false); if (!p) return;
    var box = p.querySelector('.cw-pb'), keep = {}, at = new Date().toISOString().slice(11, 19);
    ch.forEach(function (c) { keep[c.id] = 1; });
    cwd.ch.forEach(function (c) {                    // stations gone quiet: kept for Save
      if (!keep[c.id] && c.text && c.text.trim()) cwd.archive.push(cwEntry(c, at));
      if (!keep[c.id] && cwd.rows[c.id]) { cwd.rows[c.id].remove(); delete cwd.rows[c.id]; }
    });
    cwd.archive = cwd.archive.slice(-500);
    if (!cwd.ch.length && ch.length) box.innerHTML = '';
    cwd.ch = ch;
    ch.forEach(function (c) {
      var r = cwd.rows[c.id];
      if (!r) {
        r = document.createElement('div'); r.className = 'br-row';
        r.innerHTML = '<span class="f"></span><span class="w"></span><span class="c"></span><div class="x"></div>';
        r.dataset.hz = c.hz; cwd.rows[c.id] = r;
      }
      box.appendChild(r);                            // in the browser's order
      var khz = (Number(window.freq) || 0) + c.hz / 1000;
      r.dataset.hz = c.hz;
      r.title = 'Click: decode only this station (CW on ' + khz.toFixed(3) + ' kHz)';
      r.querySelector('.f').textContent = khz.toFixed(3);
      r.querySelector('.w').textContent = c.wpm ? c.wpm + ' wpm' : '';
      var cc = r.querySelector('.c'); cc.textContent = (c.cq && c.call ? 'CQ ' : '') + (c.call || ''); cc.className = 'c' + (c.cq ? ' cq' : '');
      var x = r.querySelector('.x'), t = String(c.text || '').replace(/^\s+/, '');
      if (x.textContent !== t) {
        var end = x.scrollTop + x.clientHeight >= x.scrollHeight - 4;
        x.textContent = t;
        if (end) x.scrollTop = x.scrollHeight;
      }
    });
    if (!ch.length) cwBrowseUI();
    var tt = p.querySelector('.cw-title'); if (tt) tt.textContent = 'CW Browser · ' + ch.length + ' signal' + (ch.length === 1 ? '' : 's');
    // A line's own scrollbar (over six lines of text): a click or drag on it scrolls, it does not
    // pick the station (PhantomSDR-Plus noScrollbarPick)
    box.onmousedown = function (e) { var x = e.target.closest && e.target.closest('.x'); box._onBar = !!(x && e.offsetX >= x.clientWidth); };
    box.onclick = function (e) {
      if (box._onBar) { box._onBar = false; return; }
      var r = e.target.closest('.br-row'); if (!r) return;
      var khz = (Number(window.freq) || 0) + Number(r.dataset.hz) / 1000;
      cwBrowse(false);                               // back to CW, the station on the passband centre
      try { if (window.ubersdr_listener_mode) window.ubersdr_listener_mode(); setfreqif(khz.toFixed(3)); } catch (x) {}
    };
  }
  function cwSave() {
    var lines;
    if (cwd.browse || cwd.archive.length) {
      var at = new Date().toISOString().slice(11, 19);
      lines = cwd.archive.concat(cwd.browse ? cwd.ch.filter(function (c) { return c.text && c.text.trim(); }).map(function (c) { return cwEntry(c, at); }) : [])
        .map(function (e) { return e.at + ' UTC  ' + e.khz.toFixed(3) + ' kHz' + (e.wpm ? '  ' + e.wpm + ' wpm' : '') + (e.call ? '  ' + (e.cq ? 'CQ ' : '') + e.call : '') + '  ' + e.text; });
    } else { var p = cwPanel(false); lines = [p ? p.querySelector('.cw-text').textContent : '']; }
    var a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([lines.join('\n') + '\n'], { type: 'text/plain' }));
    a.download = (cwd.browse || cwd.archive.length ? 'cw-browser-' : 'cw-') + new Date().toISOString().slice(0, 19).replace(/[:T-]/g, '') + '.txt';
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }
  // Follows this page: opens with CW, closes when another mode is chosen; a new
  // frequency starts the decoder afresh (no left-over timing from the last signal)
  function cwFollow() {
    var md = String(window.mode || '').toUpperCase();
    var want = (md === 'CW' || (cwd.browse && md === 'USB')) && !(window.ubersdr_rade_active && window.ubersdr_rade_active());
    if (!want && cwd.browse) { cwArchiveAll(); cwd.browse = false; cwd.saved = null; cwBrowseUI(); }   // another mode chosen: the browser ends
    if (want && !cwd.on) {
      var p = cwPanel(true);
      if (!p) return;
      cwd.on = true; p.hidden = false; cwStats(0, 0);
      cwd.tuned = String(window.freq);
      cwStart();
      cwStatus('Listening for CW…');
    } else if (!want && cwd.on) {
      cwd.on = false; cwStop(); cwStatus('');
      var q = cwPanel(false); if (q) { q.hidden = true; cwBrowseUI(); }
    } else if (cwd.on) {
      var f = String(window.freq);
      if (f !== cwd.tuned) {
        cwd.tuned = f;
        if (cwd.browse) { cwBrowseRestart(); return; }     // new frequency: the browser starts over
        cwReset();
        var t = cwTail(); if (t && t !== '\n') cwText('\n');
        cwStatus('Listening for CW…');
      }
    }
  }
  window.addEventListener('load', function () {
    if (!document.getElementById('wfmode')) return;   // desktop page only
    setInterval(cwFollow, 350);
  });
  window.addEventListener('beforeunload', cwStop);

  // ── Digital-mode decoders (desktop): FT8, FT4, FT2, JS8, WSPR, SSTV, FAX, NAVTEX, RTTY ──
  // PhantomSDR-Plus's decoders, in sv1btl/decoders.js (an ES module) and sv1btl/psdr/.
  window.addEventListener('load', function () {
    if (!document.getElementById('wfmode')) return;   // desktop page only
    var s = document.createElement('script');
    s.type = 'module';
    s.src = 'sv1btl/decoders.js?v=20261107gh';
    s.onerror = function () { console.error('ubersdr-compat: could not load sv1btl/decoders.js'); };
    document.head.appendChild(s);
  });
  // Receive Diversity (PhantomSDR-Plus's combiner, sv1btl/psdr/diversity.js): desktop and mobile
  window.addEventListener('load', function () {
    var d = document.createElement('script');
    d.type = 'module';
    d.src = 'sv1btl/diversity-ui.js?v=20261028agc';
    d.onerror = function () { console.error('ubersdr-compat: could not load sv1btl/diversity-ui.js'); };
    document.head.appendChild(d);
  });

  // ── Centre column grows the panel (desktop) ─────────────────────────────────
  // RW3PS's layout places the centre column with position:absolute and height:93%,
  // so the grey panel takes its height from the left and right columns only and a
  // taller centre (RADE reporter, CW window) spilled out below it. The column now
  // takes its own content height and the panel is kept at least that tall.
  function midFit() {
    var col = document.getElementById('moderow');
    while (col && getComputedStyle(col).position !== 'absolute') col = col.parentElement;
    if (!col || !col.parentElement) return;
    var box = col.parentElement;
    if (col.style.height !== 'auto') col.style.height = 'auto';
    var need = col.offsetTop + col.offsetHeight + 12;
    if (box.style.minHeight !== need + 'px') box.style.minHeight = need + 'px';
  }
  window.addEventListener('load', function () {
    if (!document.getElementById('wfmode')) return;   // desktop page only
    midFit();
    var col = document.getElementById('moderow');
    if (window.ResizeObserver && col) {
      while (col && getComputedStyle(col).position !== 'absolute') col = col.parentElement;
      if (col && col.firstElementChild) new ResizeObserver(midFit).observe(col.firstElementChild);
    }
    setInterval(midFit, 1000);                         // fallback, and after font loading
  });
  window.ubersdr_cw_state = function () { return cwd; };   // for diagnosis

  // ── CAT diagnostic log: open the page with ?catlog ───────────────────────────
  // Shows every frequency and mode change, what made it (a click on the page, or
  // software such as CATSync, with the calling code), and the mode before and after.
  // For finding out how a CAT program drives the page. Off unless ?catlog is in the URL.
  var CATLOG = /[?&]catlog\b/.test(window.location.search);
  var catlogBox = null, catlogLines = [], lastTrusted = { t: 0, what: '' };
  function catlogAdd(text) {
    if (!CATLOG) return;
    var d = new Date(), ts = d.toTimeString().slice(0, 8) + '.' + ('00' + d.getMilliseconds()).slice(-3);
    catlogLines.push(ts + '  ' + text);
    if (catlogLines.length > 300) catlogLines.shift();
    if (!catlogBox && document.body) {
      catlogBox = document.createElement('div');
      catlogBox.style.cssText = 'position:fixed;left:6px;bottom:6px;width:640px;max-width:95vw;height:260px;z-index:100001;' +
        'background:#111;color:#cfc;font:11px/1.35 monospace;border:2px solid #4c4;border-radius:6px;display:flex;flex-direction:column';
      catlogBox.innerHTML = '<div style="padding:3px 6px;background:#262;color:#fff">CAT log (?catlog) — ' +
        '<a href="#" style="color:#ff9" id="catlogsel">select all</a> · <a href="#" style="color:#ff9" id="catlogclr">clear</a></div>' +
        '<pre id="catlogpre" style="margin:0;padding:4px 6px;overflow:auto;flex:1;white-space:pre-wrap"></pre>';
      document.body.appendChild(catlogBox);
      document.getElementById('catlogsel').onclick = function (e) {
        e.preventDefault(); var r = document.createRange(); r.selectNodeContents(document.getElementById('catlogpre'));
        var sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(r);
      };
      document.getElementById('catlogclr').onclick = function (e) { e.preventDefault(); catlogLines = []; catlogAdd('(cleared)'); };
    }
    if (catlogBox) { var pre = document.getElementById('catlogpre'); pre.textContent = catlogLines.join('\n'); pre.scrollTop = pre.scrollHeight; }
  }
  function catlogWho() {
    if (Date.now() - lastTrusted.t < 600) return 'CLICK ' + lastTrusted.what;
    var st = (new Error().stack || '').split('\n').slice(2, 6).map(function (l) {
      return l.replace(/^\s*at\s+/, '').replace(/https?:\/\/[^/]+\//g, '').slice(0, 60);
    }).filter(Boolean).join(' < ');
    return 'SOFTWARE [' + st + ']';
  }
  if (CATLOG) {
    ['mousedown', 'keydown', 'touchstart'].forEach(function (t) {
      document.addEventListener(t, function (e) {
        if (!e.isTrusted) return;
        var el = e.target, id = el && (el.id || el.value || el.textContent || el.tagName);
        lastTrusted = { t: Date.now(), what: t + ':' + String(id).trim().slice(0, 24) };
      }, true);
    });
    window.addEventListener('load', function () {
      ['set_mode', 'setmf', 'setfreq', 'setfreqb', 'setfreqif', 'setfreqm'].forEach(function (name) {
        var orig = window[name];
        if (typeof orig !== 'function') return;
        window[name] = function () {
          var before = window.mode + ' ' + (typeof nominalfreq === 'function' ? nominalfreq() : '');
          var who = catlogWho();
          var r = orig.apply(this, arguments);
          var after = window.mode + ' ' + (typeof nominalfreq === 'function' ? nominalfreq() : '');
          catlogAdd(name + '(' + [].map.call(arguments, function (a) { return JSON.stringify(a); }).join(',') + ')  ' +
                    before + ' -> ' + after + '  ' + who);
          return r;
        };
      });
      catlogAdd('CAT log started — ' + navigator.userAgent.slice(0, 110));
    });
  }

  window.ubersdr_compat_after_base = function () {
    var origBandButtons = window.document_bandbuttons;
    window.document_bandbuttons = function () {
      if (nbands > 1) { origBandButtons(); return; }
      var s = '';
      for (var i = 0; i < HAM_BANDS.length; i++) {
        s += '<button type="button" class="btnBand" name="group1" id="btnHam-' + i +
             '" onclick="ubersdr_gotoband(' + i + ')">' + HAM_BANDS[i][0] + '</button>';
      }
      s += '<button type="button" class="btnBand" name="group1" id="btnHam-all" onclick="wfset(4)" title="whole receiver range">All</button>';
      document.write(s);
    };
    // Returning visitor: restore mode, filter and frequency. The carrier is set directly:
    // tuning through setfreqif/setfreqb would apply RW3PS's automatic mode-per-frequency
    // table (7030 kHz → LSB) and the standard filter. It is applied at start-up and again
    // once the audio has connected, because soundappletstarted2 then re-tunes the page
    // (and passes the carrier where a displayed frequency is expected, which would move a
    // CW signal by (hi+lo)/2). From then on every retune and mode/filter change is saved.
    var origBodyonload = window.bodyonload, posReady = false;
    var restoring = false;
    function applyPos(p) {
      restoring = true;                    // the saved mode is kept, whatever band it is on
      try {
        set_mode(p.mode);
        setmf(p.mode.toLowerCase(), p.lo, p.hi);
        var carrier = p.nom - (iscw() ? (hi + lo) / 2 : 0);
        setwaterfall(band, carrier);
        setfreq(carrier);
      } finally { restoring = false; }
    }
    window.bodyonload = function () {
      origBodyonload.apply(this, arguments);
      if (lastPos) applyPos(lastPos);
      posReady = true;
      bandLight();
    };
    var origSound2 = window.soundappletstarted2, soundRestored = false;
    window.soundappletstarted2 = function () {
      origSound2.apply(this, arguments);
      if (lastPos && !soundRestored) { soundRestored = true; applyPos(lastPos); }
    };
    function savePos() { if (posReady) { window.ubersdr_savepos(nominalfreq(), mode, lo, hi); bandRemember(nominalfreq(), mode, lo, hi); } }
    // Band-plan mode on a band change (CAT sync, e.g. DJ0MY's CATSync): whenever the
    // frequency moves into another amateur band - from this page or from a radio - the
    // band's mode in HAM_BANDS is set (40m LSB, 20m USB, MW AM…). For BAND_MODE_HOLD_MS
    // after that, a different mode set by software (the radio echoing the mode it last had
    // there) is ignored, so the band-plan mode wins and is passed on to the radio. A mode
    // chosen by the visitor (a click on a mode control) always goes through, and within a band
    // any mode is kept (CW, FT8 in USB on 40m…).
    var BAND_MODE_HOLD_MS = 2500, bandHold = { until: 0, mode: '' }, lastHuman = 0, applyingBand = false;
    // only a click on a mode control counts as the visitor choosing a mode: the mode
    // buttons, the filter presets, the RADE buttons and a listener in the users list
    var MODE_CONTROLS = '[id^="btn-"], .btnBandW, .userbtn, #modesel, .decbtn, .dec-sel';   // .decbtn/.dec-sel: sv1btl/decoders.js
    ['pointerdown', 'mousedown', 'touchstart', 'change'].forEach(function (t) {
      document.addEventListener(t, function (e) {
        if (e.isTrusted && e.target && e.target.closest && e.target.closest(MODE_CONTROLS)) lastHuman = Date.now();
      }, true);
    });
    function hamIndex(fk) {
      for (var i = 0; i < HAM_BANDS.length; i++) if (fk >= HAM_BANDS[i][1] && fk <= HAM_BANDS[i][2]) return i;
      return -1;
    }
    var origSetfreq = window.setfreq;
    window.setfreq = function (f) {
      var before = hamIndex(nominalfreq());
      origSetfreq.apply(this, arguments);
      var after = hamIndex(nominalfreq());
      // a running decoder (sv1btl/decoders.js) owns the mode and filter: no band-plan mode
      var decOn = (window.ubersdr_dec_label && window.ubersdr_dec_label()) || xm.kind;
      if (posReady && !restoring && !decOn && after >= 0 && after !== before) {
        var bm = String(HAM_BANDS[after][4]).toUpperCase();
        if (String(window.mode).toUpperCase() !== bm) {
          var nom = nominalfreq();
          applyingBand = true;
          try { set_mode(bm); } finally { applyingBand = false; }
          if (Math.abs(nominalfreq() - nom) > 0.001) origSetfreq(nom - (iscw() ? (hi + lo) / 2 : 0));   // keep the shown frequency (CW)
        }
        bandHold = { until: Date.now() + BAND_MODE_HOLD_MS, mode: bm };
      }
      savePos(); bandLight(); radeFollowTune(); xmFollowTune();
    };
    // sv1btl/decoders.js: a decoder's mode and filter are the listener's choice too
    window.ubersdr_listener_mode = function () { lastHuman = Date.now(); };

    // The Band button (wfset(3), Waterfall Settings) follows the band plan: it zooms to
    // the whole band the shown frequency is in and sets that band's mode, keeping the
    // shown frequency. The band is the amateur band of HAM_BANDS (40m 7000-7200 LSB,
    // 30m CW…), else RW3PS's band-plan segment (modeperfreq in websdr-base.js, read from
    // its source: 41 m 7205-7605 AM…). A running decoder stops (it owns mode and filter).
    // Outside both it zooms as before (±100 kHz) and leaves the mode alone.
    var planSegs = null;
    function planBand(f) {
      for (var i = 0; i < HAM_BANDS.length; i++)
        if (f >= HAM_BANDS[i][1] && f <= HAM_BANDS[i][2]) return [HAM_BANDS[i][1], HAM_BANDS[i][2], HAM_BANDS[i][4]];
      if (!planSegs) {
        planSegs = [];
        var re = /ffff\s*>=?\s*([0-9.]+)\s*&&\s*ffff\s*<\s*([0-9.]+)\s*\)\s*setmf\(\s*["'](\w+)["']/g, m;
        while ((m = re.exec(String(window.modeperfreq || '')))) planSegs.push([+m[1], +m[2], m[3]]);
      }
      var hit = null;
      for (var j = 0; j < planSegs.length; j++) if (f >= planSegs[j][0] && f < planSegs[j][1]) hit = planSegs[j];   // the last wins, as there
      return hit;
    }
    var origWfset = window.wfset;
    window.wfset = function (cmd) {
      if (cmd !== 3) return origWfset.apply(this, arguments);
      var nom = nominalfreq(), pb = planBand(nom), e = bi[band];
      if (!pb || !e) return origWfset.apply(this, arguments);
      try { timeout_idle_restart(); } catch (x) {}
      var width = pb[1] - pb[0], z = 0;                 // same arithmetic as the band buttons
      while (2 * width < e.samplerate && z < e.maxzoom) { z++; width *= 2; }
      wfset_freq(band, z, (pb[0] + pb[1]) / 2);
      try { if (window.ubersdr_decoders && window.ubersdr_decoders.state().on) window.ubersdr_decoders.stop(true); } catch (x) {}
      lastHuman = Date.now();                           // the listener's choice: past the band-mode guard
      set_mode(String(pb[2]).toLowerCase());
      setfreq(nom - (iscw() ? (hi + lo) / 2 : 0));      // the same shown frequency in that mode
    };
    var origSetmf = window.setmf;
    window.setmf = function (m) {
      var now = Date.now();
      if (!applyingBand && now < bandHold.until && now - lastHuman > 1500 &&
          String(m).toUpperCase() !== bandHold.mode) return;      // software echo of the old mode: ignore
      var args = Array.prototype.slice.call(arguments);
      if (String(m).toLowerCase() === 'cw' && isFinite(args[1]) && isFinite(args[2])) {   // centred on the CW pitch
        var c = window.ubersdr_cw_pitch_lohi(+args[1], +args[2]); args[1] = c[0]; args[2] = c[1];
      }
      origSetmf.apply(this, args); savePos(); bandLight(); radeFollowMode(); xmFollowMode();
    };
    // Clicking a listener in the users strip: tune to the exact frequency they are on
    // (the RW3PS click also shifted it by this page's own passband offset) and switch to
    // their mode — sent at the end of their name by these pages; for other clients the
    // amateur band's usual mode, else the current one.
    window.ubersdr_gotouser = function (i) {
      var b = uu_bands[i], e = bi[b];
      if (!e) return;
      var f = uu_freqs[i] * e.samplerate + e.centerfreq - e.samplerate / 2;
      // the position is sent with ~30 Hz steps; these pages also put the exact frequency
      // in the name ("… 7120.00 LSB"), so use that when it matches
      var nf = /\s(\d+\.\d{2})(?:\s(?:CW|LSB|USB|AM|FM))?$/.exec(uu_names[i] || '');
      f = (nf && Math.abs(nf[1] - f) < 1) ? Number(nf[1]) : Math.round(f * 100) / 100;
      var mm = NAME_MODES.exec(uu_names[i] || ''), mo = mm ? mm[1] : null;
      if (!mo) for (var k = 0; k < HAM_BANDS.length; k++) if (f >= HAM_BANDS[k][1] && f <= HAM_BANDS[k][2]) { mo = HAM_BANDS[k][4]; break; }
      if (b !== band) setband(b);
      setwaterfall(band, f);
      setfreq(f);                          // (sets the band-plan mode if the band changes)
      if (mo && mo !== mode) { set_mode(mo); setfreq(f); }   // then the listener's own mode
    };
    var origDouu = window.douu;
    window.douu = function () {
      origDouu.apply(this, arguments);
      for (var i = 0; i < uu_names.length; i++) {
        var d = document.getElementById('user' + i), btn = d && d.querySelector('button');
        if (btn) btn.onclick = (function (n) { return function () { ubersdr_gotouser(n); }; })(i);
      }
    };
    // Station/memory labels only from a quarter zoom (zoom >= maxzoom/4) inwards; further out
    // they would crowd the scale. Below that showdx runs as if "Hide labels" were on.
    var origShowdx = window.showdx;
    window.showdx = function (b) {
      var e = bi[b], keep = hidedx;
      if (e && e.zoom * 4 < e.maxzoom) hidedx = 1;
      try { origShowdx.apply(this, arguments); } finally { hidedx = keep; }
    };
    var origZoomchange = window.zoomchange;
    window.zoomchange = function () { origZoomchange.apply(this, arguments); bandLight(); };
    var origUpdbw = window.updbw;
    window.updbw = function () { origUpdbw.apply(this, arguments); savePos(); };

    // Station labels on the waterfall scale. UberSDR's /~~fetchdx answers in a format
    // (stationinfo=[...]) that websdr-base.js does not read, so the labels come from
    // sv1btl/stationinfo.txt instead, in the original WebSDR format, one per line:
    //   <freq kHz><mode> <text>      e.g.  1188am R. Nikolas (GR)   or   28074usb FT8<br>JT65
    // mode is am/fm/usb/lsb/cw (any case), or a PhantomSDR-Plus markers.json mode (FT8,
    // RTTY-WX, SITOR, MORSE, RADEL, HFDL… see LABEL_MODES): the label then gets that
    // mode's receiver mode and carries the mode name (data-dec) for sv1btl/decoders.js,
    // which starts its decoder on a click. A mode with no decoder here (HFDL, DRM) or an
    // unknown one follows the band plan. Lines starting with # are comments. The file
    // is re-read on each band/zoom change, so edits show after a page reload.
    var LABEL_MODES = { ft8: 'usb', ft4: 'usb', ft2: 'usb', js8: 'usb', wspr: 'usb', fax: 'usb', wefax: 'usb',
      navtex: 'usb', sitor: 'usb', rtty: 'usb', 'rtty-wx': 'usb', psk31: 'usb', olivia: 'usb', mfsk: 'usb',
      bpsk31: 'usb', psk63: 'usb', bpsk63: 'usb', psk125: 'usb', bpsk125: 'usb', qpsk31: 'usb', qpsk63: 'usb',
      qpsk125: 'usb', contestia: 'usb', dsc: 'usb', selcall: 'usb', time: 'usb', dcf77: 'usb', msf: 'usb', rwm: 'usb',
      wwv: 'usb', wwvh: 'usb', fst4w: 'usb', msk144: 'usb', ale: 'usb',
      mfsk16: 'usb', mfsk32: 'usb', mfsk64: 'usb', dominoex: 'usb', thor: 'usb', throb: 'usb', hell: 'usb',
      feldhell: 'usb', mt63: 'usb', packet: 'usb', aprs: 'usb', radeu: 'usb', rade: 'usb', freedv: 'usb',
      radel: 'lsb', morse: 'cw', sstv: 'sb', hfdl: 'bp', drm: 'bp' };
    // The page's band plan for f (kHz): the amateur band's mode, else RW3PS's table
    // (modeperfreq in websdr-base.js, read without letting it change anything)
    function bandplanMode(f) {
      var m = window.ubersdr_bandmode ? window.ubersdr_bandmode(f) : null;
      if (!m && typeof window.modeperfreq === 'function') {
        var orig = window.setmf, wm = window.watermode;     // its calls also set watermode
        window.setmf = function (mo) { m = mo; };
        try { window.modeperfreq(f); } catch (e) {} finally { window.setmf = orig; window.watermode = wm; }
      }
      return m ? String(m).toLowerCase() : (f < 10000 ? 'lsb' : 'usb');
    }
    window.fetchdx = function (b) {
      var e = bi[b];
      var min = e.effcenterfreq - e.effsamplerate / 2, max = e.effcenterfreq + e.effsamplerate / 2;
      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function () {
        if (xhr.readyState !== 4) return;
        dxs = [];
        if (xhr.status === 200) {
          var list = [];
          var lines = xhr.responseText.split(/\r?\n/);
          for (var i = 0; i < lines.length; i++) {
            var m = /^\s*([0-9]+(?:\.[0-9]*)?)\s*([a-zA-Z][a-zA-Z0-9-]*)?\s+(.+?)\s*$/.exec(lines[i]);
            if (!m || lines[i].charAt(0) === '#') continue;
            var f = parseFloat(m[1]);
            if (f < min || f > max) continue;
            var mo = (m[2] || '').toLowerCase(), text = m[3];
            if (!/^(am|fm|usb|lsb|cw)$/.test(mo)) {
              var lm = LABEL_MODES[mo];
              if (lm && lm !== 'bp') text += '<span hidden data-dec="' + mo.toUpperCase() + '"></span>';
              mo = lm === 'sb' ? (f < 10000 ? 'lsb' : 'usb') : (lm && lm !== 'bp' ? lm : bandplanMode(f));
            }
            list.push([f, mo, text]);
          }
          list.sort(function (p, q) { return p[0] - q[0]; });   // showdx expects ascending order
          for (var j = 0; j < list.length; j++) dx(list[j][0], list[j][1], list[j][2]);
        }
        showdx(b);
      };
      xhr.open('GET', 'sv1btl/stationinfo.txt', true);
      xhr.setRequestHeader('Cache-Control', 'no-cache');
      xhr.send(null);
    };

    // Squelch: keep only the on/off. RW3PS's setsquelch also widened the SSB filter
    // (a workaround for the original server's squelch) and did not restore it.
    window.setsquelch = function (a) { if (soundapplet) soundapplet.setparam('squelch=' + Number(a)); };

    // Autonotch: RW3PS asks the server (autonotch=), which UberSDR ignores; run the
    // browser notch instead
    window.setautonotch = function (a) { if (soundapplet && soundapplet.setnotch) soundapplet.setnotch(1, a); };

    // RW3PS looks up the visitor's location on ip-api.com and redirects to a page
    // this site does not have; not wanted here.
    window.ip2geo = function () {};

    // Mouse positions for a horizontally stretched waterfall (see matchWidths below).
    // Everything that tunes or drags — websdr-base.js and UberSDR's websdr-waterfall.js —
    // works in the waterfall's own 1024-pixel space and reads the pointer through
    // getMouseXY, so dividing x by the stretch factor keeps every drag in step with the
    // pointer. Click-to-tune also subtracts the waterfall's on-screen left edge, which
    // has to be divided the same way.
    // With the page fitted to the window (pageZoom, see fitPage) the pointer moves
    // pageZoom screen pixels per page pixel, so that is divided out as well.
    var origGetMouseXY = window.getMouseXY;
    window.getMouseXY = function (e) {
      var p = origGetMouseXY(e);
      return { x: p.x / (wfScale * pageZoom), y: p.y / pageZoom };
    };
    window.useMouseXY = function (e) {
      var pos = getMouseXY(e);
      var coords = scaleobj.offsetParent.getBoundingClientRect();
      setfreq_lim((pos.x - coords.left / (wfScale * pageZoom) - 512) * khzperpixel + centerfreq - (hi + lo) / 2);
      if (initmodeflag == 1) modeperfreq(freq);
      return cancelEvent(e);
    };
    // Type selector: "spectrum" is drawn in the PhantomSDR-Plus style (see specSetType)
    var origWaterfallmode = window.waterfallmode;
    window.waterfallmode = function (m) { specSetType(m, origWaterfallmode); };

    // RW3PS left a resize handler pointing at a function it had commented out
    window.stretch_waterfalls = function () {};
  };

  // ── The desktop page fitted to the window width (2026-10-10) ─────────────────
  // The layout is about PAGE_MARGIN + the controls panel wide (≈1200 px). The whole
  // page is scaled with CSS zoom so that width fills the browser window: smaller on a
  // 1024-1280 px screen, larger on 1920 px, 2K and 4K screens (FIT_MIN..FIT_MAX).
  // Mouse positions are divided by pageZoom where the page code works in page pixels
  // (getMouseXY above, the spectrum crosshair, the frequency digits, the wheel zoom
  // of the waterfall below). Off with ?nofit in the address.
  // FIT_SHARE (2026-10-26): the page takes 90% of the window width, centred.
  var PAGE_MARGIN = 30, FIT_MIN = 0.5, FIT_MAX = 3, FIT_SHARE = 0.9;
  var pageZoom = 1;
  window.ubersdr_pagezoom = function () { return pageZoom; };
  function fitPage() {
    var panel = document.getElementById('mainpanel');
    if (!panel || !panel.offsetWidth || /[?&]nofit\b/.test(location.search)) return;
    document.body.style.maxWidth = (panel.offsetWidth + PAGE_MARGIN) + 'px';
    var z = FIT_SHARE * document.documentElement.clientWidth / (panel.offsetWidth + PAGE_MARGIN);
    z = Math.max(FIT_MIN, Math.min(FIT_MAX, Math.floor(z * 100) / 100));
    if (Math.abs(z - pageZoom) < 0.005) return;
    pageZoom = z;
    document.body.style.zoom = z === 1 ? '' : String(z);
  }
  var fitTimer = null;
  window.addEventListener('resize', function () { clearTimeout(fitTimer); fitTimer = setTimeout(fitPage, 150); });
  // Mouse wheel over the waterfall or the spectrum: zoom only, never scroll the page
  // (2026-10-10). The waterfall script listens for the old DOMMouseScroll/mousewheel
  // events, which do not stop the page from scrolling, and takes the pointer position
  // from offsetX, which is wrong when the page is fitted to the window. So the modern
  // 'wheel' event is handled here: the page does not scroll, the zoom is centred on the
  // pointer, and the old events that may follow are swallowed. Touchpads send many
  // small steps: they are added up to one zoom step per WHEEL_STEP_PX.
  var WHEEL_STEP_PX = 60, wheelAcc = 0;
  function overWaterfall(t) {
    var wd = document.getElementById('wfdiv0');
    return !!(wd && t && t.nodeType === 1 && wd.contains(t));
  }
  document.addEventListener('wheel', function (ev) {
    if (!overWaterfall(ev.target)) return;
    ev.preventDefault(); ev.stopImmediatePropagation();
    var wa = window.waterfallapplet && window.waterfallapplet[0];
    var cv = wfCanvases()[0];
    if (!wa || typeof wa.setzoom !== 'function' || !cv) return;
    var dy = ev.deltaY || 0;
    if (ev.deltaMode === 0) {                    // pixels (touchpad, smooth wheels): add up
      wheelAcc += dy;
      if (Math.abs(wheelAcc) < WHEEL_STEP_PX) return;
      dy = wheelAcc; wheelAcc = 0;
    } else wheelAcc = 0;
    if (!dy) return;
    var r = cv.getBoundingClientRect();
    if (!r.width) return;
    var x = Math.max(0, Math.min(1023, Math.round((ev.clientX - r.left) / r.width * 1024)));
    wa.setzoom(dy < 0 ? -2 : -1, x);            // up: zoom in, down: zoom out
  }, { capture: true, passive: false });
  function oldWheel(ev) {                       // the legacy events of the same turn
    if (!overWaterfall(ev.target)) return;
    ev.preventDefault(); ev.stopImmediatePropagation();
  }
  ['DOMMouseScroll', 'mousewheel', 'MozMousePixelScroll'].forEach(function (n) {
    document.addEventListener(n, oldWheel, { capture: true, passive: false });
  });

  // ── One width for waterfall, users strip and chat: the controls panel's ─────
  // The waterfall is 1024 pixels of data from the server; it is stretched to fit
  // with a CSS transform. The users strip is redrawn at the full width by douu()
  // in websdr-base.js (window.ubersdr_width), so its labels are not stretched.
  var wfScale = 1;

  // The waterfall's canvas box: UberSDR's websdr-waterfall.js numbers it with a counter
  // that keeps going up, so it is #wfcdiv0 after a page load but #wfcdiv1, #wfcdiv2, …
  // once the waterfall has been switched off and on again (2026-10-13).
  function wfcDiv() { return document.querySelector('[id^="wfcdiv"]'); }
  function wfCanvases() { var d = wfcDiv(); return d ? d.querySelectorAll('canvas') : []; }

  function matchWidths() {
    var panel = document.querySelector('.mb[style*="min-width: 1160px"]');
    if (!panel) return true;          // not the desktop page (m.html): nothing to match
    var w = panel.offsetWidth;        // page pixels (not affected by fitting the page to the window)
    if (w <= 1024) return false;
    wfScale = w / 1024;
    window.ubersdr_width = w;
    var frames = document.getElementsByClassName('users-bg');   // waterfall frame and users list
    for (var i = 0; i < frames.length; i++) frames[i].style.width = w + 'px';
    var wfc = document.getElementById('wfcontainer');
    if (wfc) {
      wfc.style.transformOrigin = '0 0';
      wfc.style.transform = 'scaleX(' + wfScale + ')';
    }
    var chat = document.getElementById('chatboxnew');
    if (chat) { chat.style.width = w + 'px'; chat.style.boxSizing = 'border-box'; }
    if (typeof douu === 'function' && window.usersobj) douu();
    return true;
  }
  // The page stays hidden (display:none) until its LESS stylesheet is compiled, so
  // there is nothing to measure at load time; retry until the panel has a width.
  var matchTries = 0;
  function matchWhenVisible() {
    if (!matchWidths() && ++matchTries < 100) setTimeout(matchWhenVisible, 200);
    else fitPage();
  }
  window.addEventListener('load', matchWhenVisible);

  // ── Waterfall brightness / contrast, manual and automatic brightness ─────────
  // The RW3PS colours come from a CSS filter on the waterfall:
  //   brightness(b) contrast(c) url(#svgGradientMap)
  // #svgGradientMap turns each pixel into its luminance and looks that up in a colour
  // table (dark blue → cyan → yellow → red). Auto brightness measures the newest
  // waterfall lines and sets b so that the noise floor sits on dark blue; signals keep
  // their natural range above it (set by the Contrast slider), so a quiet band stays
  // quiet instead of having its noise stretched up to red.
  // 2026-10-28: #svgGradientMap is PhantomSDR-Plus's 'PhantomSDR' map unchanged
  // (phantomsdrData, first 256 rows), dark navy at the bottom; the near-black low end
  // of 2026-10-12 is gone. The 3D spectrum reads the same table.
  // (On 2026-09-29 the waterfall briefly used the spectrum's colours with a colour table
  // rebuilt while listening; that was reverted to this, at the user's request.)

  var WF_NOISE_PCT = 0.50, WF_NOISE_T = 0.15;   // median pixel (the noise floor) → dark blue (was 0.20 until 2026-09-29, 0.10 until 2026-10-13: lighter, then 0.12, 0.14 until 2026-10-26: brighter, 0.17 until 2026-10-27: darker)
  // Auto contrast (2026-09-29): brightness and contrast are fitted together so that
  //   - the noise floor (median pixel) sits on WF_NOISE_T,
  //   - the noise grain (WF_GRAIN_PCT pixel) stays below WF_GRAIN_MAX, so a quiet band
  //     is not stretched into bright speckle,
  //   - strong signals (WF_SIG_PCT pixel) come close to WF_SIG_T (yellow → orange,
  //     short of the saturated red end).
  var WF_GRAIN_PCT = 0.85, WF_GRAIN_MAX = 0.20;   // was 0.22, then 0.20 (2026-10-12, darker background on busy bands), 0.17 until 2026-10-13, then 0.18, 0.19 until 2026-10-26 (brighter), 0.22 until 2026-10-27 (darker)
  var WF_SIG_PCT = 0.997, WF_SIG_T = 0.74;   // 0.70 until 2026-10-26 (brighter)
  var WF_SIG_W = 1.25;   // weight of the signal goal (was 1): signals come out brighter (2026-10-12)
  var WF_C_MIN = 0.8, WF_C_MAX = 3.5;   // was 3: more room to stretch signals away from the noise (2026-10-12)
  // Wide views (all 0–30 MHz, more than WF_WIDE_KHZ across): each pixel covers many kHz,
  // so most pixels hold signals and the 85 % pixel is a signal, not noise grain. There the
  // grain limit is left out (it dimmed the whole picture) and the floor sits a bit higher.
  var WF_WIDE_KHZ = 2000, WF_NOISE_T_WIDE = 0.15;   // was 0.15 (2026-10-12: noise darker on busy views), 0.10 until 2026-10-13, then 0.12, 0.14 until 2026-10-26 (brighter), 0.17 until 2026-10-27 (darker)
  // ... but a softer speckle limit is kept there (weight 3, was none): without it busy
  // stretches came out medium blue
  var WF_GRAIN_MAX_WIDE = 0.28;   // 0.28 until 2026-10-26 (brighter), 0.31 until 2026-10-27 (darker)
  function wfWide() { var e = window.bi && bi[window.band]; return !!(e && e.effsamplerate > WF_WIDE_KHZ); }
  var WF_AUTO_INTERVAL = 4000;                  // ms between measurements once settled (2000 until 2026-10-26: slower)
  var WF_TICK = 250;                            // ms: how often new waterfall lines are looked for

  var wfB = 1, wfC = 1, wfAutoTimer = null;

  function wfFilter() {
    return 'brightness(' + Math.round(wfB * 100) + '%) contrast(' + Math.round(wfC * 100) + '%) url("#svgGradientMap")';
  }
  function wfApply() {
    var f = wfFilter(), divs = document.querySelectorAll('[id^="wfcdiv"]');
    for (var i = 0; i < divs.length; i++) divs[i].style.filter = f;
  }

  function wfShowSliders() {
    var b = document.getElementById('wf-brightness2'), c = document.getElementById('wf-contrast2');
    if (b) b.value = Math.round(wfB * 100);
    if (c) c.value = Math.round(wfC * 100);
  }

  // One colour channel (0..1) through the filter chain up to the colour table lookup.
  function srgbToLinear(x) { return x <= 0.04045 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); }
  function linearToSrgb(y) { return y <= 0.0031308 ? 12.92 * y : 1.055 * Math.pow(y, 1 / 2.4) - 0.055; }
  function bc(x, b, c) {
    x = Math.min(1, x * b);                       // brightness()
    x = (x - 0.5) * c + 0.5;                      // contrast()
    return x < 0 ? 0 : (x > 1 ? 1 : x);
  }
  // Position in the colour table: CSS filter functions work in sRGB; the feColorMatrix
  // (saturate 0) in #svgGradientMap works in linear RGB; the table lookup in sRGB again.
  function tablePos(r, g, b, B, C) {
    var y = 0.213 * srgbToLinear(bc(r, B, C)) + 0.715 * srgbToLinear(bc(g, B, C)) + 0.072 * srgbToLinear(bc(b, B, C));
    return linearToSrgb(y);
  }

  // Colour histogram of the newest waterfall lines (the palette has at most 256 colours).
  // UberSDR's websdr-waterfall.js scrolls the picture up and draws each new line at the
  // bottom, so the bottom rows are the last few seconds; rows above may still show the
  // picture from before a zoom or retune.
  var WF_ROWS = 40;
  function wfHistogram(maxRows) {
    var hist = {}, total = 0;
    var canvases = wfCanvases();   // desktop and mobile page alike
    for (var k = 0; k < canvases.length; k++) {
      var cv = canvases[k];
      if (!cv.width || !cv.height) continue;
      var d;
      var rows = Math.min(maxRows || WF_ROWS, cv.height);
      try { d = cv.getContext('2d').getImageData(0, cv.height - rows, cv.width, rows).data; } catch (e) { continue; }
      for (var i = 0; i < d.length; i += 4 * 2) {          // every 2nd pixel is plenty
        var key = (d[i] << 16) | (d[i + 1] << 8) | d[i + 2];
        if (key === 0) continue;                            // not yet drawn
        hist[key] = (hist[key] || 0) + 1;
        total++;
      }
    }
    var list = [];
    for (var h in hist) list.push([((h >> 16) & 255) / 255, ((h >> 8) & 255) / 255, (h & 255) / 255, hist[h]]);
    return { list: list, total: total };
  }

  // Colour-table positions at brightness B, contrast C of the noise floor (median pixel),
  // the noise grain and the strong signals
  function wfLevels(list, total, B, C) {
    var pts = [];
    for (var i = 0; i < list.length; i++) pts.push([tablePos(list[i][0], list[i][1], list[i][2], B, C), list[i][3]]);
    pts.sort(function (a, b) { return a[0] - b[0]; });
    var want = [WF_NOISE_PCT * total, WF_GRAIN_PCT * total, WF_SIG_PCT * total], out = [], acc = 0, w = 0;
    for (var j = 0; j < pts.length && w < 3; j++) {
      acc += pts[j][1];
      while (w < 3 && acc >= want[w]) { out.push(pts[j][0]); w++; }
    }
    while (out.length < 3) out.push(pts[pts.length - 1][0]);
    return { noise: out[0], grain: out[1], sig: out[2] };
  }
  // How far a setting is from the goals; the dark noise floor matters most. A small
  // preference for normal contrast decides between settings that look about the same
  // (a quiet band has only a few waterfall levels, so many settings score alike).
  function wfCost(L, C) {
    var wide = wfWide();
    return 6 * Math.abs(L.noise - (wide ? WF_NOISE_T_WIDE : WF_NOISE_T)) +   // weight 6, was 4 (2026-10-12, darker background)
           (wide ? 3 * Math.max(0, L.grain - WF_GRAIN_MAX_WIDE) : 6 * Math.max(0, L.grain - WF_GRAIN_MAX)) +
           WF_SIG_W * Math.abs(L.sig - WF_SIG_T) +
           0.05 * Math.abs(Math.log(C));
  }
  var WF_HYST = 0.04;   // a new setting must beat the current one by this much

  // Best brightness 10–500 % and contrast 80–300 % (a zoomed-in waterfall arrives from
  // UberSDR much darker than the full-band view): coarse grid, then a finer one around it
  var WF_B_MIN = 0.1, WF_B_MAX = 5;   // min was 0.3; lowered with WF_NOISE_T (2026-09-29)
  // fixC: search brightness only, at this contrast (the fast start after its first fit)
  function wfBestFit(h, fixC) {
    var best = null;
    function tryBC(B, C) {
      if (B < WF_B_MIN || B > WF_B_MAX) return;
      if (fixC) C = fixC; else if (C < WF_C_MIN || C > WF_C_MAX) return;
      var L = wfLevels(h.list, h.total, B, C), cost = wfCost(L, C);
      if (!best || cost < best.cost) best = { B: B, C: C, cost: cost, noise: L.noise, grain: L.grain, sig: L.sig };
    }
    var i, j, lb = Math.log(WF_B_MIN), rb = Math.log(WF_B_MAX / WF_B_MIN), lc = Math.log(WF_C_MIN), rc = Math.log(WF_C_MAX / WF_C_MIN);
    for (i = 0; i <= 30; i++) for (j = 0; j <= 8; j++) tryBC(Math.exp(lb + rb * i / 30), Math.exp(lc + rc * j / 8));
    var B0 = best.B, C0 = best.C, sb = Math.exp(rb / 30), sc = Math.exp(rc / 8);
    for (i = -4; i <= 4; i++) for (j = -4; j <= 4; j++) tryBC(B0 * Math.pow(sb, i / 4), C0 * Math.pow(sc, j / 4));
    return best;
  }

  // After a zoom, pan or mode change the bottom rows still hold the old picture until
  // new lines replace it. The new lines are counted (the bottom row changes with each
  // one: about 1 line/s here) and only those are measured, so Auto never fits to the old
  // picture. (Until 2026-10-13 it waited a fixed 4.5 s, then measured 40 rows, mostly
  // old ones, and stepped every 2 s: 11 s before the first setting after a page load,
  // and still moving 50 s after a zoom.)
  // Fast start (2026-10-13), after a view change, page load or switching Auto on:
  //   - the first WF_SKIP_LINES lines after a view change are left out (the switch-over
  //     line and a half-drawn one), and for ~6 s after a zoom the noise comes one level
  //     step lower before it settles, so the fast fits look only at the newest
  //     WF_FAST_ROWS lines;
  //   - the first fit comes as soon as WF_FAST_MIN_LINES clean lines are in and is
  //     applied at once; then a fit with every new line, eased in halfway, until
  //     WF_FAST_LINES clean lines are in;
  //   - then the calm regime: every WF_AUTO_INTERVAL, up to WF_ROWS lines, hysteresis.
  var WF_SKIP_LINES = 1, WF_FAST_MIN_LINES = 1, WF_FAST_ROWS = 8, WF_FAST_LINES = 12;   // skip/min were 2 until 2026-10-26: the first fit one line sooner
  var wfViewKey = '', wfNewLines = 0, wfLinesSinceFit = 0, wfFastFits = 0, wfBottomSig = null, wfLastStep = 0;
  function wfCleanLines() { return Math.max(0, wfNewLines - WF_SKIP_LINES); }
  function wfViewChanged() {
    var e = window.bi && window.bi[window.band];
    var key = e ? e.effcenterfreq + '/' + e.effsamplerate + '/' + window.watermode : '';
    if (key === wfViewKey) return false;
    wfViewKey = key;
    return true;
  }
  function wfRestart(fresh) {                   // fresh: count lines from now on
    wfNewLines = fresh ? 0 : WF_SKIP_LINES + WF_FAST_ROWS; wfLinesSinceFit = fresh ? 0 : 1; wfFastFits = 0;
  }
  // A few pixels of the bottom row, to see a new line arrive
  function wfBottomRow() {
    var canvases = wfCanvases();
    for (var k = 0; k < canvases.length; k++) {
      var cv = canvases[k], d, sig = '';
      if (!cv.width || !cv.height) continue;
      try { d = cv.getContext('2d').getImageData(0, cv.height - 1, cv.width, 1).data; } catch (e) { return null; }
      for (var x = 0; x < cv.width; x += 16) sig += d[4 * x] + ',' + d[4 * x + 1] + ',' + d[4 * x + 2] + ';';
      return sig;
    }
    return null;
  }

  function wfTick() {
    if (window.view === 3) return;                              // waterfall off
    if (wfViewChanged()) wfRestart(true);
    var sig = wfBottomRow();
    if (sig !== null && sig !== wfBottomSig) {
      if (wfBottomSig !== null) { wfNewLines++; wfLinesSinceFit++; }
      wfBottomSig = sig;
    }
    var fast = wfFastFits === 0 || wfCleanLines() < WF_FAST_LINES;
    if (fast) { if (wfCleanLines() < WF_FAST_MIN_LINES || !wfLinesSinceFit) return; }
    else if (Date.now() - wfLastStep < WF_AUTO_INTERVAL) return;
    wfAutoStep(fast);
  }

  function wfAutoStep(fast) {
    wfLastStep = Date.now();
    var h = wfHistogram(Math.min(fast ? WF_FAST_ROWS : WF_ROWS, wfCleanLines()));   // only lines of this view
    if (h.total < 1000 || h.list.length < 4) return;           // waterfall still filling
    // fast start: after its first fit only the brightness follows the newest lines; the
    // contrast hangs on the strongest few signals, which jump from line to line, and is
    // left to the calm regime
    var fit = wfBestFit(h, fast && wfFastFits > 0 ? wfC : 0);
    var now = wfLevels(h.list, h.total, wfB, wfC), nowCost = wfCost(now, wfC);
    window.ubersdr_wfauto_last = { fit: fit, now: now, nowCost: nowCost, colours: h.list.length, pixels: h.total,
                                   fast: fast, lines: wfNewLines };
    var k;
    if (fast) {
      k = wfFastFits === 0 ? 1 : 0.5;
      wfFastFits++; wfLinesSinceFit = 0;
    } else {
      // Small corrections are eased in so the picture does not flicker, tiny ones are
      // ignored; when the current setting is clearly off, jump straight to the new one.
      if (fit.cost > nowCost - WF_HYST) return;                // current setting is good enough
      // (2026-10-26: slower once settled, 0.25 / 0.6, were 0.4 / 1)
      var off = Math.max(Math.abs(now.noise - fit.noise), Math.abs(now.sig - fit.sig) / 3);
      k = off > 0.08 ? 0.6 : 0.25;
    }
    wfB = Math.exp((1 - k) * Math.log(wfB) + k * Math.log(fit.B));
    wfC = Math.exp((1 - k) * Math.log(wfC) + k * Math.log(fit.C));
    wfApply();
    wfShowSliders();
  }

  window.ubersdr_wfprobe = { hist: wfHistogram, levels: wfLevels };   // for testing

  function wfSetAuto(on, remember) {
    var cb = document.getElementById('wfautocheckbox');
    if (cb) cb.checked = on;
    if (wfAutoTimer) { clearInterval(wfAutoTimer); wfAutoTimer = null; }
    if (on) {
      wfViewChanged(); wfRestart(false);          // the picture on screen is this view: fit at once
      wfTick();
      wfAutoTimer = setInterval(wfTick, WF_TICK);
    }
    if (remember) try { localStorage.setItem('ubersdr_wfauto', on ? '1' : '0'); } catch (e) {}
  }
  window.ubersdr_wfauto = function (on) { wfSetAuto(!!on, true); };

  // Waterfall switched off and on again: the new canvas box has no colour filter yet
  // (brightness, contrast and the colour table), and Auto starts over on its new lines
  // (from 'load' on: before that #waterfalls still holds the placeholder #wfcdiv8)
  var wfcSeen = null;
  window.addEventListener('load', function () {
    wfcSeen = wfcDiv();
    setInterval(function () {
      var d = wfcDiv();
      if (!d || d === wfcSeen) return;
      wfcSeen = d;
      wfApply();
      wfBottomSig = null; wfRestart(true);
    }, WF_TICK);
  });

  // The RW3PS slider handlers each replaced the whole filter, so moving one slider
  // undid the other; these apply both. Auto sets both sliders, so moving either one
  // switches auto off and leaves the picture where the visitor put it.
  function wfManual(which) {
    wfC = (Number(document.getElementById('wf-contrast2').value) || 100) / 100;
    wfB = (Number(document.getElementById('wf-brightness2').value) || 100) / 100;
    if (wfAutoTimer) wfSetAuto(false, true);
    wfApply();
  }
  window.addEventListener('load', function () {
    window.wfbright = function () { wfManual('b'); };
    window.wfcontrast = function () { wfManual('c'); };
    var saved = null;
    try { saved = localStorage.getItem('ubersdr_wfauto'); } catch (e) {}
    if (saved !== '0') wfSetAuto(true, false);   // on by default; off only if this visitor switched it off
  });

  // ── Spectrum in the PhantomSDR-Plus style (Type = spectrum) ─────────────────
  // Drawn the way sv1btl/PhantomSDR-Plus draws it (frontend/src/waterfall.js,
  // drawSpectrum): black background, fill coloured by HEIGHT with its rainbow map,
  // white trace, a faint grid every 10 dB with labels on the right, 50/50 smoothing
  // between lines, and a dashed crosshair with the frequency on mouse hover.
  // The data is the newest waterfall line: with "spectrum" chosen the waterfall script
  // keeps running (hidden under this canvas), and each new line's colours are turned
  // back into levels with the waterfall's own colour table. So the spectrum always
  // matches what the waterfall would show (zoom, weak/strong signals).
  // UberSDR maps dBFS to levels as (dBFS + calibration + 120) × 255 / 100; the grid is
  // labelled in dBFS with WF_CAL_DB = server.websdr_waterfall_calibration in UberSDR's
  // config.yaml (12 on this receiver).
  // The vertical scale follows the noise floor, as PhantomSDR-Plus's follows its
  // waterfall window: bottom = floor - SPEC_BELOW_DB, top = bottom + SPEC_RANGE_DB.
  var WF_CAL_DB = (typeof STN.waterfallCalibration === 'number') ? STN.waterfallCalibration : 12, SPEC_ALPHA = 0.5, SPEC_BELOW_DB = 3, SPEC_RANGE_DB = 70;   // SPEC_BELOW_DB was 10: the noise now sits at the bottom of the panel (2026-10-06)
  var SPLIT_H = 100;   // spectrum height (px) in Type = spectrum + waterfall
  var spec = { on: false, split: false, canvas: null, ctx: null, row: null, lvl: null, filt: null,
               view: '', hoverX: null, grad: null, gradH: 0, dirty: true, minDb: null };
  function lvlToDb(l) { return l * 100 / 255 - 120 - WF_CAL_DB; }

  // Waterfall colour → level (the standard WebSDR table, as in websdr-waterfall.js);
  // palRGB = [R, G, B] per level, the other way round (for the 3D spectrum)
  var palRGB = null;
  var palIndex = (function () {
    var E = new Uint8Array(256), F = new Uint8Array(256), G = new Uint8Array(256), e, m = {};
    for (e = 0; e < 64; e++) { E[e] = 0; F[e] = 0; G[e] = 2 * e; }
    for (; e < 128; e++) { E[e] = 3 * e - 192; F[e] = 0; G[e] = 2 * e; }
    for (; e < 192; e++) { E[e] = e + 64; F[e] = 256 * Math.sqrt((e - 128) / 64); G[e] = 511 - 2 * e; }
    for (; e < 256; e++) { E[e] = 255; F[e] = 255; G[e] = 512 + 2 * e; }
    for (e = 255; e >= 0; e--) m[(E[e] << 16) | (F[e] << 8) | G[e]] = e;
    palRGB = [E, F, G];
    return m;
  })();

  // PhantomSDR-Plus spectrum colour map (its scStops): 0 = noise floor … 255 = strongest
  var specColormap = (function () {
    var st = [[0, [0, 0, 51]], [1, [0, 0, 77]], [14, [0, 45, 183]], [30, [0, 158, 255]],
              [46, [0, 255, 255]], [92, [255, 255, 0]], [124, [255, 128, 0]],
              [156, [255, 0, 0]], [255, [179, 0, 0]]];
    var out = [];
    for (var i = 0; i < 256; i++) {
      var a = st[0], b = st[st.length - 1];
      for (var k = 0; k < st.length - 1; k++) if (i >= st[k][0] && i <= st[k + 1][0]) { a = st[k]; b = st[k + 1]; break; }
      var f = b[0] > a[0] ? (i - a[0]) / (b[0] - a[0]) : 0;
      out.push([Math.round(a[1][0] + (b[1][0] - a[1][0]) * f), Math.round(a[1][1] + (b[1][1] - a[1][1]) * f),
                Math.round(a[1][2] + (b[1][2] - a[1][2]) * f)]);
    }
    return out;
  })();

  function specBuildGrad(h) {                 // one colour per canvas row, bottom = 0
    var g = new Uint8ClampedArray(h * 4), d = h - 1;
    for (var row = 0; row < h; row++) {
      var t = d > 0 ? (h - 1 - row) / d : 0, x = 255 * t;
      var i0 = Math.max(0, Math.min(255, Math.floor(x))), i1 = Math.min(255, i0 + 1), fr = x - i0;
      var c0 = specColormap[i0], c1 = specColormap[i1];
      g[row * 4] = c0[0] + (c1[0] - c0[0]) * fr;
      g[row * 4 + 1] = c0[1] + (c1[1] - c0[1]) * fr;
      g[row * 4 + 2] = c0[2] + (c1[2] - c0[2]) * fr;
      g[row * 4 + 3] = 255;
    }
    spec.grad = g; spec.gradH = h;
  }

  // Text on this canvas is stretched with the waterfall (see matchWidths); undo that
  function specText(ctx, text, x, y, align) {
    ctx.save(); ctx.translate(x, y); ctx.scale(1 / wfScale, 1);
    ctx.textAlign = align; ctx.fillText(text, 0, 0); ctx.restore();
  }

  function specCanvas() {
    var wfdiv = document.getElementById('wfdiv0'), wfc = wfcDiv();
    if (!wfdiv || !wfc) return null;
    if (!spec.canvas || spec.canvas.parentNode !== wfdiv) {
      // outside #wfcdivN, so the waterfall's colour filter does not recolour it; the
      // mouse passes through to the waterfall (tuning, dragging, wheel zoom)
      var c = document.createElement('canvas');
      c.id = 'ubersdr-spectrum';
      c.style.cssText = 'position:absolute;left:0;top:0;pointer-events:none;z-index:1;display:none;';   // under the passband shade (.vl, z-index 2)
      wfdiv.style.position = 'relative';
      wfdiv.appendChild(c);
      spec.canvas = c; spec.ctx = c.getContext('2d'); spec.dirty = true;
    }
    if (!wfc._ubersdrHover) {                   // crosshair follows the mouse
      wfc._ubersdrHover = true;
      wfc.addEventListener('mousemove', function (ev) {
        var r = wfc.getBoundingClientRect();
        spec.hoverX = (ev.clientX - r.left) / (wfScale * pageZoom); spec.dirty = true;
      });
      wfc.addEventListener('mouseleave', function () { spec.hoverX = null; spec.dirty = true; });
    }
    if (!spec.canvas._ubersdrHover) {           // the panel of spectrum + waterfall
      var sc = spec.canvas;
      sc._ubersdrHover = true;
      sc.addEventListener('mousemove', function (ev) {
        var r = sc.getBoundingClientRect();
        spec.hoverX = (ev.clientX - r.left) / (wfScale * pageZoom); spec.dirty = true;
      });
      sc.addEventListener('mouseleave', function () { spec.hoverX = null; spec.dirty = true; });
      sc.addEventListener('click', function (ev) {   // click on the spectrum tunes there
        if (spec.split) tuneAtClientX(sc, ev.clientX);
      });
    }
    specLayout(wfdiv, wfc);
    var w = 1024, h = spec.split ? SPLIT_H : (wfc.clientHeight || 100);
    if (spec.canvas.width !== w || spec.canvas.height !== h) {
      spec.canvas.width = w; spec.canvas.height = h; spec.dirty = true;
    }
    return spec.canvas;
  }

  // Frequency under the mouse: x across element el, which must span exactly the view
  // (the spectrum canvas or the waterfall canvas — not #wfcdivN, which is wider than the
  // picture and the frequency scale)
  function freqAtClientX(el, clientX) {
    var e = window.bi && bi[window.band];
    if (!e) return null;
    var r = el.getBoundingClientRect();
    if (!r.width) return null;
    return e.effcenterfreq - e.effsamplerate / 2 + (clientX - r.left) / r.width * e.effsamplerate;
  }
  // A click tunes to the nearest whole or half kHz, by the hundredths of the displayed
  // frequency: .00–.40 → .00, .41–.60 → .50, .61–.99 → the next whole kHz
  // (7100.40 → 7100.00, 7100.41 → 7100.50, 7100.61 → 7101.00).
  function snapKHz(f) {
    var h = Math.round(f * 100), k = Math.floor(h / 100), c = h - k * 100;
    return c <= 40 ? k : (c <= 60 ? k + 0.5 : k + 1);
  }
  function tuneTo(f) {
    if (f === null) return;
    f = snapKHz(f);                           // the displayed frequency
    if (iscw()) f -= (hi + lo) / 2;           // CW: the carrier sits beside it
    setfreq(Math.round(f * 1000) / 1000);
  }
  function tuneAtClientX(el, clientX) { tuneTo(freqAtClientX(el, clientX)); }

  // Desktop page: a click on the waterfall tunes there, like a click on the spectrum.
  // The waterfall script uses a mouse press to start dragging the view, so only a press
  // released without moving (under 4 px) counts as a click; dragging and wheel zoom stay.
  // (On the mobile page tuning is done by dragging the waterfall, so it is left alone.)
  window.addEventListener('load', function () {
    if (!document.getElementById('wfmode')) return;           // not the desktop page
    var down = null;
    document.addEventListener('mousedown', function (ev) {
      var wfc = wfcDiv(), cv = wfc && wfc.querySelector('canvas');
      if (ev.button !== 0 || !cv || !wfc.contains(ev.target)) { down = null; return; }
      // the frequency is taken now, before the waterfall script starts moving the view
      down = { x: ev.clientX, y: ev.clientY, f: freqAtClientX(cv, ev.clientX) };
    }, true);
    document.addEventListener('mouseup', function (ev) {
      var d = down; down = null;
      if (!d || ev.button !== 0) return;
      if (Math.abs(ev.clientX - d.x) > 4 || Math.abs(ev.clientY - d.y) > 4) return;   // a drag
      tuneTo(d.f);
    }, true);
  });

  // ── Frequency display: tune digit by digit (desktop page) ────────────────────
  // Over a digit of the big frequency display: the mouse wheel steps the frequency by
  // that digit's place (7120.00: the "1" = 100 kHz, the last "0" = 0.01 kHz), a left
  // click steps it up and a right click down. The digit under the mouse is underlined.
  // A click on the free space beside the digits still lets you type a frequency; while
  // typing, the digits do not step.
  window.addEventListener('load', function () {
    if (!document.getElementById('wfmode')) return;           // not the desktop page
    var inp = document.freqform && document.freqform.frequency;
    if (!inp || !inp.parentNode) return;
    var box = inp.parentNode;
    if (getComputedStyle(box).position === 'static') box.style.position = 'relative';
    var bar = document.createElement('div');
    bar.style.cssText = 'position:absolute;height:3px;background:#98ffee;border-radius:2px;' +
      'box-shadow:0 0 6px #98ffee;pointer-events:none;display:none;z-index:2;';
    box.appendChild(bar);
    inp.title = 'Mouse wheel or click on a digit: left click = up, right click = down.\n' +
                'Click beside the digits to type a frequency.';
    var mctx = document.createElement('canvas').getContext('2d');

    // the digit under the mouse: its place value (kHz) and its left/right edge in px
    function digitAt(clientX) {
      var v = inp.value, dot = v.indexOf('.');
      if (!/^\d+(\.\d+)?$/.test(v)) return null;
      if (dot < 0) dot = v.length;
      var cs = getComputedStyle(inp);
      mctx.font = cs.fontStyle + ' ' + cs.fontWeight + ' ' + cs.fontSize + ' ' + cs.fontFamily;
      var r = inp.getBoundingClientRect(), z = pageZoom;
      clientX = (clientX - r.left) / z;                               // page pixels from the field's left edge
      var padL = parseFloat(cs.paddingLeft) || 0, padR = parseFloat(cs.paddingRight) || 0;
      var bl = parseFloat(cs.borderLeftWidth) || 0, br = parseFloat(cs.borderRightWidth) || 0;
      var inner = r.width / z - padL - padR - bl - br, tw = mctx.measureText(v).width;
      var x0 = bl + padL + Math.max(0, (inner - tw) / 2);   // text-align: center
      for (var i = 0, x = x0; i < v.length; i++) {
        var w = mctx.measureText(v[i]).width;
        if (clientX >= x && clientX < x + w) {
          if (i === dot) return null;
          var place = i < dot ? Math.pow(10, dot - 1 - i) : Math.pow(10, dot - i);
          return { step: place, left: x, width: w };
        }
        x += w;
      }
      return null;
    }
    function typing() { return document.activeElement === inp; }
    function show(d) {
      if (!d || typing()) { bar.style.display = 'none'; return; }
      var ir = inp.getBoundingClientRect(), br = box.getBoundingClientRect();
      bar.style.left = ((ir.left - br.left) / pageZoom + d.left + 1) + 'px';
      bar.style.width = Math.max(4, d.width - 2) + 'px';
      bar.style.top = ((ir.bottom - br.top) / pageZoom - 12) + 'px';
      bar.style.display = 'block';
    }
    function step(kHz) {
      var e = bi[band], f = Math.round((nominalfreq() + kHz) * 100) / 100;
      var fmin = e.centerfreq - e.samplerate / 2, fmax = e.centerfreq + e.samplerate / 2;
      if (f < fmin || f > fmax) return;
      var carrier = f - (iscw() ? (hi + lo) / 2 : 0);
      setwaterfall(band, carrier);            // follow with the view only if it goes off-screen
      setfreq(Math.round(carrier * 1000) / 1000);
    }
    inp.addEventListener('mousemove', function (ev) {
      var d = typing() ? null : digitAt(ev.clientX);
      inp.style.cursor = d ? 'pointer' : '';
      show(d);
    });
    inp.addEventListener('mouseleave', function () { bar.style.display = 'none'; inp.style.cursor = ''; });
    inp.addEventListener('wheel', function (ev) {
      if (typing()) return;
      var d = digitAt(ev.clientX);
      if (!d || !ev.deltaY) return;
      ev.preventDefault();                     // do not scroll the page
      step(ev.deltaY < 0 ? d.step : -d.step);
      show(digitAt(ev.clientX));               // the text may have changed length
    }, { passive: false });
    inp.addEventListener('mousedown', function (ev) {
      if (typing() || (ev.button !== 0 && ev.button !== 2)) return;
      var d = digitAt(ev.clientX);
      if (!d) return;                          // beside the digits: normal typing
      ev.preventDefault();                     // no text cursor, no focus
      step(ev.button === 0 ? d.step : -d.step);
      show(digitAt(ev.clientX));
    });
    inp.addEventListener('contextmenu', function (ev) {
      if (!typing() && digitAt(ev.clientX)) ev.preventDefault();   // right click steps down
    });
    inp.addEventListener('focus', function () { bar.style.display = 'none'; });
  });

  // Spectrum over the waterfall (Type = spectrum), or a panel above a waterfall flipped
  // to run from the top down (Type = spectrum + waterfall: newest line under the
  // spectrum). The flip is only CSS: the waterfall script still draws as usual.
  function specLayout(wfdiv, wfc) {
    var c = spec.canvas, want = spec.split ? 'split' : 'over';
    if (c._layout === want) return;
    c._layout = want;
    vlSpan(spec.split);
    if (spec.split) {
      c.style.position = 'relative'; c.style.pointerEvents = 'auto'; c.style.cursor = 'crosshair';
      c.style.height = SPLIT_H + 'px';
      wfdiv.insertBefore(c, wfc);
      wfc.style.transform = 'scaleY(-1)';
    } else {
      c.style.position = 'absolute'; c.style.pointerEvents = 'none'; c.style.cursor = '';
      c.style.height = '';
      wfc.style.transform = '';
    }
    spec.dirty = true;
  }
  // The transparent passband shade (.vl, under the yellow bar) covers the waterfall;
  // with Type = spectrum + waterfall it is made taller so it covers the spectrum too.
  function vlSpan(on) {
    if (!document.getElementById('ubersdr-vl-style')) {
      var st = document.createElement('style');
      st.id = 'ubersdr-vl-style';
      st.textContent = 'body.ubersdr-split .vl{height:' + (100 + SPLIT_H) + 'px;top:' + (-117 - SPLIT_H) + 'px}';
      document.head.appendChild(st);
    }
    document.body.classList.toggle('ubersdr-split', !!on);
  }
  function specHide() {
    vlSpan(false);
    var ln = document.getElementById('ubersdr-wf-cursor');
    if (ln) ln.style.display = 'none';
    if (!spec.canvas) return;
    spec.canvas.style.display = 'none';
    var wfc = wfcDiv();
    if (wfc && spec.canvas._layout === 'split') wfc.style.transform = '';
    spec.canvas._layout = null;
  }

  // Newest waterfall line → levels; true when it is a new line
  function specReadLine() {
    var cv = wfCanvases()[0];
    if (!cv || !cv.height) return false;
    var d;
    try { d = cv.getContext('2d').getImageData(0, cv.height - 1, cv.width, 1).data; } catch (e) { return false; }
    var n = cv.width, i, same = spec.row && spec.row.length === d.length;
    if (same) for (i = 0; i < d.length; i += 16) if (d[i] !== spec.row[i] || d[i + 2] !== spec.row[i + 2]) { same = false; break; }
    if (same) return false;
    spec.row = new Uint8ClampedArray(d);
    if (!spec.lvl || spec.lvl.length !== n) { spec.lvl = new Float32Array(n); spec.filt = null; }
    for (i = 0; i < n; i++) {
      var v = palIndex[(d[4 * i] << 16) | (d[4 * i + 1] << 8) | d[4 * i + 2]];
      if (v !== undefined) spec.lvl[i] = v;          // a blended pixel (zoom in progress): keep the last level
    }
    var e = window.bi && bi[window.band], view = e ? e.effcenterfreq + '/' + e.effsamplerate : '';
    var fresh = !spec.filt || view !== spec.view;
    if (fresh) { spec.filt = new Float32Array(spec.lvl); spec.view = view; }
    else for (i = 0; i < n; i++) spec.filt[i] = SPEC_ALPHA * spec.lvl[i] + (1 - SPEC_ALPHA) * spec.filt[i];
    // noise floor = median level; ease the scale towards it (jump after a retune/zoom)
    var sorted = Array.prototype.slice.call(spec.filt).sort(function (a, b) { return a - b; });
    var want = lvlToDb(sorted[sorted.length >> 1]) - SPEC_BELOW_DB;
    spec.minDb = (fresh || spec.minDb === null || Math.abs(want - spec.minDb) > 15) ? want : 0.9 * spec.minDb + 0.1 * want;
    return true;
  }

  function specDraw() {
    var c = spec.canvas, ctx = spec.ctx, w = c.width, h = c.height, arr = spec.filt, x, row;
    var minDb = spec.minDb !== null ? spec.minDb : -130, span = SPEC_RANGE_DB;
    function yOf(l) { return h - ((lvlToDb(l) - minDb) / span) * h; }
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
    if (arr) {
      if (!spec.grad || spec.gradH !== h) specBuildGrad(h);
      var img = ctx.createImageData(w, h), px = img.data, g = spec.grad, n = arr.length;
      new Uint32Array(px.buffer).fill(0xff000000);     // opaque black above the curve
      for (x = 0; x < w; x++) {
        var top = Math.max(0, Math.floor(yOf(arr[Math.min(n - 1, Math.floor(x * n / w))])));
        for (row = top; row < h; row++) {
          var o = (row * w + x) * 4, q = row * 4;
          px[o] = g[q]; px[o + 1] = g[q + 1]; px[o + 2] = g[q + 2]; px[o + 3] = 255;
        }
      }
      ctx.putImageData(img, 0, 0);
    }
    // dB grid (dBFS), labels on the right
    ctx.font = '9px monospace';
    for (var dB = Math.ceil(minDb / 10) * 10; dB <= minDb + span; dB += 10) {
      var y = Math.round(h - ((dB - minDb) / span) * h) + 0.5;
      ctx.strokeStyle = 'rgba(255,255,255,0.22)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
      var label = String(dB), tw = ctx.measureText(label).width / wfScale;
      ctx.fillStyle = 'rgba(0,0,0,0.55)';
      ctx.fillRect(w - 4 - tw - 2, Math.max(y - 10, 0), tw + 4, 11);
      ctx.fillStyle = 'rgba(210,210,210,0.9)';
      specText(ctx, label, w - 4, Math.max(y - 2, 9), 'right');
    }
    // trace
    if (arr) {
      ctx.beginPath();
      for (x = 0; x < arr.length; x++) {
        var yy = yOf(arr[x]), xx = x * w / arr.length;
        if (x) ctx.lineTo(xx, yy); else ctx.moveTo(xx, yy);
      }
      ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 1; ctx.stroke();
    }
    // hover crosshair and frequency
    if (spec.hoverX !== null && window.bi && bi[window.band]) {
      var e = bi[band], f = e.effcenterfreq - e.effsamplerate / 2 + spec.hoverX / 1024 * e.effsamplerate;
      ctx.strokeStyle = 'rgba(255,240,80,0.6)'; ctx.setLineDash([4, 3]);
      ctx.beginPath(); ctx.moveTo(spec.hoverX, 0); ctx.lineTo(spec.hoverX, h); ctx.stroke(); ctx.setLineDash([]);
      ctx.font = '11px monospace'; ctx.fillStyle = 'rgba(255,255,180,0.95)';
      specText(ctx, (f / 1000).toFixed(6) + ' MHz', 10, 15, 'left');
    }
  }

  function specLoop() {
    requestAnimationFrame(specLoop);
    if (!spec.on) { specHide(); v3Hide(); return; }
    if (!specCanvas()) return;
    spec.canvas.style.display = 'block';
    var fresh = specReadLine();
    if (fresh) spec.dirty = true;
    v3Frame(fresh);                             // the 3D spectrum, when switched on, in its place
    if (spec.dirty) { spec.dirty = false; if (!v3.on) specDraw(); specWfLine(); }
  }

  // With Type = spectrum + waterfall the dashed hover line carries on down the
  // waterfall, as in PhantomSDR-Plus (App.svelte .waterfall-cursor-line). It is a
  // div over the waterfall in #wfdiv0, which is stretched with it (wfScale), so its
  // left is in the waterfall's own 1024 pixels like spec.hoverX.
  function specWfLine() {
    var wfdiv = document.getElementById('wfdiv0'), wfc = wfcDiv();
    var ln = document.getElementById('ubersdr-wf-cursor');
    if (!ln && wfdiv) {
      ln = document.createElement('div');
      ln.id = 'ubersdr-wf-cursor';
      ln.style.cssText = 'position:absolute;width:1px;pointer-events:none;z-index:3;display:none;' +
        'background:repeating-linear-gradient(to bottom,rgba(255,240,80,0.6) 0 4px,transparent 4px 7px);';
      wfdiv.appendChild(ln);
    }
    if (!ln) return;
    if (!spec.on || !spec.split || spec.hoverX === null || !wfc) { ln.style.display = 'none'; return; }
    ln.style.left = spec.hoverX + 'px';
    ln.style.top = wfc.offsetTop + 'px';
    ln.style.height = wfc.offsetHeight + 'px';
    ln.style.display = 'block';
  }
  window.addEventListener('load', function () { requestAnimationFrame(specLoop); });

  // ── 3D spectrum (2026-10-26) ─────────────────────────────────────────────────
  // The last spectrum lines stacked in relief, as in PhantomSDR-Plus
  // (frontend/src/lib/Waterfall3D.svelte, from PhantomSDR-ORSAT by F1NSK, GPLv3):
  // frequency across, time into the screen, level as height. Switched with the "3D"
  // switch beside "Tube & Waterfall & DSP & Audio" (remembered in localStorage
  // 'ubersdr_spec3d'); it takes the place and the size of the 2D spectrum above
  // (#ubersdr-spectrum), so it shows with Type = spectrum or spectrum + waterfall.
  // It shows exactly what the waterfall shows: its lines are the waterfall's own levels
  // (spec.lvl), stored as they are, and turned into colour and height at drawing time
  // through the waterfall's brightness and contrast (wfB, wfC: Auto or the sliders) and
  // its colour table (#svgGradientMap): v3Luts. So a change of brightness, by Auto or
  // by hand, recolours the waterfall and the whole 3D history alike, at once, and every
  // point has the colour of the same level in the waterfall. Drawn by the GPU (WebGL2): the
  // history is a circular W×H texture, one row per line, and every row keeps the
  // frequency range it was received with, so zoom and pan do not smear the history.
  // The front row lines up with the waterfall: in spectrum + waterfall a click tunes
  // to the frequency under the pointer (on a back row: the frequency of that row).
  var V3_KEY = 'ubersdr_spec3d', V3_GEOM_KEY = 'ubersdr_spec3d_geom';
  var V3_W = 1024, V3_H = 320;            // history: points per line, lines
  var V3_AMP = 1.3, V3_ANGLE0 = 1.5, V3_DEPTH0 = 0.5, V3_SHARPEN = 0.7, V3_HPOW = 2;
  var v3 = { on: false, failed: false, canvas: null, overlay: null, tools: null, geomBox: null,
             gl: null, prog: null, vao: null, nIdx: 0, histTex: null, rangeTex: null, cmapTex: null, u: {},
             hist: new Uint8Array(V3_W * V3_H * 2), ranges: new Float64Array(V3_H * 2),
             times: new Float64Array(V3_H), head: 0, ref: 0, prev: new Float32Array(V3_W), havePrev: false,
             prevView: '', viewL: 0, viewR: 0, angle: V3_ANGLE0, depth: V3_DEPTH0,
             K: 0, BACKH: 0, RISE: 0, angleMax: 1.6, lastMarks: 0, dirty: true };
  try {
    var g3 = JSON.parse(localStorage.getItem(V3_GEOM_KEY) || 'null');
    if (g3 && g3.angle >= 0.3 && g3.angle <= 1.6) v3.angle = g3.angle;
    if (g3 && g3.depth >= 0 && g3.depth <= 1) v3.depth = g3.depth;
  } catch (e) {}
  function v3Geom() {
    v3.K = Math.max(0.6 * v3.depth, 0.01);
    v3.BACKH = 1 - v3.depth;
    v3.angleMax = Math.max(0.3, Math.min(1.6, 2 - V3_AMP * v3.BACKH / (1 + v3.K)));
    if (v3.angle > v3.angleMax) v3.angle = v3.angleMax;
    v3.RISE = v3.angle;
    v3.lastMarks = 0; v3.dirty = true;
    try { localStorage.setItem(V3_GEOM_KEY, JSON.stringify({ angle: v3.angle, depth: v3.depth })); } catch (e) {}
  }
  v3Geom();
  function v3sOf(d) { return 1 / (1 + v3.K * d); }
  function v3AmpOf(d) { return V3_AMP * v3sOf(d) * (1 + (v3.BACKH - 1) * d); }
  function v3GroundOf(d) { return -1 + v3.RISE * (1 - v3sOf(d)) / (1 - v3sOf(1)); }

  var V3_VS = '#version 300 es\n' +
    'in vec2 aUV;\n' +
    'uniform highp usampler2D uHist;\n' +
    'uniform highp sampler2D uRange;\n' +   // per row: range [L, R] (kHz from v3.ref)
    'uniform highp sampler2D uHgt;\n' +     // raw level → height level (0-1), see v3Luts
    'uniform int uHead;\n' +
    'uniform vec2 uView;\n' +
    'uniform float uRise, uK, uBackH, uAmp;\n' +
    'flat out int vIdx;\n' +
    'ivec2 sampleAt(float u, int age) {\n' +
    '  int row = (uHead - age + ' + V3_H + ') % ' + V3_H + ';\n' +
    '  vec2 rr = texelFetch(uRange, ivec2(row, 0), 0).rg;\n' +
    '  if (!(rr.y > rr.x)) return ivec2(0);\n' +
    '  if (rr.y - rr.x > 1.5 * (uView.y - uView.x)) return ivec2(0);\n' +   // recorded much wider: floor
    '  float t = (uView.x + u * (uView.y - uView.x) - rr.x) / (rr.y - rr.x);\n' +
    '  if (t < 0.0 || t >= 1.0) return ivec2(0);\n' +
    '  int x = int(t * float(' + V3_W + '));\n' +
    '  return ivec2(texelFetch(uHist, ivec2(min(x, ' + (V3_W - 1) + '), row), 0).rg);\n' +
    '}\n' +
    'void main() {\n' +
    '  int age = int(aUV.y * float(' + (V3_H - 1) + ') + 0.5);\n' +
    '  float d = aUV.y;\n' +
    '  float s = 1.0 / (1.0 + uK * d);\n' +
    '  float sx = (aUV.x * 2.0 - 1.0) * s;\n' +
    '  ivec2 hc = sampleAt(aUV.x, age);\n' +
    '  float hv = texelFetch(uHgt, ivec2(hc.x, 0), 0).r;\n' +
    '  float sBack = 1.0 / (1.0 + uK);\n' +
    '  float ground = -1.0 + uRise * (1.0 - s) / (1.0 - sBack);\n' +
    '  float y = ground + pow(hv, ' + V3_HPOW.toFixed(1) + ') * uAmp * s * mix(1.0, uBackH, d);\n' +
    '  vIdx = hc.y;\n' +
    '  gl_Position = vec4(sx, y, d * 0.98, 1.0);\n' +
    '}';
  var V3_FS = '#version 300 es\n' +
    'precision mediump float;\n' +
    'flat in int vIdx;\n' +
    'uniform sampler2D uCmap;\n' +          // raw level → the waterfall's colour, see v3Luts
    'out vec4 frag;\n' +
    'void main() {\n' +
    '  frag = vec4(texelFetch(uCmap, ivec2(vIdx, 0), 0).rgb, 1.0);\n' +
    '}';

  function v3InitGL() {
    var gl = v3.canvas.getContext('webgl2', { antialias: false, alpha: false });
    if (!gl) throw new Error('WebGL2 unavailable');
    function sh(type, src) {
      var s = gl.createShader(type);
      gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
      return s;
    }
    var prog = gl.createProgram();
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, V3_VS));
    gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, V3_FS));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
    ['uHist', 'uCmap', 'uHgt', 'uRange', 'uView', 'uHead', 'uRise', 'uK', 'uBackH', 'uAmp'].forEach(function (n) {
      v3.u[n] = gl.getUniformLocation(prog, n);
    });
    // V3_W × V3_H mesh (u, v) and its triangles
    var uv = new Float32Array(V3_W * V3_H * 2), i, j, k;
    for (j = 0, k = 0; j < V3_H; j++)
      for (i = 0; i < V3_W; i++) { uv[k++] = i / (V3_W - 1); uv[k++] = j / (V3_H - 1); }
    var idx = new Uint32Array((V3_W - 1) * (V3_H - 1) * 6);
    for (j = 0, k = 0; j < V3_H - 1; j++)
      for (i = 0; i < V3_W - 1; i++) {
        var a = j * V3_W + i, b = a + 1, c = a + V3_W, d = c + 1;
        idx[k++] = a; idx[k++] = c; idx[k++] = b; idx[k++] = b; idx[k++] = c; idx[k++] = d;
      }
    v3.nIdx = idx.length;
    v3.vao = gl.createVertexArray();
    gl.bindVertexArray(v3.vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
    gl.bufferData(gl.ARRAY_BUFFER, uv, gl.STATIC_DRAW);
    var loc = gl.getAttribLocation(prog, 'aUV');
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, gl.createBuffer());
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, gl.STATIC_DRAW);
    function tex() {
      var t = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      return t;
    }
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
    v3.histTex = tex();      // [height, colour] per point, 0-255
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RG8UI, V3_W, V3_H, 0, gl.RG_INTEGER, gl.UNSIGNED_BYTE, v3.hist);
    v3.rangeTex = tex();
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RG32F, V3_H, 1, 0, gl.RG, gl.FLOAT, new Float32Array(V3_H * 2));
    v3.cmapTex = tex();      // raw level → colour, and → height: filled by v3Luts
    v3.hgtTex = tex();
    // the waterfall's colour table (#svgGradientMap feFuncR/G/B)
    var fm = document.getElementById('svgGradientMap');
    v3.wfTable = ['feFuncR', 'feFuncG', 'feFuncB'].map(function (nm) {
      var el = fm && fm.querySelector(nm), tv = el ? el.getAttribute('tableValues').split(/[\s,]+/).filter(Boolean).map(Number) : [];
      return tv.length ? tv : [0, 1];
    });
    v3.v3LutKey = '';
    gl.enable(gl.DEPTH_TEST);
    gl.clearColor(0, 0, 0, 1);
    v3.gl = gl; v3.prog = prog;
  }

  // The canvas, the marks overlay and the ⚙ angle/depth tools, in #wfdiv0 over the 2D spectrum
  function v3Elements() {
    var wfdiv = document.getElementById('wfdiv0');
    if (!wfdiv) return false;
    if (v3.canvas && v3.canvas.parentNode === wfdiv) return true;
    var c = document.createElement('canvas');
    c.id = 'ubersdr-spectrum3d';
    c.style.cssText = 'position:absolute;left:0;top:0;z-index:1;display:none;cursor:crosshair;';
    var o = document.createElement('canvas');
    o.style.cssText = 'position:absolute;left:0;top:0;z-index:1;display:none;pointer-events:none;';
    var t = document.createElement('div');
    t.style.cssText = 'position:absolute;z-index:4;display:none;transform-origin:100% 0;font:11px sans-serif;';
    t.innerHTML =
      '<button type="button" title="Angle and depth" style="padding:1px 7px;border-radius:5px;' +
      'border:1px solid #000;background:#1b2129;color:#22d3ee;font-weight:600;cursor:pointer;">⚙</button>' +
      '<div style="display:none;position:absolute;right:0;top:24px;padding:6px 8px;border-radius:6px;' +
      'background:rgba(10,14,22,.9);border:1px solid #000;color:#a5f3fc;white-space:nowrap;">' +
      '<label style="display:block;">Angle <input type="range" min="0.3" max="1.6" step="0.01" style="width:110px;vertical-align:middle;"></label>' +
      '<label style="display:block;">Depth <input type="range" min="0" max="1" step="0.05" style="width:110px;vertical-align:middle;"></label>' +
      '<button type="button" style="margin-top:3px;border-radius:5px;border:1px solid #000;background:#1b2129;color:#22d3ee;cursor:pointer;">Reset</button></div>';
    var btn = t.children[0], box = t.children[1], ins = box.querySelectorAll('input');
    function sync() { ins[0].max = v3.angleMax; ins[0].value = v3.angle; ins[1].value = v3.depth; }
    btn.addEventListener('click', function () { box.style.display = box.style.display === 'none' ? 'block' : 'none'; sync(); });
    ins[0].addEventListener('input', function () { v3.angle = Number(ins[0].value); v3Geom(); });
    ins[1].addEventListener('input', function () { v3.depth = Number(ins[1].value); v3Geom(); sync(); });
    box.querySelector('button').addEventListener('click', function () { v3.angle = V3_ANGLE0; v3.depth = V3_DEPTH0; v3Geom(); sync(); });
    t.addEventListener('wheel', function (ev) { ev.stopPropagation(); }, true);
    wfdiv.appendChild(c); wfdiv.appendChild(o); wfdiv.appendChild(t);
    v3.canvas = c; v3.overlay = o; v3.tools = t;
    // Spectrum + waterfall: hover shows the frequency (and the dashed line down the
    // waterfall), a click tunes there
    c.addEventListener('mousemove', function (ev) {
      var p = v3Pick(ev.clientX, ev.clientY), r = c.getBoundingClientRect();
      spec.hoverX = p ? (p.clientX - r.left) / (wfScale * pageZoom) : null;
      v3.hoverAge = p ? p.age : 0;
      spec.dirty = true; v3.lastMarks = 0;
    });
    c.addEventListener('mouseleave', function () { spec.hoverX = null; spec.dirty = true; v3.lastMarks = 0; });
    c.addEventListener('click', function (ev) {
      var p = v3Pick(ev.clientX, ev.clientY);
      if (p) tuneAtClientX(c, p.clientX);
    });
    try { v3InitGL(); } catch (err) { v3.failed = true; console.warn('3D spectrum:', err); }
    return true;
  }

  function v3Hide() {
    if (spec.canvas) spec.canvas.style.visibility = '';
    if (!v3.canvas) return;
    v3.canvas.style.display = 'none'; v3.overlay.style.display = 'none'; v3.tools.style.display = 'none';
  }

  // Same place and size as the 2D spectrum canvas
  function v3Place() {
    var sc = spec.canvas, c = v3.canvas, o = v3.overlay;
    var w = sc.offsetWidth || 1024, h = sc.offsetHeight || sc.height, top = sc.offsetTop, left = sc.offsetLeft;
    [c, o].forEach(function (el) {
      el.style.left = left + 'px'; el.style.top = top + 'px';
      el.style.width = w + 'px'; el.style.height = h + 'px'; el.style.display = 'block';
    });
    c.style.pointerEvents = spec.split ? 'auto' : 'none';   // over the waterfall: the waterfall takes the mouse
    sc.style.visibility = 'hidden';
    var dpr = Math.min(2, window.devicePixelRatio || 1);
    var bw = Math.max(1, Math.round(w * wfScale * pageZoom * dpr)), bh = Math.max(1, Math.round(h * pageZoom * dpr));
    if (c.width !== bw || c.height !== bh) { c.width = bw; c.height = bh; v3.dirty = true; }
    if (o.width !== w || o.height !== h) { o.width = w; o.height = h; v3.lastMarks = 0; }
    var t = v3.tools;
    t.style.display = 'block';
    t.style.top = (top + 6) + 'px'; t.style.left = ''; t.style.right = (wfdivRight(sc) + 8) + 'px';
    t.style.transform = 'scaleX(' + (1 / wfScale) + ')';   // #wfcontainer is stretched by wfScale: not the buttons
  }
  function wfdivRight(sc) { return sc.parentNode.clientWidth - sc.offsetLeft - sc.offsetWidth; }

  // Ranges are kept in kHz from v3.ref, so the GPU's 32-bit floats stay fine-grained;
  // a move of the view far away (another band) moves v3.ref and rewrites the table.
  function v3SetRef(f) {
    v3.ref = f;
    var a = new Float32Array(V3_H * 2);
    for (var i = 0; i < V3_H * 2; i++) a[i] = v3.ranges[i] ? v3.ranges[i] - f : 0;
    if (!v3.gl) return;
    v3.gl.bindTexture(v3.gl.TEXTURE_2D, v3.rangeTex);
    v3.gl.texSubImage2D(v3.gl.TEXTURE_2D, 0, 0, 0, V3_H, 1, v3.gl.RG, v3.gl.FLOAT, a);
  }

  // Raw waterfall level (0-255) → what the waterfall shows for it: the palette colour
  // through brightness(wfB) contrast(wfC) and #svgGradientMap, as the browser does it
  // (tablePos, then the table read linearly between its entries). The position in the
  // table is also the height level. Rebuilt whenever Auto or the sliders change wfB/wfC.
  var v3lutH = new Float32Array(256);
  function v3Luts() {
    var gl = v3.gl, key = wfB + '/' + wfC;
    if (!gl || !palRGB || key === v3.v3LutKey) return;
    v3.v3LutKey = key;
    var col = new Uint8Array(256 * 4), l, k;
    for (l = 0; l < 256; l++) {
      var p = tablePos(palRGB[0][l] / 255, palRGB[1][l] / 255, palRGB[2][l] / 255, wfB, wfC);
      v3lutH[l] = p;
      for (k = 0; k < 3; k++) {
        var tv = v3.wfTable[k], pos = p * (tv.length - 1), a = Math.min(Math.floor(pos), tv.length - 1), b = Math.min(a + 1, tv.length - 1);
        col[l * 4 + k] = Math.round((tv[a] + (tv[b] - tv[a]) * (pos - a)) * 255);
      }
      col[l * 4 + 3] = 255;
    }
    gl.bindTexture(gl.TEXTURE_2D, v3.cmapTex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, 256, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, col);
    gl.bindTexture(gl.TEXTURE_2D, v3.hgtTex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.R32F, 256, 1, 0, gl.RED, gl.FLOAT, v3lutH);
    v3.dirty = true; v3.lastMarks = 0;
  }

  // New line: the waterfall's newest raw levels (spec.lvl), stored as they are
  var v3line = new Uint8Array(V3_W * 2), v3norm = new Float32Array(V3_W), v3src = new Float32Array(V3_W),
      v3lv = new Float32Array(V3_W);
  function v3Push() {
    var e = window.bi && bi[window.band], arr = spec.lvl, gl = v3.gl;
    if (!gl || !e || !arr || !arr.length) return;
    var L = e.effcenterfreq - e.effsamplerate / 2, R = e.effcenterfreq + e.effsamplerate / 2;
    if (!(R > L)) return;
    var view = L + '/' + R;
    if (view !== v3.prevView) { v3.havePrev = false; v3.prevView = view; }
    var n = arr.length, i, x;
    if (v3src.length < n) { v3src = new Float32Array(n); v3lv = new Float32Array(n); }
    for (i = 0; i < n; i++) v3lv[i] = arr[i];
    for (i = 0; i < n; i++) {                   // sharpen across frequency: lower a peak's sides, never the peak
      var m = v3lv[i], a = v3lv[i > 0 ? i - 1 : 0], c = v3lv[i < n - 1 ? i + 1 : n - 1];
      var v = Math.min(m, m + V3_SHARPEN * (m - 0.5 * (a + c)));
      v3src[i] = v <= 0 ? 0 : v;
    }
    for (x = 0; x < V3_W; x++) {
      var i0 = Math.floor(x * n / V3_W), i1 = Math.max(i0 + 1, Math.floor((x + 1) * n / V3_W)), mx = 0, kk = Math.min(i0, n - 1);
      for (i = i0; i < i1 && i < n; i++) if (v3src[i] > mx) { mx = v3src[i]; kk = i; }   // max keeps thin carriers
      v3norm[x] = mx;
      v3line[2 * x + 1] = Math.max(0, Math.min(255, Math.round(v3lv[kk])));        // colour: the unsharpened level
    }
    for (x = 0; x < V3_W; x++) {                // a light 10 % carry-over in time steadies the noise
      var hv = v3norm[x];
      if (v3.havePrev) hv = 0.9 * hv + 0.1 * v3.prev[x];
      v3.prev[x] = hv;
      v3line[2 * x] = Math.max(0, Math.min(255, Math.round(hv)));
    }
    v3.havePrev = true;
    var hd = v3.head = (v3.head + 1) % V3_H;
    v3.times[hd] = performance.now();
    v3.hist.set(v3line, hd * V3_W * 2);
    v3.ranges[hd * 2] = L; v3.ranges[hd * 2 + 1] = R;
    gl.bindTexture(gl.TEXTURE_2D, v3.histTex);
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, hd, V3_W, 1, gl.RG_INTEGER, gl.UNSIGNED_BYTE, v3line);
    if (!v3.ref || Math.abs((L + R) / 2 - v3.ref) > 2000) v3SetRef((L + R) / 2);
    else {
      gl.bindTexture(gl.TEXTURE_2D, v3.rangeTex);
      gl.texSubImage2D(gl.TEXTURE_2D, 0, hd, 0, 1, 1, gl.RG, gl.FLOAT, new Float32Array([L - v3.ref, R - v3.ref]));
    }
    v3.dirty = true;
  }

  function v3Render() {
    var gl = v3.gl, e = window.bi && bi[window.band];
    if (!gl || !e) return;
    var L = e.effcenterfreq - e.effsamplerate / 2, R = e.effcenterfreq + e.effsamplerate / 2;
    if (!(R > L)) return;
    if (L !== v3.viewL || R !== v3.viewR) { v3.viewL = L; v3.viewR = R; v3.dirty = true; }
    if (!v3.dirty) return;
    v3.dirty = false;
    gl.viewport(0, 0, v3.canvas.width, v3.canvas.height);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.useProgram(v3.prog);
    gl.bindVertexArray(v3.vao);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, v3.histTex); gl.uniform1i(v3.u.uHist, 0);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, v3.cmapTex); gl.uniform1i(v3.u.uCmap, 1);
    gl.activeTexture(gl.TEXTURE3); gl.bindTexture(gl.TEXTURE_2D, v3.hgtTex); gl.uniform1i(v3.u.uHgt, 3);
    gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, v3.rangeTex); gl.uniform1i(v3.u.uRange, 2);
    gl.uniform2f(v3.u.uView, L - v3.ref, R - v3.ref);
    gl.uniform1i(v3.u.uHead, v3.head);
    gl.uniform1f(v3.u.uRise, v3.RISE);
    gl.uniform1f(v3.u.uK, v3.K);
    gl.uniform1f(v3.u.uBackH, v3.BACKH);
    gl.uniform1f(v3.u.uAmp, V3_AMP);
    gl.drawElements(gl.TRIANGLES, v3.nIdx, gl.UNSIGNED_INT, 0);
  }

  // Scale marks on the overlay: dBFS on the front row (right, as the 2D spectrum's
  // grid), seconds into the depth (left); the frequency under the pointer (top left)
  function v3Marks() {
    var o = v3.overlay, ctx = o.getContext('2d'), w = o.width, h = o.height;
    function yPx(y) { return (1 - y) / 2 * h; }
    ctx.clearRect(0, 0, w, h);
    ctx.font = '9px monospace';
    if (v3.failed) {
      ctx.fillStyle = '#22d3ee'; ctx.font = '13px sans-serif';
      specText(ctx, 'The 3D spectrum needs WebGL2, which this browser does not offer.', w / 2, h / 2, 'center');
      return;
    }
    // dBFS of a raw level as the 2D spectrum labels it (lvlToDb), placed at that level's height
    var lastY = Infinity;
    for (var dB = Math.ceil(lvlToDb(0) / 10) * 10; dB <= lvlToDb(255); dB += 10) {
      var v = v3lutH[Math.max(0, Math.min(255, Math.round((dB + 120 + WF_CAL_DB) * 255 / 100)))];
      if (v <= 0.02) continue;
      var y = Math.round(yPx(v3GroundOf(0) + Math.pow(v, V3_HPOW) * V3_AMP)) + 0.5;
      if (y < 30) break;                         // clear of the ⚙ button
      if (lastY - y < 12) continue;
      lastY = y;
      ctx.strokeStyle = 'rgba(34,211,238,0.4)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(w - 46 / wfScale, y); ctx.lineTo(w, y); ctx.stroke();
      ctx.fillStyle = 'rgba(165,243,252,0.9)';
      specText(ctx, String(dB), w - 4, y - 3, 'right');
    }
    var hd = v3.head, now = v3.times[hd], oldest = 0, a;
    for (a = V3_H - 1; a > 0; a--) if (v3.times[(hd - a + V3_H) % V3_H] > 0) { oldest = a; break; }
    if (now > 0 && oldest > 4) {
      var total = (now - v3.times[(hd - oldest + V3_H) % V3_H]) / 1000;
      var step = [1, 2, 5, 10, 15, 30, 60, 120].filter(function (st) { return total / st <= 5; })[0] || 300;
      ctx.setLineDash([4, 3]);
      for (var sec = step, ag = 1; sec < total; sec += step) {
        while (ag < oldest && (now - v3.times[(hd - ag + V3_H) % V3_H]) / 1000 < sec) ag++;
        var d = ag / (V3_H - 1), ty = Math.round(yPx(v3GroundOf(d))) + 0.5;
        ctx.strokeStyle = 'rgba(34,211,238,0.22)';
        ctx.beginPath(); ctx.moveTo(0, ty); ctx.lineTo(w, ty); ctx.stroke();
        ctx.fillStyle = 'rgba(165,243,252,0.85)';
        specText(ctx, '−' + sec + ' s', 8, ty - 3, 'left');
      }
      ctx.setLineDash([]);
    }
    if (spec.split && spec.hoverX !== null && window.bi && bi[window.band]) {
      var e = bi[band], f = e.effcenterfreq - e.effsamplerate / 2 + spec.hoverX / 1024 * e.effsamplerate;
      ctx.font = '11px monospace'; ctx.fillStyle = 'rgba(255,255,180,0.95)';
      specText(ctx, (f / 1000).toFixed(6) + ' MHz' + (v3.hoverAge >= 0.5 ? '  (−' + v3.hoverAge.toFixed(1) + ' s)' : ''), 10, 15, 'left');
    }
  }

  // Level (0-1, height) of a row at position u of the view, as sampleAt() in the shader
  function v3LevelAt(u, age) {
    var row = (v3.head - age + V3_H) % V3_H, l = v3.ranges[row * 2], r = v3.ranges[row * 2 + 1];
    if (!(r > l) || r - l > 1.5 * (v3.viewR - v3.viewL)) return v3lutH[0];
    var t = (v3.viewL + u * (v3.viewR - v3.viewL) - l) / (r - l);
    if (t < 0 || t >= 1) return v3lutH[0];
    return v3lutH[v3.hist[(row * V3_W + Math.min(Math.floor(t * V3_W), V3_W - 1)) * 2]];
  }
  // The row under the pointer (the front-most one whose surface reaches up to it):
  // the frequency there as a front-row clientX, and the row's age in seconds
  function v3Pick(clientX, clientY) {
    if (!v3.canvas || !(v3.viewR > v3.viewL)) return null;
    var rc = v3.canvas.getBoundingClientRect();
    if (!rc.width || !rc.height) return null;
    var xs = (clientX - rc.left) / rc.width * 2 - 1, ys = 1 - (clientY - rc.top) / rc.height * 2;
    for (var a = 0; a < V3_H; a++) {
      var d = a / (V3_H - 1), sd = v3sOf(d);
      if (Math.abs(xs) > sd) return null;
      var u = 0.5 + 0.5 * xs / sd;
      if (ys <= v3GroundOf(d) + Math.pow(v3LevelAt(u, a), V3_HPOW) * v3AmpOf(d)) {
        var t = v3.times[(v3.head - a + V3_H) % V3_H];
        return { clientX: rc.left + u * rc.width, age: t > 0 ? (v3.times[v3.head] - t) / 1000 : 0 };
      }
    }
    return null;
  }

  // Called from specLoop while the 2D spectrum is shown; fresh = a new line came in
  function v3Frame(fresh) {
    if (!v3.on) { v3Hide(); return; }
    if (!spec.canvas || !v3Elements()) return;
    v3Place();
    v3Luts();
    if (fresh) v3Push();
    v3Render();
    var t = performance.now();
    if (t - v3.lastMarks > 250) { v3.lastMarks = t; v3Marks(); }
  }

  // The "3D" switch beside "Tube & Waterfall & DSP & Audio". Turned on while
  // Type = waterfall, it also switches Type to spectrum + waterfall, so it shows.
  window.addEventListener('load', function () {
    var sw = document.getElementById('spec3d_toggle');
    if (!sw) return;
    var saved = null;
    try { saved = localStorage.getItem(V3_KEY); } catch (e) {}
    sw.checked = v3.on = (saved === '1');
    sw.addEventListener('change', function () {
      v3.on = sw.checked;
      try { localStorage.setItem(V3_KEY, v3.on ? '1' : '0'); } catch (e) {}
      var sel = document.getElementById('wfmode');
      if (v3.on && sel && sel.value === '1') {
        sel.value = '2';
        try { localStorage.setItem(WFTYPE_KEY, '2'); } catch (e) {}
        window.waterfallmode(2);
      }
      v3.dirty = true; v3.lastMarks = 0; spec.dirty = true;
    });
  });

  // ── SNR the PhantomSDR-Plus way (its waterfall.js _updateSnr) ───────────────
  // Measured on the newest waterfall line, not from the S-meter's peak and minimum:
  //   noise  = quietest ~3 kHz patch of the visible span (the minimum of the
  //            per-window medians, the passband and a guard band left out),
  //            rescanned every second and eased 50 % towards each new scan;
  //   signal = strongest bin in the tuned passband (freq + lo … freq + hi);
  //   SNR    = max(0, signal − noise) in dB, eased 30 % towards each new line.
  // Levels are 100/255 dB apart (see lvlToDb). websdr-base.js shows window.ubersdr_snr
  // in the SNR box; it is null until there is a measurement.
  var SNR_NF_SCAN_MS = 1000, SNR_WIN_HZ = 3000;
  var snrSt = { row: null, view: '', noise: null, snr: null, nextScan: 0 };
  window.ubersdr_snr = null;
  function snrUpdate() {
    var cv = wfCanvases()[0], e = window.bi && bi[window.band];
    if (!cv || !cv.width || !cv.height || !e || !(e.effsamplerate > 0)) return;
    var d;
    try { d = cv.getContext('2d').getImageData(0, cv.height - 1, cv.width, 1).data; } catch (x) { return; }
    var n = cv.width, i, same = snrSt.row && snrSt.row.length === d.length;
    if (same) for (i = 0; i < d.length; i += 16) if (d[i] !== snrSt.row[i] || d[i + 2] !== snrSt.row[i + 2]) { same = false; break; }
    if (same) return;
    snrSt.row = new Uint8ClampedArray(d);
    var lvl = new Array(n);
    for (i = 0; i < n; i++) lvl[i] = palIndex[(d[4 * i] << 16) | (d[4 * i + 1] << 8) | d[4 * i + 2]];   // undefined: blended pixel
    var view = e.effcenterfreq + '/' + e.effsamplerate;
    if (view !== snrSt.view) { snrSt.view = view; snrSt.noise = null; snrSt.snr = null; }   // new span: start over

    // tuned passband → pixels
    function px(fk) { return Math.round((fk - e.effcenterfreq) / e.effsamplerate * n + n / 2); }
    var a = px(freq + lo), b = px(freq + hi), i0 = -1, i1 = -1, hasPb = false;
    if (b < a) { var t = a; a = b; b = t; }
    if (b >= 0 && a <= n - 1) { i0 = Math.max(0, a); i1 = Math.min(n - 1, b); hasPb = true; }

    // noise floor: quietest ~3 kHz window, every SNR_NF_SCAN_MS
    var now = Date.now();
    if (snrSt.noise === null || now >= snrSt.nextScan) {
      snrSt.nextScan = now + SNR_NF_SCAN_MS;
      var hzPerPx = e.effsamplerate * 1000 / n;
      var win = Math.max(4, Math.round(SNR_WIN_HZ / hzPerPx));
      var guard = hasPb ? Math.max(win, (i1 - i0) + win) : 0;
      var quiet = Infinity, buf = [], w, v;
      for (w = 0; w + win <= n; w += win) {
        if (hasPb && w <= i1 + guard && (w + win - 1) >= i0 - guard) continue;
        buf.length = 0;
        for (i = w; i < w + win; i++) { v = lvl[i]; if (v !== undefined) buf.push(v); }
        if (buf.length < 3) continue;
        buf.sort(function (x, y) { return x - y; });
        if (buf[buf.length >> 1] < quiet) quiet = buf[buf.length >> 1];
      }
      if (!isFinite(quiet)) {                       // nothing left outside the passband: 20th percentile
        buf.length = 0;
        for (i = 0; i < n; i++) if (lvl[i] !== undefined) buf.push(lvl[i]);
        if (buf.length >= 4) { buf.sort(function (x, y) { return x - y; }); quiet = buf[Math.floor(buf.length * 0.2)]; }
      }
      if (isFinite(quiet)) snrSt.noise = snrSt.noise === null ? quiet : snrSt.noise + 0.5 * (quiet - snrSt.noise);
    }
    if (snrSt.noise === null) return;

    // signal: strongest bin in the passband (whole line if the passband is off screen)
    var peak = -Infinity;
    if (hasPb) for (i = i0; i <= i1; i++) if (lvl[i] > peak) peak = lvl[i];
    if (!isFinite(peak)) for (i = 0; i < n; i++) if (lvl[i] > peak) peak = lvl[i];
    if (!isFinite(peak)) return;
    var snr = Math.max(0, (peak - snrSt.noise) * 100 / 255);
    snrSt.snr = snrSt.snr === null ? snr : snrSt.snr + 0.3 * (snr - snrSt.snr);
    window.ubersdr_snr = snrSt.snr;
  }
  // Digital-mode frame at the right of the indicator row under the S-meter (#digi_info):
  // the running decoder (decoders.js ubersdr_dec_label) or RADE, in cyan; empty otherwise.
  function digiLabel() {
    var el = document.getElementById('digi_info');
    if (!el) return;
    var t = (window.ubersdr_dec_label && window.ubersdr_dec_label()) ||
            (rade.side ? 'RADE' : '') || (xm.kind ? XM[xm.kind].label : '');
    if (el.textContent !== t) el.textContent = t;
  }
  setInterval(function () { try { digiLabel(); } catch (x) {} }, 400);
  function snrLoop() { requestAnimationFrame(snrLoop); try { snrUpdate(); } catch (x) {} }
  window.addEventListener('load', function () { requestAnimationFrame(snrLoop); });

  // Type = spectrum (0) or spectrum + waterfall (2): keep the waterfall script in
  // waterfall mode (it is the data source) and show this spectrum over it or above it;
  // waterfall (1) hides it again. (2 was "weak sigs" and 3 "strong sigs", both removed.)
  // The Type selector is the source of truth: the page also re-applies the mode itself
  // (e.g. when the waterfall restarts) from a variable that is 1 while this is shown.
  function specSetType(m, orig) {
    var sel = document.getElementById('wfmode');
    m = sel ? Number(sel.value) : Number(m);
    spec.on = (m === 0 || m === 2);
    spec.split = (m === 2);
    spec.dirty = true;
    orig(1);
  }

  // First visit: Type = spectrum + waterfall. The visitor's own choice is kept in this
  // browser (localStorage 'ubersdr_wftype') for the next visits. Desktop page only.
  var WFTYPE_KEY = 'ubersdr_wftype', WFTYPE_DEFAULT = '2';
  window.addEventListener('load', function () {
    var sel = document.getElementById('wfmode');
    if (!sel) return;
    var v = null;
    try { v = localStorage.getItem(WFTYPE_KEY); } catch (e) {}
    if (!/^[012]$/.test(v || '')) v = WFTYPE_DEFAULT;
    sel.value = v;
    sel.addEventListener('change', function () { try { localStorage.setItem(WFTYPE_KEY, sel.value); } catch (e) {} });
    window.waterfallmode(Number(v));
  });

  // ── Move UberSDR's credit line (written before the RW3PS layout) to the bottom
  document.addEventListener('DOMContentLoaded', function () {
    var overlay = document.getElementById('audiostartbutton');
    if (!overlay || overlay.parentNode !== document.body) return;
    var credit = document.createElement('div');
    credit.id = 'ubersdr-credit';
    while (document.body.firstChild && document.body.firstChild !== overlay) {
      var n = document.body.firstChild;
      if (n.nodeName === 'P' || n.nodeName === 'HR') document.body.removeChild(n);
      else credit.appendChild(n);
    }
    document.body.appendChild(credit);
  });
}());
