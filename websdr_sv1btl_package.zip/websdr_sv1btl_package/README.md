# SV1BTL WebSDR layout for UberSDR — installation and user guide

websdr_sv1btl version 6.0.0 (2026-11-21) · by SV1BTL · based on RW3PS's WebSDR template

(This is the version of this layout, not of UberSDR, which has its own version numbers.)

- **Repository:** https://github.com/sv1btl/WebSDR-emulation-for-UberSDR
- **Live example:** http://sv1btlham.no-ip.org:8901/ (SV1BTL's WebSDR, Athens)
- **Questions and problem reports:** https://github.com/sv1btl/WebSDR-emulation-for-UberSDR/issues

This package replaces the page that UberSDR shows on its **WebSDR port (8901)** with the
layout used at SV1BTL's WebSDR (Athens, KM17vx). It is the classic Twente WebSDR interface
restyled by RW3PS, adapted to UberSDR's Opus sound engine, with extras such as:

- a **waterfall** with colours and automatic brightness and contrast;
- a **spectrum** in the PhantomSDR style, either over the waterfall or above it
  ("spectrum + waterfall", the default for first-time visitors); there the dashed line
  that follows the mouse runs down through the waterfall as well, as in PhantomSDR-Plus;
- a **3D spectrum** as in PhantomSDR-Plus, with the waterfall's own colours (the **3D**
  switch next to "Tube & Waterfall & DSP & Audio"; see "3D spectrum" below);
- **click-to-tune** on the waterfall and the spectrum, rounded to 0.5 kHz. The mouse wheel
  there zooms; **Shift + wheel** tunes in 100 Hz steps and **Ctrl + Shift + wheel** in 10 Hz
  steps, as in PhantomSDR-Plus (desktop page);
- **digit tuning** on the frequency display: mouse wheel over a digit, left click up,
  right click down;
- a **frequency keypad**: click anywhere else in the black frequency / S-meter frame (desktop
  page) for a number pad with a decimal point; type the frequency in kHz and press Enter
  (see "Frequency keypad" in section 6);
- **band buttons** that zoom to the band and follow the frequency; **All** shows the
  whole receiver range and stays lit while the waterfall is fully zoomed out. As in
  PhantomSDR-Plus, each band button **remembers** the last frequency tuned in that band,
  here with its mode and filter too (kept in the visitor's browser); a second press on the
  band already lit goes back to the band's default. The **Band** button in Waterfall
  Settings follows the band plan: it zooms to the whole band you are in and sets that
  band's mode, keeping the frequency shown (40 m 7000–7200 LSB, 30 m CW, 41 m broadcast
  7205–7605 AM…; amateur bands from the band table, the rest from the page's band-plan
  table, `modeperfreq` in `websdr-base.js`). A running decoder stops; outside both it
  zooms ±100 kHz as before;
- more **Mode buttons** on the one Mode line: **RADE V1** (FreeDV digital voice, **RADEL**
  and **RADEU**), decoded by UberSDR's own FreeDV extension; **IQ** (the raw I/Q, with
  PhantomSDR-Plus's IQ demodulators and IQ recording) and **DRM** (decoded by UberSDR,
  with PhantomSDR-Plus's DRM schedule);
- the desktop page **fits the browser window**: it is scaled to the window's width, from
  1024 px screens to 4K (add `?nofit` to the address to switch this off);
- **signal readouts** on the radio display, as in PhantomSDR-Plus: **dBm**, **dBµV**,
  **SNR** and **NF** (noise floor) in a row over the S-meter;
- a **dark theme** for the whole page (the **Light GUI / Dark GUI** switch next to Auto
  brightness; the original light look is the default, each visitor's choice is kept);
- a **CW decoder** window that opens under the Mode buttons while the mode is CW, using
  PhantomSDR-Plus's CW decoder in the listener's browser, with a **CW Browser** that
  decodes every CW signal in the passband at once;
- **digital-mode decoders** (FT8, FT4, FT2, JS8, WSPR, SSTV, HF FAX, NAVTEX, a SERVICES window with
  HFDL, Maritime FSK / SITOR, Weather RTTY, Naval RTTY, DSC, time signals, HF Selcall, ALE 2G, AQC-ALE, the FSK modes SITOR-A, ARQ-E
  and ARQ-E3, STANAG 4285, MIL-STD-188-110A and 3G ALE, and an
  FLDIGI window with Amateur RTTY, PSK31·63·125 (BPSK/QPSK), Olivia and Contestia (Amateur
  RTTY, PSK, Olivia / Contestia and MFSK each with a browser for all their signals at once), FST4W, MFSK, MSK144, DominoEX, THOR, THROB,
  Hellschreiber, MT63, ALE 2G HAM, Packet and APRS) from
  PhantomSDR-Plus, with a Decoder button row under the Mode buttons, and **Decoder ID**,
  which tells which mode is in the passband;
- **Receive Diversity** (desktop and mobile pages), as in PhantomSDR-Plus: a second receiver somewhere
  else (an UberSDR, a KiwiSDR, a PhantomSDR-Plus or a classic WebSDR) follows your tuning,
  and the speaker
  plays whichever of the two hears the station better (see "Receive Diversity" in
  section 6);
- **audio tools** that run in the listener's browser: Weak-signal AGC, noise reduction,
  two autonotch filters, squelch, a soft limiter, Hi-Boost, L/R output and WAV recording;
- the **listener's country and city** in the users list, and clicking a listener tunes
  to their frequency and mode;
- works with **DJ0MY's CATSync** (Windows): your own transceiver and the WebSDR follow each
  other's frequency and mode, both ways;
- a **mobile page** (phones are sent there automatically) with the same audio tools and
  S-meter;
- **station labels** on the frequency scale, taken from a simple text file.
- a **chatbox** that works with UberSDR's WebSDR chat. The server keeps the last 20
  messages in memory until it restarts.

UberSDR itself is not modified: the files are mounted into the container, UberSDR
updates do not touch them, and uninstalling brings back UberSDR's own page.

---

## Contents

1. [Requirements](#1-requirements)
2. [Quick install](#2-quick-install)
3. [Your station settings (station.js)](#3-your-station-settings-stationjs)
4. [Station labels (stationinfo.txt)](#4-station-labels-stationinfotxt)
5. [Other things you may want to change](#5-other-things-you-may-want-to-change)
6. [How it works](#6-how-it-works)
7. [After an UberSDR update](#7-after-an-ubersdr-update)
8. [Upgrading to a newer package](#8-upgrading-to-a-newer-package)
9. [Uninstalling](#9-uninstalling)
10. [Manual installation (without install.sh)](#10-manual-installation-without-installsh)
11. [Troubleshooting](#11-troubleshooting)
12. [Settings for advanced users](#12-settings-for-advanced-users)
13. [Credits and licences](#13-credits-and-licences)

---

## 1. Requirements

- A working **UberSDR** installation made with its standard installer (Docker Compose).
  The package expects the usual layout:
  - `~/ubersdr/docker-compose.yml`
  - a service called `ubersdr`
  - a container called `ka9q_ubersdr`

  Other folders and names work too (see below).
- UberSDR's **WebSDR server switched on**. In the admin page, or in `config.yaml`:

  ```yaml
  server:
    enable_websdr: true
    websdr_tcp_port: 8901
  ```

  To check it, open `http://<your-address>:8901/`. You should see UberSDR's own WebSDR
  page before installing.
- `python3` and `docker` on the host. Both are already there on a normal UberSDR machine.
- For the **RADE** buttons (optional): UberSDR's FreeDV extension (standard in current
  UberSDR) and `server.enable_cors: true` in its `config.yaml`. See section 6.

## 2. Quick install

1. **Get the package on the UberSDR machine**, anywhere, for example in your home folder.

   With git:

   ```bash
   git clone https://github.com/sv1btl/WebSDR-emulation-for-UberSDR.git
   cd WebSDR-emulation-for-UberSDR
   ```

   Or without git, download the repository as a ZIP file:

   ```bash
   wget https://github.com/sv1btl/WebSDR-emulation-for-UberSDR/archive/refs/heads/main.zip
   unzip main.zip
   cd WebSDR-emulation-for-UberSDR-main
   ```

   Or download `websdr_sv1btl_package.zip` from the repository's
   [Releases](https://github.com/sv1btl/WebSDR-emulation-for-UberSDR/releases) page and unpack it with
   `unzip websdr_sv1btl_package.zip && cd websdr_sv1btl_package`. Check it first
   with `sha256sum -c websdr_sv1btl_package.zip.sha256`, using the `.sha256` file
   from the same page.

2. **Run the installer:**

   ```bash
   bash install.sh                  # if UberSDR is in ~/ubersdr
   bash install.sh /path/to/ubersdr # if it is somewhere else
   ```

   The installer does this, and deletes nothing:

   - copies `websdr_sv1btl/` next to UberSDR's `docker-compose.yml`;
   - adds 6 mount lines to the `ubersdr` service in `docker-compose.yml`, after saving a
     backup as `docker-compose.yml.bak.<date>`;
   - reads `websdr_waterfall_calibration` from UberSDR's `config.yaml` and writes it into
     `station.js`;
   - offers to set up the WebSDR relay for Receive Diversity, asking for its port (Enter
     for 8902; see "Receive Diversity" in section 6);
   - asks before recreating the container. This happens only once, the first time. It
     stops the audio of anyone listening for about 15 seconds, so you can answer **N**
     and run it later with `cd ~/ubersdr && docker compose up -d ubersdr`;
   - runs a check. Every line should say **OK**.

3. **Edit your station settings** in `~/ubersdr/websdr_sv1btl/sv1btl/station.js` (see
   section 3). This needs no restart.

4. **Open `http://<your-address>:8901/`** and press **Ctrl+F5**. Also try the mobile page
   at `/m.html`.

## 3. Your station settings (station.js)

Everything that belongs to your station is in one file:
**`websdr_sv1btl/sv1btl/station.js`**. Open it with any text editor (see
[the note about editors](#editing-files-safely)). Change the values, keeping the quotes
and the comma at the end of each line.

| Setting | Example | What it does |
|---|---|---|
| `callsign` | `'SV1ABC'` | "It is operated by …" in the page header |
| `location` | `'Athens, GR'` | "This is a WebSDR receiver, located in …" |
| `locator` | `'KM17vx'` | Maidenhead locator, shown with a link to a map |
| `email` | `'sv1abc@example.com'` | contact address in the header |
| `mobileTitle` | `'SV1ABC WebSDR Mobile version'` | browser-tab title of the mobile page |
| `startKHz` | `7120` | where a **first-time** visitor starts, in kHz (returning visitors start where they left off) |
| `startMode` | `'LSB'` | mode for that start: `'LSB'`, `'USB'`, `'AM'`, `'CW'` or `'FM'` |
| `waterfallCalibration` | `12` | must equal `websdr_waterfall_calibration` in UberSDR's `config.yaml`; the installer copies it. It sets the dB scale of the spectrum. |
| `mainServer` | `'https://sv1abc.tunnel.ubersdr.org'` | where visitors' browsers reach UberSDR's main web server, for RADE, IQ and DRM; the installer fills in UberSDR's public address; `''` means this host on port 8080 |
| `diversityRelayPort` | `8902` | port of the WebSDR relay for Receive Diversity, on this page's host (the installer fills it in); forward it on your router |
| `mwStepKHz` | `9` | medium-wave channel step of the >>> / <<< buttons in AM: 9 kHz in Europe, Africa and Asia, `10` in the Americas |
| `showListenerCity` | `true` | `true` gives "GR,Athens" in the users list; `false` gives the country only, "GR" |
| `otherWebSDRs` | `[ 'Twente', 'http://…' ],` | the "Switch to another WebSDR" buttons, up to 6 per row, as many rows as needed |
| `hamBands` | *(commented out)* | your own band-button table (see below); leave it out to use the built-in IARU Region 1 table |

**The band table.** Each line is:

```
[ 'button text', lowest kHz, highest kHz, kHz the button tunes to, 'mode' ],
```

For example `[ '40m', 7000, 7300, 7200, 'LSB' ],` suits Region 2. The range is also used
to highlight the right band button as a listener tunes around, and for the mode given to
listeners who don't send one.

**The desktop page title** (the browser tab) comes from UberSDR itself: its instance name
and location in the admin page. It is not set in `station.js`.

**If you make a typo** in `station.js`, the page still works but shows a red line:
"Station settings not loaded: sv1btl/station.js is missing or has a typo". Press **F12**
in the browser; the console shows the line with the error. Usually it's a missing comma
or quote.

## 4. Station labels (stationinfo.txt)

The labels on the frequency scale (broadcast stations, FT8, beacons…) come from
**`websdr_sv1btl/sv1btl/stationinfo.txt`**. There's one label per line:

```
<frequency in kHz><mode> <text>
```

```
7074usb FT8
10136usb FT8
729am ERT Athens
14100cw NCDXF beacons
```

- `mode` is one of `am`, `fm`, `usb`, `lsb` or `cw`. Clicking the label tunes there in
  that mode.
- A label whose text names a digital mode (FT8, FT4, FT2, JS8, WSPR, SSTV, FAX, NAVTEX,
  RTTY, PSK31/63/125, QPSK31/63/125, Olivia, Contestia, MFSK16/32/64, DominoEX, THOR, THROB, Hell, MT63, Packet, APRS, DSC, Selcall, ALE, FST4W, MSK144) also starts that decoder, with its own sideband and filter (desktop page). Within
  2 kHz of the mode's usual frequency it tunes to that frequency. "FT8<br>JT65" starts
  FT8. Clicking a label without a digital mode stops a running decoder.
  For the decoders that read the signal above the dial (FAX, NAVTEX, RTTY, PSK31, Olivia,
  the FLDIGI modems, Packet) the label is the signal's own frequency: `518usb NAVTEX`
  tunes the dial to 517.50 and the display shows 518.00.
- The mode can also be a **PhantomSDR-Plus `markers.json` mode**, written the same way:
  `ft8`, `ft4`, `ft2`, `js8`, `wspr`, `sstv`, `fax`, `navtex`, `sitor`, `rtty`, `rtty-wx`, `rtty-nav`,
  `psk31`, `psk63`, `psk125`, `qpsk31`, `qpsk63`, `qpsk125`, `olivia`, `contestia`, `aprs`, `radel`, `radeu`, `morse`, `hfdl`, `drm`, `dsc`, `selcall`, `time`, `dcf77`, `msf`, `rwm`, `wwv`, `wwvh`, `ale`, `fst4w`, `msk144`. Then the mode alone
  decides what a click does, whatever the text says: `147.3rtty-wx DWD DDH47` starts
  SERVICES on Weather RTTY, `2174.5sitor SITOR MSI` SERVICES on Maritime FSK / SITOR,
  `7087radel FreeDV` RADE on LSB, `77.5morse DCF77` CW with its decoder, `2986hfdl`
  the HFDL decoder, `8414.5dsc` SERVICES on DSC (the label is the DSC frequency, the dial
  goes 1.7 kHz below) and `77.5dcf77` the time-signal decoder on DCF77. As in PhantomSDR-Plus, an `ale` label on an
  amateur (HFLINK) channel opens FLDIGI's ALE 2G HAM, on any other channel SERVICES' ALE 2G. DRM takes AM (`3205drm`); the DRM button then decodes it.
  SV1BTL's file has the markers of PhantomSDR-Plus's `frequencylist/mymarkers.json` and
  `decodermarkers.json` in this form, after the station's own labels.
- Lines starting with `#` are comments.
- `<br>` in the text starts a second line.

The file in the package is SV1BTL's list, with time signals and broadcasters heard in
Europe and some local Athens stations. Replace or edit it for your area. The page reads
it again on each band or zoom change, so after editing just reload the page.

The labels appear only from a quarter of the way in on the zoom range (25–100 %);
further out they would crowd the scale. To change that, edit `e.zoom * 4 < e.maxzoom`
in `sv1btl/ubersdr-compat.js` (`* 2` = from half zoom, or delete that line to show them at every zoom).

### EiBi schedule

The **EiBi** button, next to **SW** under Broadcast Station Information, opens a search of
the [EiBi](http://www.eibispace.de/dx/) broadcast and utility schedule, as in
PhantomSDR-Plus: filter by station, language, target area, band, country, transmitter,
frequency and UTC time (on air now in green). A click on a row tunes it in its mode (AM,
USB, LSB), opens the CW decoder for CW rows, starts the decoder for FAX, NAVTEX, RTTY or
HFDL rows (decoder modes in amber), switches DRM on for DRM rows, and frames the waterfall
around it with a red label; **Show on waterfall** puts all the results on the scale as
green labels. The list shows 400 rows at first and 400 more each time you scroll near its
bottom. Desktop page only.

The list is `sv1btl/eibi.json` (the package ships a copy), made by
`websdr_sv1btl/eibi/update-eibi.sh`: it downloads the current season's file from
eibispace.de only when it has changed (at most once a day) and is live at once, no
restart. Run it daily from cron (`crontab -e`):

```
00 1 * * * $HOME/ubersdr/websdr_sv1btl/eibi/update-eibi.sh >> $HOME/ubersdr/websdr_sv1btl/eibi/update.log 2>&1
```

or by hand with `update-eibi.sh --force`.

## 5. Other things you may want to change

These are in the HTML files. They're optional.

| What | Where |
|---|---|
| receiverbook.de registration | `websdr-head.html`, line 1: paste the `<meta name="receiverbook-confirmation" …>` line that receiverbook gives you |
| "Equipment" box (hidden by default) and the picture `sv1btl/setup_bw.gif` | `websdr-controls.html`, search for `equip_info` |
| Page background images | `sv1btl/bg6.jpg` (desktop), `sv1btl/aluminium.jpg` (mobile): replace them with images of the same name |
| Colours of the text under the waterfall: the "Chatbox" heading, the Statistics line and the UberSDR credit line (light green, links cyan, the Statistics numbers yellow) | `websdr-head.html`, the rules for `#chatcaption`, `#statsbox` and `#ubersdr-credit` |
| Favicon | `sv1btl/favicon.ico` / `favicon.png` |
| The browser-autoplay guide linked in the header | `sv1btl/guide/guide.html` |

Please keep the credit line: "a layout based on RW3PS's template … modified by SV1BTL".

## 6. How it works

UberSDR builds its WebSDR page (port 8901) from files in the container's `/app/websdr/`
folder. The package **mounts** five of those files, plus one folder of its own, from
`~/ubersdr/websdr_sv1btl/`:

```
websdr_sv1btl/websdr-head.html      → the page <head>: styles, scripts
websdr_sv1btl/websdr-controls.html  → the desktop page body (RW3PS layout)
websdr_sv1btl/websdr-base.js        → the page logic (Twente WebSDR, RW3PS changes)
websdr_sv1btl/m.html                → the mobile page
websdr_sv1btl/mobile-controls.html  → the mobile page body
websdr_sv1btl/sv1btl/               → everything else, served as /sv1btl/…:
    station.js          your settings
    stationinfo.txt     your labels
    ubersdr-compat.js   the glue to UberSDR, plus all the extras (audio tools,
                        spectrum, waterfall brightness, tuning…)
    websdr-nr.js        noise-reduction engine
    images, fonts, less.js, jQuery, guide/
```

UberSDR's own `websdr-sound.js` (Opus audio) and `websdr-waterfall.js` are **not**
replaced. `ubersdr-compat.js` hooks into them, which is why the check script verifies
they still have what it needs after an UberSDR update.

### Editing files safely

The five single files are "bind-mounted": the container keeps using the exact file it
started with. When you edit one:

- **Editors that save into the same file** (nano, `cat > file`, most GUI editors) make
  the change live **at once**, with no restart.
- **Editors or tools that replace the file** (some vim settings, `sed -i`, copying a new
  file over it) are **not** seen until the container restarts:
  `docker restart ka9q_ubersdr`. A restart stops listeners' audio for about 15 seconds.
- Files inside the `sv1btl/` folder (including `station.js`) are always seen at once.

Browsers keep scripts in their cache. After editing a `.js` file, press **Ctrl+F5**. To
make every visitor's browser fetch a changed `ubersdr-compat.js`, raise the `?v=…`
number after `ubersdr-compat.js` in both `websdr-head.html` and `mobile-controls.html`.

### RADE (FreeDV digital voice)

The **RADEL** and **RADEU** buttons in the Mode row decode RADE V1 on the lower or upper
sideband, with a 700–2200 Hz passband (1500 Hz, the width of a RADE signal; the
**1.50 kHz** filter button, first in the LSB and USB filter presets, lights up). Pressing
the lit button again, or any other mode button, switches it off.

UberSDR decodes RADE on the server, with its FreeDV extension (`freedv-ka9q`). That
extension can only work on a session of UberSDR's own interface, not on a WebSDR
(port 8901) one. So when a listener presses RADEL or RADEU, their browser:

1. registers a session with UberSDR's main web server (`mainServer` in `station.js`);
2. opens an audio session there on the same frequency in LSB or USB, muted, so no audio
   is sent back for it;
3. asks UberSDR to start the FreeDV decoder on it, and plays the decoded voice through
   the page's volume, Hi-Boost, notch and NR, while the normal audio is silenced.

Tuning on the page is followed. A status line under the Mode row shows "waiting for a
RADE signal…" or "decoding", and the lit button turns green while voice is decoded.

Below it, a small **FreeDV Reporter** window lists the stations reported to FreeDV
Reporter on the band you are on, as in UberSDR's own FreeDV panel: callsign, country,
distance, frequency (a green dot when you are on it), message, TX and last RX. Stations
transmitting now come first (red TX badge), then those that transmitted most recently;
the TX column shows how long ago ("3m", "2h"). Clicking a station tunes to it (RADE
stays on, also when the station is on another band). The window shows four rows at a
time and scrolls for more.

On the **mobile page**, RADEL and RADEU are at the end of the mode list, with the same
status line under the buttons (the reporter window is on the desktop page only).

Things to know:

- **Your visitors must be able to reach `mainServer`.** The installer fills in the
  public address from UberSDR's instance settings (for example a `…tunnel.ubersdr.org`
  address). Without one, the page uses port 8080 of the same host; forward that port too
  in that case.
- **`server.enable_cors: true`** must be set in UberSDR's `config.yaml`, because the page
  (port 8901) contacts another address. The installer warns if it is off.
- **Each RADE listener uses one more UberSDR session** and one FreeDV decoder
  (`freedv_extension.max_users` in `config.yaml`, 15 by default).
- The decoder reads the sideband when it starts, so switching between RADEL and RADEU
  restarts it. UberSDR allows one restart every 2 seconds; the page waits and retries.

### IQ and DRM

The **IQ** and **DRM** buttons in the Mode row work the same way as RADE (press the lit
button again, or another mode button, to switch off; the normal audio is silenced
meanwhile; each uses one more UberSDR session on `mainServer`).

- **IQ** plays the receiver's raw I/Q, ±6 kHz around the frequency (I left, Q right), from
  an IQ session on `mainServer`; **● Rec IQ** in the status line saves it as a stereo WAV
  file (up to 60 minutes) that HDSDR, SDR#, SDRuno and SDR++ open already tuned to its
  frequency. As in PhantomSDR-Plus, IQ is played untouched: Notch, NR, Hi-Boost and
  Left/Right do not apply to it. An **IQ Demodulators** window opens below, as in PhantomSDR-Plus: up to six
  receivers inside the 12 kHz around the dial, each with its own mode (USB, LSB, CW, AM,
  DSB, FM), frequency, width, volume and pan, and a level meter; click the spectrum to move
  the selected one there, or turn the wheel over it (Shift = 100 Hz). **Demodulators**
  plays them, **Raw I/Q** the I/Q itself; the settings are kept in the browser.
- **DRM** decodes Digital Radio Mondiale with UberSDR's DRM extension on such a session:
  tune to the centre of the channel (the filter shows the DRM channel's 10 kHz and keeps
  it while tuning); the status line shows the progress, station, MER and
  text. A **DRM schedule** window opens below, as in PhantomSDR-Plus: the DRM Reception
  Project's broadcasts this receiver can tune (PhantomSDR-Plus's saved copy), grouped as
  beamed at this station's locator, on air now (nearest first), later (next 24 h) and
  medium wave, with **Confirmed only** (confirmed on air or HFCC-registered) and
  **⇒ Tune**.

### CW decoder

While the mode is **CW** (the CW button, CW narrow or wide, a keyboard key or CAT
software), a window opens under the Mode buttons with the decoded text. The decoder is
the one from **PhantomSDR-Plus** (`sv1btl/cw-decoder.js`): it locks on the strongest
steady tone in the audio, finds the speed by itself and decodes even weak or fading
signals. It shows the tone it found (≈ Hz) and the speed in WPM; a line break marks a
pause or a new frequency. **Clear** empties the window. Choosing another mode closes it.

The **Pitch** slider, as in PhantomSDR-Plus, sets the tone a CW signal is heard at:
500–800 Hz in 50 Hz steps, **600 Hz** by default, kept in the listener's browser. Every
CW filter (CW, CW narrow, CW wide, the CW bandwidth presets) is centred on it with its
own width; moving the slider keeps you on the same signal and only changes its tone.

It runs in the listener's browser, on the audio the page receives (before squelch, NR
and the notch filters, so muting does not stop it). Nothing extra is asked of UberSDR:
no extra session, no `mainServer`, no `enable_cors`. Things to know:

- It decodes what passes the page's filter, so tune the signal into the passband (the
  yellow band). With several signals in a wide filter it takes the strongest; narrow
  the filter (CW narrow) to pick one.
- It needs a few seconds of a signal to lock on to its speed.
- The **Browser** box in the window (the **CW Browser**, as in PhantomSDR-Plus) decodes every CW signal between 200 and 3000 Hz at once, one line per station: frequency, speed, the callsign picked out (green with CQ) and the text, in a box of about 6 lines with its own scrollbar. Ghost lines (the keying sidebands a strong station makes beside itself) are left out. While it runs the receiver goes to USB 200–3000 Hz and the window stays open; your CW mode and filter come back when it is switched off. A click on a line puts that station in the middle of the CW passband with the normal decoder. **Save** writes the text (in the browser every line, also the stations that went quiet). In every browser (CW, PSK, Olivia / Contestia, RTTY, MFSK) the mouse wheel over a line moves the whole list; **Shift+wheel**, or the line's own scrollbar, scrolls back through that line's text, and nothing jumps while new text comes in.
- Desktop page only.

### Digital-mode decoders

A **Decoder** row under the Mode buttons starts one of PhantomSDR-Plus's decoders, in
the listener's browser: **FT8, FT4, FT2, JS8, WSPR, SSTV, FAX, NAVTEX, FLDIGI, SERVICES**.
**SERVICES** (the HFDL button before) has a Service list at the start of its window, in
PhantomSDR-Plus's order: HFDL, Maritime FSK / SITOR, Weather RTTY, Naval RTTY (PBB CARB), DSC, Time Signals, HF Selcall,
ALE 2G, AQC-ALE, FSK modes (SITOR-A, ARQ-E, ARQ-E3), STANAG 4285, MIL-STD-188-110A serial and 3G ALE;
the button reopens the last one. Picking a frequency in a SERVICES, FAX or NAVTEX list also centres the
waterfall on the signal at a medium zoom (about 59 kHz across), as in PhantomSDR-Plus. The FLDIGI window's list, also in PhantomSDR-Plus's
order, picks Amateur RTTY (or its Browser), PSK31·63·125 (BPSK/QPSK, or the PSK Browser), Olivia / Contestia (or
their Browser), FST4W, MFSK16·32·64 (or its Browser), MSK144, DominoEX, THOR, THROB, Hellschreiber, MT63,
ALE 2G HAM, Packet or APRS. Its window
opens above "Waterfall Settings". Pressing the lit button again, or choosing AM, FM, CW
or RADE, stops it; the page then returns to the band's usual mode (LSB on 40 m, CW on
30 m…; outside the amateur bands the sideband stays) with that mode's usual filter (or
the preset the listener chose for it). Tuning into another band while a decoder runs
keeps the decoder's own mode and filter. Only one runs at a time. Like the CW decoder they take the received
audio before squelch, NR and the notch filters, and nothing extra is asked of UberSDR.

While a decoder runs, the **Mode Filters' presets** on the left are replaced by
**Decoder Filters' presets**: one button per decoder with its filter width (FT8, FT4,
FT2 and JS8 2.90 kHz, WSPR 400 Hz, SSTV 1.50 kHz, FAX 1.60 kHz, NAVTEX 500 Hz; SERVICES by service: HFDL 2.60 kHz, Maritime FSK / SITOR 500 Hz, Weather RTTY 593 Hz, Naval RTTY 1.06 kHz, DSC, Selcall and time signals 600 Hz, ALE 2G and AQC-ALE 2.25 kHz, FSK modes 2.80 kHz, STANAG 4285, MIL-STD-188-110A and 3G ALE 3.30 kHz; FLDIGI
follows its list: RTTY 300 Hz, PSK 200, 400 or 800 Hz by speed, the other modes their
bandwidth plus a margin). A button sets that decoder's sideband and filter;
the one in use is lit. The Mode presets come back when the decoder stops.

| Decoder | What the button does | Window |
|---|---|---|
| FT8, FT4, FT2 | USB, filter 0.1–3.0 kHz; FT8/FT4 move to the band's usual frequency if the dial is not on one | UTC, dB, DT, Hz, message, locator and distance from your locator; 15 / 7.5 / 3.75 s slots. One line per decode: a long message ends with “…”, and a click on it shows it all (another click folds it) |
| JS8 | USB 0.1–3.0 kHz, the band's JS8 frequency | messages put together from JS8 frames; speed Normal/Fast/Turbo/Slow/Ultra |
| WSPR | USB 1.3–1.7 kHz, the band's WSPR frequency | spots every 2 minutes (even UTC minutes): call, locator, dBm, kHz, SNR, distance |
| SSTV | LSB below 10 MHz, USB above; 1.0–2.5 kHz | the picture (VIS auto-detect or a fixed mode), Save as PNG, a list of SSTV frequencies |
| FAX | USB 1.1–2.7 kHz | the weather chart, LPM/IOC, Invert, Save; the station list tunes 1.9 kHz below the published frequency, which the display shows |
| NAVTEX | USB 0.25–0.75 kHz | the messages (ZCZC … NNNN); list of NAVTEX stations and the ITU SITOR-B channels (2174.5, 4210 … 26100.5 kHz) |
| HFDL (SERVICES) | USB 0.15–2.75 kHz; the dial on the listed frequency (subcarrier at 1440 Hz) | aircraft messages (UTC, kHz, SNR, ground station, aircraft with a FlightAware link, type, ACARS text, 📍 position); ground stations and their frequencies with Tune; Squitters; Save. As in PhantomSDR-Plus, **🗺 Map** shows the aircraft that reported a position in the window and **⤢ Large map** in a large window you can drag and resize (⌖ Fit all, ✕ or Esc to close); positions are kept while the map is closed |
| Maritime FSK / SITOR (SERVICES) | USB 0.25–0.75 kHz; the dial 0.5 kHz below the signal | SITOR-B / NBDP maritime safety broadcasts (100 Bd, 170 Hz) as plain text, without NAVTEX's message framing; NAVTEX 518, 490 and 4209.5 kHz and the ITU HF SITOR channels (2174.5, 4210 … 26100.5 kHz), with the NAVTEX timetable of the channel |
| Weather RTTY (SERVICES) | USB around 1000 Hz, 593 Hz wide | DWD weather RTTY, 50 Bd / 450 Hz (DDH47 on 147.3 kHz LF: 85 Hz, set when picked): text, the DWD frequencies and the programme's schedule; **Squelch** slider in dB SNR (Off … +10, default −8) |
| Naval RTTY (SERVICES) | USB around 1000 Hz, 1.06 kHz wide | naval CARB RTTY (Channel Availability / Receipt Broadcast), as PBB of the Royal Netherlands Navy: NATO 75 Bd / 850 Hz, mark and space inverted; text, the 18 PBB frequencies; **Squelch** slider in dB SNR (Off … +10, default −7) |
| DSC (SERVICES) | USB 1.4–2.0 kHz; the dial 1.7 kHz below the DSC frequency | GMDSS calls (100 Bd FSK): time, frequency, category in colour (DISTRESS, URGENCY, SAFETY, ROUTINE), format, the decoded fields (who calls whom, telecommands, position with a 📍 map link), error check; S/N and tuning offset; the distress & safety, coast → ship and ship → coast frequencies with Tune; Save |
| Time Signals (SERVICES) | USB 0.7–1.3 kHz; the dial 1 kHz below the carrier | DCF77, MSF, RWM, WWV/WWVH with their frequencies: the decoded UTC time and date, the time in this station's own time zone (from its locator), when the minute mark arrived against your clock, DUT1; the seconds of the minute as a bar; Save. A full clean minute is needed first |
| HF Selcall (SERVICES) | USB 1.4–2.0 kHz; the dial 1.7 kHz below the channel | CCIR 493-4 Selcall calls (Codan, Barrett …) as DSC; the 7 and 8 MHz channels (KiwiSDR's list) |
| FLDIGI | USB, around the mode's audio centre | the window's list: Amateur RTTY, PSK31·63·125 (BPSK/QPSK), Olivia / Contestia, FST4W, MFSK16·32·64, MSK144, DominoEX, THOR, THROB / THROBX, Hellschreiber, MT63, ALE 2G HAM, Packet (AX.25), APRS (the FLDIGI button reopens the last one). Amateur RTTY: text, 45.45 Bd / 170 Hz, with the band frequencies; its **Browser** box decodes every RTTY signal of that shift and speed between 0.3 and 2.7 kHz at once, one line each, as in the PSK Browser (filter 0.2–2.8 kHz; a click on a line decodes that one); **Save**; **Squelch** slider in dB SNR (Off … +10, default −5) keeps noise from printing |
| PSK31·63·125 (FLDIGI list) | USB around 1000 Hz (the signal there): ±100 Hz at 31 Bd, ±200 Hz at 63, ±400 Hz at 125 | text; a **Mode** list: BPSK31, BPSK63, BPSK125, QPSK31, QPSK63, QPSK125 (must match the signal; QPSK with fldigi's error correction), or **PSK Browser**: every BPSK31 signal between 0.3 and 2.7 kHz on a line of its own (frequency, lock and the text in a box of about 6 lines that follows what comes in (Shift+wheel or its own scrollbar scrolls back; a click on the scrollbar does not pick the line); the number of signals above), a click on a line decodes that one; **Save** saves the text (in the browser one line per signal, also the ones that went quiet); calling frequencies; **Auto-tune** finds the strongest carrier within 0.3–2.7 kHz and moves it to 1000 Hz. A click on a PSK trace on the waterfall puts it in the filter. Its squelch is built in (it prints only once locked on a carrier), as in PhantomSDR-Plus |
| Olivia / Contestia (FLDIGI list) | USB around 1000 Hz, the signal bandwidth + 150 Hz each side | text; mode Olivia 8/250, 16/500, 32/1000 or 16/1000, or **Contestia** (the same modem with a smaller error-correction block, upper case only) 8/250, 4/125, 4/250, 4/500, 8/500, 8/1000, 16/500, 16/1000, 32/1000 or 64/1000 (must match the signal); the **Browser** box decodes every signal of that set-up between 0.3 and 2.7 kHz at once, one line each, as in the PSK Browser (filter 0.2–2.8 kHz; a click on a line decodes that one); **Save**; **Squelch** slider (FEC S/N 3–15, default 4); calling frequencies (they set the mode too). A click on a trace puts it in the filter |
| MFSK16·32·64, DominoEX, THOR, THROB / THROBX, MT63 (FLDIGI list) | USB around 1500 Hz (MT63: its lowest carrier at 500 Hz), the signal bandwidth plus a margin | text; a Mode list (speed or bandwidth, must match the signal: MFSK16/32/64, DominoEX Micro–88, THOR Micro–100, THROB/THROBX 1/2/4, MT63 500/1000/2000 short or long) and its own **Squelch** scale as in PhantomSDR-Plus (MFSK 0–60, default 22; DominoEX and THOR 0–80, default 25; THROB 0–20 dB, default 4; MT63 0–15, default 4; far left = off); **Auto-tune** finds the strongest signal within 0.3–2.7 kHz and moves the dial onto it — THROB must be within ±3 Hz. A click on a trace puts it in the filter. MFSK and MT63 text comes a few seconds behind the signal. MFSK16·32·64 has a **Browser** box too: every signal of that sub-mode between 0.3 and 2.7 kHz at once, one line each (filter 0.2–2.8 kHz; a click on a line decodes that one); **Save** |
| Hellschreiber (FLDIGI list) | USB around 1500 Hz | a picture of the received text, as on paper (no squelch, as fldigi); Feld Hell, Slow Hell, Hell X5/X9, FSK Hell 245/105, Hell 80; **Reverse** for FSK Hell sent the other way round; **Save** as PNG; Auto-tune |
| Packet (AX.25), APRS (FLDIGI list) | USB 1.3–2.1 kHz, tones 1600/1800 Hz | 300 Bd HF packet: every frame like a TNC monitor, or APRS decoded into plain text (positions, weather, messages…). Only frames with a correct checksum are printed. List: the 30 m HF APRS dial, 10147.6 kHz. 1200 Bd VHF packet needs FM above 30 MHz, which this receiver does not cover; there is no APRS map |
| ALE 2G HAM (FLDIGI list), ALE 2G (SERVICES) | USB 0.5–2.75 kHz (LSB for the few LSB networks); the dial on the channel | MIL-STD-188-141 link set-up: soundings, calls and links with who calls whom, commands and bit errors (repeats counted, not listed again); networks from KiwiSDR's list and their channels with Tune: ALE 2G HAM has the amateur (HFLINK) channels, SERVICES' ALE 2G the government, military, MARS and utility networks; Save |
| AQC-ALE (SERVICES) | USB 0.5–2.75 kHz; the dial on the listed frequency | the quick-call form of ALE 2G (MIL-STD-188-141B): calls, responses, links, soundings and inlink transactions with traffic type, noise report and link quality; plain ALE 2G calls too. Tune exactly: about 60 Hz off is not read |
| FSK modes (SERVICES) | USB 0.3–3.1 kHz; the dial on the listed frequency | SITOR-A, ARQ-E and ARQ-E3 teleprinter text; **System**, **Baud**, **Shift** and **Centre** in the window (remembered), polarity and character timing found automatically |
| STANAG 4285, MIL-STD-188-110A (SERVICES) | USB 0.15–3.45 kHz; the dial on the listed frequency | NATO / military 8-PSK data modems (2400 symbols/s on 1800 Hz): the rate and interleaver (4285 tries them all, 110A reads them from its preamble), text or hex, S/N, offset; most traffic is encrypted |
| 3G ALE (SERVICES) | USB 0.15–3.45 kHz; the dial on the listed frequency | MIL-STD-188-141B link set-up PDUs (BW0 bursts) with their fields, CRC-checked; addresses as numbers (group.member) |
| FST4W (FLDIGI list) | USB around 1500 Hz, ± the search width + 150 Hz | WSJT-X's LF/MF beacon mode: one decode per T/R period (120, 300, 900 or 1800 s, on the UTC clock) with a recording bar; UTC, dB, DT, MHz, message; F Tol ±50/100/150 Hz; the 136, 474.2 and 1836.6 kHz dials; Save as WSJT-X lists them |
| MSK144 (FLDIGI list) | USB around 1500 Hz, tones 1000/2000 Hz | WSJT-X's meteor-scatter mode: UTC, dB, T, MHz, message; F Tol, T/R period 15/30 s, Decode Fast/Normal/Deep. It lives on 6 m and 2 m, above this receiver; only 10 m (28.145 MHz) is listed |

- JS8 and WSPR show a bar under the window title: it fills over the
  current slot (teal while capturing, grey while waiting for the first slot) with the
  time to the next decode.
- FT8, FT4, FT2, JS8 and WSPR show a small **audio spectrum** under the title, as in
  PhantomSDR-Plus: the peak of each frequency over the slot being captured, with yellow
  marks where the last slot's spots were decoded (WSPR zoomed to 1390–1610 Hz).
- FAX, NAVTEX, Maritime FSK / SITOR and Weather RTTY show a **schedule** (UTC) of the
  station picked or tuned, as in PhantomSDR-Plus: the next charts of a FAX station, the NAVTEX stations of
  the channel with their letters, the items of the DWD programme. A transmission on the
  air stays at the top as **ON AIR**; amber 3 minutes before, red 30 s before.
- **Decoder ID**, the line under the Decoder buttons, as in PhantomSDR-Plus: switched
  **On**, it measures the signal in the passband (width, shift, speed, timing, SNR) for
  about 20 s and names the mode it is, with how sure it is and the runners-up; 📻 marks a
  known calling frequency of that mode. **Use …** starts that decoder; **Recentre &
  retry** moves a signal near the passband edge to 1500 Hz. Off by default (it costs CPU
  only while on); starting a decoder switches it off, retuning starts over.
- FT8, FT4, FT2 and JS8 start each capture a little after the UTC slot boundary, to
  allow for the time the audio takes to arrive. The page learns this "time shift" from
  the decoded DT values (shown in the window) and keeps it in the listener's browser.
  The listener's PC clock must be right (within about a second).
- While a decoder runs, the frequency display shows the **signal's** frequency, as in
  PhantomSDR-Plus: the dial plus the audio centre the decoder reads (FAX 1.9 kHz, NAVTEX
  and Maritime FSK / SITOR 0.5 kHz, RTTY 1.0 kHz, DSC and Selcall 1.7 kHz, time signals 1.0 kHz; PSK31, Olivia, the FLDIGI modems and Packet their centre). So
  NAVTEX on 518 kHz reads 518.00 with the dial on 517.50, and a frequency typed in while it
  runs is taken as the signal's. The dial frequency (shown when the decoder stops) is what
  the waterfall, memories, links and CAT use. FT8, FT4, FT2, JS8, WSPR and SSTV show the
  dial (WSPR 14095.6). Without a decoder the page shows the middle of a filter narrower
  than 1.4 kHz, as in CW.
- A running decoder keeps its own mode and filter: neither the band's usual mode (CW on
  30 m) nor a typed frequency changes them.
- The distance column needs the station locator in `station.js` (`locator`).
- The decoder files are in `sv1btl/psdr/` (PhantomSDR-Plus's own files, as of
  2026-11-06: WSPR decodes in up to three passes, taking out each decoded station so
  weaker ones under it show up; SSTV keeps drawing weak pictures and no longer mistakes
  Robot 36 for Robot 72; NAVTEX holds weak signals much better; MFSK finds a signal up to
  75 Hz off the dial; DominoEX and Olivia print less noise after a transmission ends; PSK63, PSK125, QPSK and
  Contestia added; then ALE 2G, FST4W, MSK144, the PSK Browser, DSC, time signals and
  HF Selcall, and the Olivia / Contestia Browser; 2026-11-08: the FLDIGI and SERVICES lists
  in PhantomSDR-Plus's order, Weather RTTY and Maritime FSK / SITOR in SERVICES, ALE 2G split
  into ALE 2G HAM and the other networks; 2026-11-14: the RTTY and MFSK Browsers, Naval RTTY
  (PBB CARB) in SERVICES; 2026-11-21: AQC-ALE, the FSK modes SITOR-A / ARQ-E / ARQ-E3, STANAG 4285,
  MIL-STD-188-110A and 3G ALE in SERVICES, in `psdr/krypto500/`) and `sv1btl/decoders.js` (the buttons and windows). The JS8 dictionary (1.9 MB) is only
  downloaded when JS8 is used.
- Desktop page only.

### SNR, dBm, dBµV and NF readouts

- The readouts sit in a row over the S-meter, in PhantomSDR-Plus's order, each in its own
  fixed cell and colour: **dBm** cyan, **dBµV** green, **SNR** yellow, **NF** red; the
  numbers themselves are a very light grey. The MUTED, SQL, ANF1, ANF2, NR and AGC lights
  are in a row under the S-meter scale (lit: MUTED red, SQL orange, the others green), with
  a fixed place at its right end that shows the digital mode in use in bold yellow (FT8, JS8, WSPR,
  SSTV, FAX, NAVTEX, the FLDIGI mode such as RTTY or PSK31, or RADE) and stays empty
  otherwise.
- **SNR** is measured on the waterfall, the way PhantomSDR-Plus does it: the noise is the
  quietest 3 kHz stretch of the visible span (the median of each stretch, the passband
  left out), rescanned every second; the signal is the strongest point in the passband;
  SNR is the difference in dB, never below 0, smoothed a little. A steady carrier (AM) no
  longer reads 0 dB, and pauses in speech are not needed. After a band change or zoom it
  takes a second or two to settle.
- **dBm** is the current S-meter reading, with the per-band S-meter offsets of
  `websdr-base.js` applied.
- **dBµV** is dBm + 107 (into 50 Ω).
- **NF** is the noise floor in dBm: dBm minus SNR, so it always agrees with the SNR figure.
- A readout shows `--` while there is nothing to show (no signal reading yet; NF also
  until the first SNR measurement). Unlike PhantomSDR-Plus, there is no extra +5 dB
  display offset: the figures follow this receiver's S-meter calibration.
- The grey noise marker on the S-meter bar still works the original way (the lowest
  reading over a few seconds), so it can differ from NF.
- The SNR measurement is in `sv1btl/ubersdr-compat.js` (`snrUpdate`); the readouts are
  filled in by `websdr-base.js`. Desktop page only.

### Frequency keypad

A click anywhere in the black frame with the frequency display, the magic eye and the
S-meter opens a number pad over the page, so a frequency can be entered with the mouse or a
finger as well as the keyboard.

- The pad has the keys **0–9**, a decimal point **.**, **⌫** (delete the last digit),
  **Clear**, **Cancel** and **Enter**. The number is shown in the display at its top.
- Type the frequency in **kHz**, as in the frequency field: `7074`, `14074.5`, `198`. Only
  digits and one decimal point are accepted (up to 9 digits); a number starting with the
  point gets a `0` in front.
- **Enter** tunes there and closes the pad; the mode follows the band plan, as when the
  frequency is typed in the frequency field (LSB on 40 m, USB on 20 m…). An empty entry or
  0 is ignored. **Cancel**, a click outside the pad or **Esc** closes it without tuning.
- The computer keyboard works while the pad is open: digits (also the numeric keypad), `.`
  or `,`, Backspace, Delete (clear), Enter and Esc. The page's one-key shortcuts (M for
  mute, arrows for tuning…) are off until it closes. On a phone or tablet the pad does not
  bring up the on-screen keyboard.
- **Digit tuning stays as it was:** the mouse wheel over a digit, a left click on a digit
  (up) and a right click (down) step that digit and do not open the pad. A click beside
  the digits opens the pad (it used to put a typing cursor in the frequency field). The
  `G` key still empties the frequency field for typing.
- The pad is at the end of `websdr-controls.html` (`#freqpad`, functions
  `sv1btl_freqpopup_open` and `sv1btl_freqpad_key`); the frame that opens it is
  `#radiodisplay`. It is dark in both themes, with the dark theme's blue on Enter.
  Desktop page only.

### Receive Diversity

Combine this receiver with a **second receiver somewhere else** and listen to whichever of
the two has the better signal at the moment, as PhantomSDR-Plus does. When one site is in
a fade, the other usually is not, so you keep copy through it; two sites also have
different local noise. It is **selection**, with a 30 ms crossfade at each switch, not a
sum of the two signals: two distant receivers hear the station over different paths, with
unrelated phase. So it buys continuity, not a stronger signal.

- The **Receive Diversity** panel is in the middle column, just above the "Switch to
  another WebSDR" links, collapsed. Click it to open it, choose what the second receiver
  is, type its address and press **Start**: an **UberSDR** by its normal web address
  (`sdr.example.org`, not port 8073), a **KiwiSDR** as `host:8073`, a **PhantomSDR+** as
  `host:8900`, a **WebSDR** as `host:8901` (through this station's relay, see below).
  Nothing has to be set up on the other receiver.
- Tune as usual: the second receiver **follows** the frequency, mode and filter by itself.
- You listen **1–3 seconds behind real time**, because the earlier stream is delayed to
  match the later one. Lining the two streams up takes about 15–30 seconds of signal;
  meanwhile they are paired by arrival and the better one is already chosen (*Ready
  (unaligned)*). Both receivers must hear the station: on a band with only noise at both
  ends they never line up, and should not.
- The word beside the title: *off*, *Please wait…* (amber: connecting or still aligning),
  *Ready* (green), or the error (red). The dot shows which site you hear: green this
  receiver, cyan the second one. The table shows the link, the measured delay
  (*aligned*), the correlation, the remote audio arriving, both SNR figures and the
  number of switches.
- **Remote SNR trim** (−15 … +15 dB) is added to the second receiver's SNR before the two
  are compared: + favours it, − this one. +15 and −15 force one site, to hear it alone.
  Start at 0; a KiwiSDR may want a few dB +. If it flips back and forth constantly, move
  the trim a little.
- **☰** keeps every receiver used, per type, in the visitor's browser: give one a name,
  edit it, drag it up or down (or use ▲▼) to change the order, remove it, open its own page (🌍), and export or import all
  the lists as a file.
- The CW and digital decoders keep using **this** receiver (a switch in the middle of a
  slot would spoil a decode); diversity feeds the speaker only. RADE also uses this
  receiver.
- **Weak-signal AGC** is switched off when you press Start and back on when you press
  Stop.
- A session uses one listener slot on the other receiver for as long as it runs; please
  be considerate with volunteers' receivers.
- The panel is `sv1btl/diversity-ui.js`; the combiner and the receiver connections are
  PhantomSDR-Plus's own files in `sv1btl/psdr/` (`diversity.js`, `uberSource.js`,
  `kiwiSource.js`, `remoteSource.js`, `webSdrSource.js`, `webSdrCodec.js`,
  `diversityList.js`), with PhantomSDR-Plus's audio module
  (`psdr/modules/phantomsdrdsp_bg.*`) for FLAC from a PhantomSDR+.
- On the **mobile page** it is a section of its own, **Receive Diversity:**, just under the
  RADE status line (above Memories): tap it to open it. Type, address, Start/Stop, the
  trim, the status table and the saved receivers (tap one to use it, 🌍 its own page, ✕
  remove, export and import) work as on the desktop; naming and reordering are on the
  desktop page. The saved list is kept per browser, so a phone starts empty: export it on
  the desktop and import the file on the phone.

#### The WebSDR relay (for example port 8902)

A classic WebSDR (PA3FWM's software) accepts its audio only from its own page, and a
browser cannot pretend otherwise. So the connection goes through a small relay program on
this server, PhantomSDR-Plus's `websdr_relay.py`, in `websdr_sv1btl/relay/`, run as a
Docker container on a port of its own. Listeners' browsers connect to it directly, on that
port of the same address as the page.

**`install.sh` offers to set it up** (answer **y**). It asks for:

- your **callsign** (an e-mail address too, if you like) and your page's **public
  address** (offered from UberSDR's own settings). Both are sent to each WebSDR as the
  relay's User-Agent, so its operator knows who is connecting;
- the **port** for the relay: press Enter for **8902**, or type another free one
  (1024–65535, not the WebSDR port). The installer writes it into
  `relay/websdr_relay.json` and into `station.js` (`diversityRelayPort`), so the page
  finds the relay there.

It then builds and starts the container (it starts again by itself after a reboot) and
checks that it answers. On an upgrade the relay's settings are kept and the container is
restarted with the new files.

> **The relay's port (e.g. 8902) must be forwarded (opened) on your router** to the
> UberSDR machine, TCP, just like 8901. Without it, WebSDR diversity works only inside
> your own network. UberSDR, KiwiSDR and PhantomSDR+ partners do not need it. Check it
> with `http://<your-address>:8902/status` from outside your network (a phone on mobile
> data).

**By hand** instead (port 8902 in this example): set `"site"`, `"operator"` and `"port"` in
`websdr_sv1btl/relay/websdr_relay.json`, then

```
docker build -t websdr-relay ~/ubersdr/websdr_sv1btl/relay
docker run -d --name websdr_relay --restart unless-stopped -p 8902:8902 \
  -v ~/ubersdr/websdr_sv1btl/relay:/app:ro websdr-relay
```

For another port, use it in both `-p` numbers and in `diversityRelayPort` in `station.js`.
After editing the settings: `docker restart websdr_relay`.

The relay allows 10 sessions to any one WebSDR and 60 in all, passes on only tuning
commands, and refuses private addresses. The other WebSDR's user list shows the session as
"<callsign> diversity". WebSDR operators added the Origin check on purpose: keep the
limits and stop if an operator asks. `uninstall.sh` offers to remove the relay container.

### 3D spectrum

The **3D** switch next to "Tube & Waterfall & DSP & Audio" shows the spectrum in relief, as
in PhantomSDR-Plus: frequency across, the last 320 lines going back into the screen, level
as height. It takes the place and size of the 2D spectrum (with Type = waterfall, switching
it on sets Type to spectrum + waterfall). It shows exactly what the waterfall shows: the
same levels in the same colours, through the waterfall's brightness and contrast, so Auto
brightness (or the sliders) changes the waterfall and the whole 3D picture alike. dBFS
marks on the right, seconds back on the left; ⚙ sets angle and depth. With spectrum +
waterfall, hovering shows the frequency and a click tunes there (on an older line: that
line's frequency). It needs WebGL2; the choice is kept in the visitor's browser.

**Auto brightness** reacts at once after a page load, zoom or band change (first setting
after one new line, then with every line for the first twelve), then calmly: a check every
4 s with small, eased steps.

### Page size, look and dark theme

- **Fits the window.** The desktop page is scaled to 90% of the width of the browser
  window, centred (0.5× to 3×; `FIT_SHARE` in `ubersdr-compat.js`), so it suits a 1024 px
  laptop screen as well as a Full HD, 2K or 4K monitor, and follows when the window is resized. Clicks, drags, the mouse wheel and
  the frequency digits stay exact. Add `?nofit` to the address for the old fixed size.
- **Dark theme.** The **Light GUI / Dark GUI** switch next to Auto brightness turns dark: the page
  header, the WebSDR Information panel, the Waterfall / Keyboard Control / Background
  image boxes, the control panel (buttons, lists, switches, sliders), the RADE, CW and
  decoder windows, the signal strength plot, the users bar and the chat box. The radio
  display with the S-meter and the waterfall stay as they are. Off (the original light
  look) is the default; each visitor's choice is kept in their browser.
- **Colours.** Light theme: the original teal for selected buttons, switches, radio
  buttons and sliders. Dark theme: blue (`#3a6db5`) for all of them. Without the
  background image the page background is very dark blue (`#0a1a3a`). Links are blue
  (`#0645ad`) in the light theme and keep their light blue in the dark theme; in both they
  turn red under the mouse (the cyan links at the bottom of the page keep their colour).
- **Sliders and on/off switches** have the same small 3D knob, in both themes (in the dark theme with a deeper shadow and a light edge so it stands out); slider tracks and switch grooves look slightly sunken. In the dark theme the "Switch to" buttons for other WebSDRs are raised grey buttons too, like the other dark buttons.
- Desktop page only; the mobile page keeps its own look.

### What listeners' browsers contact

- Your UberSDR (port 8901): the page, audio and waterfall.
- Your UberSDR's main web server (`mainServer`), only while RADE, IQ or DRM is on.
- `tile.openstreetmap.org` (map tiles), only while the HFDL map is open.
- The second receiver chosen in Receive Diversity, only while that runs (for a WebSDR,
  this station's relay on port 8902 instead).
- `get.geojs.io`, or `ipwho.is` as a fallback, once a day per visitor. This finds the
  visitor's own country and city for the users list. Nothing is sent to it except the
  normal web request. To switch it off, see section 12.

## 7. After an UberSDR update

UberSDR's updater only *adds* missing services to `docker-compose.yml` and never changes
the `ubersdr` service, so the mount lines stay. After each update, run:

```bash
bash ~/ubersdr/websdr_sv1btl/check-after-update.sh
```

- **Every line says OK:** everything is in place.
- **A FAIL line:** it says what is wrong. The usual case is missing mount lines; the
  line to copy is in `compose-mounts.txt` in the package. The other is
  "`websdr-sound.js` changed shape", meaning a new UberSDR version renamed something the
  audio extras rely on. The page still plays; please report it at
  https://github.com/sv1btl/WebSDR-emulation-for-UberSDR/issues.

If your UberSDR is not in `~/ubersdr`, or the container has another name:

```bash
UBERSDR_DIR=/path/to/ubersdr CONTAINER=my_container URL=http://localhost:8901 \
  bash /path/to/ubersdr/websdr_sv1btl/check-after-update.sh
```

## 8. Upgrading to a newer package

Get the new version and run its `install.sh` again:

```bash
cd WebSDR-emulation-for-UberSDR   # the folder you cloned
git pull
bash install.sh
```

(Without git, download and unpack the new ZIP or release archive, and run its
`install.sh`.) The installer:

- saves the whole current folder as `websdr_sv1btl.bak.<date>`;
- writes the new files **in place**, so they are live at once with no restart;
- **keeps your `station.js` and `stationinfo.txt`**, and adds to your `station.js` any
  settings that are new in this version (with their explanation and default value; your
  own values are not changed). It lists the settings it added.

If `git pull` stops with *"Your local changes to the following files would be
overwritten by merge"* (for example `websdr_sv1btl/websdr-controls.html`), you have
edited files in the cloned folder. Set your edits aside, update, and put them back:

```bash
git stash && git pull && git stash pop
```

If `stash pop` reports a conflict, open the file, keep the lines you need, and delete
the `<<<<<<<` / `=======` / `>>>>>>>` markers. To discard your edits instead, run
`git checkout -- <file>` before `git pull`.

## 9. Uninstalling

```bash
bash uninstall.sh                  # or: bash uninstall.sh /path/to/ubersdr
```

This removes the 6 mount lines (the old file is kept as `docker-compose.yml.bak.<date>`)
and, after asking, recreates the container. UberSDR's own WebSDR page is back. It also
offers to remove the WebSDR relay container, if there is one.
`~/ubersdr/websdr_sv1btl/` stays; delete it by hand if you want.

## 10. Manual installation (without install.sh)

1. Copy the `websdr_sv1btl` folder next to `docker-compose.yml`, for example to
   `~/ubersdr/websdr_sv1btl`.
2. In `docker-compose.yml`, under `services:` → `ubersdr:` → `volumes:`, add the 6
   lines from `compose-mounts.txt`, indented like the lines already there.
3. Set `waterfallCalibration` in `sv1btl/station.js` to the value of
   `websdr_waterfall_calibration` in UberSDR's config:

   ```bash
   docker exec ka9q_ubersdr grep websdr_waterfall_calibration /app/config/config.yaml
   ```

4. Apply it with `cd ~/ubersdr && docker compose up -d ubersdr`.
5. Check it with `bash ~/ubersdr/websdr_sv1btl/check-after-update.sh`.

## 11. Troubleshooting

| Problem | Cause and fix |
|---|---|
| Port 8901 shows UberSDR's own page, not this layout | The mounts aren't active: run `docker compose up -d ubersdr` in the UberSDR folder, then the check script. |
| The check says "http://localhost:… does not answer" (older versions: many FAIL lines with `HTTP 000`) | UberSDR was still starting, the WebSDR server is off, or the port is published under another number. Wait a minute and run the check again; see `docker port ka9q_ubersdr`; for another port run `URL=http://localhost:<port> bash ~/ubersdr/websdr_sv1btl/check-after-update.sh`. The installation itself is fine if sections 1 and 2 say OK. |
| Port 8901 doesn't answer at all | `enable_websdr` is off, or the port isn't published/forwarded. Check `config.yaml` and the `ports:` of the `ubersdr` service (`8901:8901`). |
| Red "Station settings not loaded" line | A typo in `station.js` (section 3). |
| The header still says "N0CALL / Your City" | `station.js` wasn't edited, or the browser cached the old one: press Ctrl+F5. |
| An edit to an HTML file doesn't show | The file was *replaced*, not saved in place (section 6): run `docker restart ka9q_ubersdr`. |
| The spectrum's dB numbers look wrong | `waterfallCalibration` in `station.js` doesn't match `websdr_waterfall_calibration` in `config.yaml`. |
| No sound until clicking | Browsers need one click before playing audio; the page shows a "start audio" button. The header links a guide for allowing autoplay. |
| With the Dark Reader browser extension, the passband shade over the waterfall or the S-meter looks dark and solid | Dark Reader recolours their colour gradients. The pages carry `<meta name="darkreader-lock">` in `websdr-head.html` and `m.html`, which makes Dark Reader leave them alone. If you still see it, the listener should reload the page; check that the line wasn't lost after editing those files. |
| Phones don't get the mobile page | Open `/m.html?mobile` once; that clears a saved "desktop version" choice. |
| Audio or extras stopped after an UberSDR update | Run the check script (section 7). |
| RADE says "RADE unavailable: cannot reach …" | `mainServer` in `station.js` is wrong or not reachable from outside, or `server.enable_cors` is off (section 6). |
| RADE stays on "waiting for a RADE signal…" | Nobody is transmitting RADE there right now. Common RADE frequencies: 7177 kHz LSB, 14236 kHz USB. |
| A "PhantomSDR-Plus — installation report" says `Subproject exists but has no meson.build file` | That report comes from the installer of **PhantomSDR-Plus** (`/opt/PhantomSDR-Plus/install.sh`), a separate WebSDR server. websdr_sv1btl doesn't need it: this package installs no PhantomSDR-Plus and compiles nothing, so the error can be ignored (and `/opt/PhantomSDR-Plus` deleted). If you do run PhantomSDR-Plus, download its fixed `install.sh` from [github.com/sv1btl/PhantomSDR-Plus](https://github.com/sv1btl/PhantomSDR-Plus) and run it again. |
| `install.sh` says `cat: …/websdr-controls.html: No such file or directory` and `ERROR: cannot write …`, or "the package is incomplete" | A file is missing from your copy of the package (`git status` shows it as "deleted"). Installers older than 2026-11-23 then left that file empty on the live page. Restore the package with `git checkout -- websdr_sv1btl && git pull` (or download it again) and run `bash install.sh` again. Each run saves a backup; only the first one holds the old file. |
| Something else | Open the page with `?ubersdr_debug` at the end of the address (`http://…:8901/?ubersdr_debug`). Script errors then appear in a red panel at the bottom; please include them in a report at [github.com/sv1btl/WebSDR-emulation-for-UberSDR/issues](https://github.com/sv1btl/WebSDR-emulation-for-UberSDR/issues). |

## 12. Settings for advanced users

These constants are near the top of their sections in `sv1btl/ubersdr-compat.js`. After
editing, raise the `?v=` number (see section 6).

| Constant | Default | Meaning |
|---|---|---|
| `WAGC_TARGET_DB`, `WAGC_MAX_DB`, `WAGC_NOISE_MAX_DB` | −9, 20, 3 | Weak-signal AGC: target peak level (dBFS), most boost with a signal, most boost on an empty channel |
| `WAGC_PROFILE` | SSB 0.4 / 0.75, AM 1 / 1 | Weak-signal AGC hang (s, only after a sudden jump) and release time constant (s), as the PhantomSDR-Plus Auto AGC; attack is immediate, level = peak of the last 100 ms |
| `NR_MULT`, `NR_FLOOR` | per level | noise-reduction strength, and how far noise is turned down: −9/−14/−18/−23 dB for Low/Medium/High/Strong |
| `SQL_OPEN_DB`, `SQL_CLOSE_DB`, `SQL_HANG_S` | 8, 4, 0.6 | squelch: opens this many dB above the noise |
| `LIM_CEIL`, `LIM_KNEE` | 0.7, 0.8 | soft limiter |
| `WF_NOISE_T`, `WF_SIG_T`, `WF_GRAIN_MAX` | 0.15, 0.74, 0.20 | auto brightness: where the noise floor and strong signals sit in the colour scale (full 0–30 MHz view: noise 0.15, speckle limit 0.28; with `WF_SIG_W` 1.25 = how hard it pushes signals brighter, `WF_C_MAX` 3.5 = most contrast; the colour table is PhantomSDR-Plus's “PhantomSDR” map, so the background is dark navy) |
| `WFTYPE_DEFAULT` | `'2'` | first-visit waterfall type: 0 spectrum, 1 waterfall, 2 spectrum + waterfall |
| `GEO_SERVICES` | geojs.io, ipwho.is | location lookup; set it to `[]` to switch the location in the users list off |
| `SPEC_RANGE_DB` | 70 | spectrum height in dB |

## 13. Credits and licences

- **WebSDR** client pages and scripts (`websdr-base.js`, the mobile page), © 2007–2014
  Pieter-Tjerk de Boer, PA3FWM — [websdr.org](http://www.websdr.org). They are served by
  UberSDR's WebSDR emulation, as they are on every WebSDR.
- **RW3PS**'s WebSDR template: layout, styles and the waterfall colour map.
- **UberSDR** by madpsy — [github.com/madpsy/ka9q_ubersdr](https://github.com/madpsy/ka9q_ubersdr).
- **websdr-nr.js** noise reduction © 2026 joshuah.rainstar@gmail.com. MIT terms, with a
  caveat in its header about **commercial use**; read the header before using it on a
  paid service. SV1BTL added a residual floor (`setFloor`).
- **jQuery 3.1.1** (MIT), **Less.js 3.12** (Apache 2.0), **Roboto Condensed** font
  (Apache 2.0).
- **DS-Digital** font (`sv1btl/DS-DIGII.TTF`, the frequency display) © Dusit Supasawat,
  "All Rights Reserved". It is usually free for personal use only. If that is a concern
  for your station, replace it with another digital-style font of the same file name.
- The **spectrum** is drawn after the style of PhantomSDR-Plus.
- **sv1btl/cw-decoder.js**, the CW decoder, comes from PhantomSDR-Plus
  ([github.com/sv1btl/PhantomSDR-Plus](https://github.com/sv1btl/PhantomSDR-Plus)) and is
  under its licence, the **GNU GPL v3**.
- The **digital-mode decoders** in `sv1btl/psdr/` come from PhantomSDR-Plus too, and with
  `sv1btl/decoders.js` are under the **GNU GPL v3**. The FT8/FT4/FT2 engine
  (`ft8_lib.wasm`, from Karlis Goba's ft8_lib, MIT) and the JS8 engine and dictionary
  (`js8.wasm`, built on ft8_lib with tables from JS8Call, and `js8_dict.bin`, from
  JS8Call, GPL v3) keep their own terms. The HFDL engine (`hfdl.wasm`: dumphfdl by Tomasz
  Lemiech, with libacars, GPL v3 or later) and the zstd inflater `sv1btl/fzstd.js` (fzstd
  by Arjun Barrett, MIT, as UberSDR uses it) keep theirs too.
- **SERVICES** and the newer FLDIGI modes are PhantomSDR-Plus's too (GPL v3): DSC and HF
  Selcall, time signals, ALE 2G (a port of gr-ale as carried in KiwiSDR's ALE_2G
  extension, GPL v3, with its network list), FST4W and MSK144 (ports of the WSJT-X
  decoders, GPL v3), and AQC-ALE, SITOR-A / ARQ-E / ARQ-E3, STANAG 4285, MIL-STD-188-110A and 3G ALE
  (PhantomSDR-Plus's own implementations from the published standards, `psdr/krypto500/` and
  `psdr/ale.js`); the time-zone table `tzLookup.js` (tz-lookup, CC0).
- The **HFDL map**: PhantomSDR-Plus's `aprsMap.js` (GPL v3) with **Leaflet 1.9.4**
  (BSD-2-Clause, the copy UberSDR ships) in `sv1btl/psdr/lib/`; map tiles © OpenStreetMap
  contributors. The **IQ demodulators** (`iqDemod.js`) and the **DRM schedule**
  (`drmSchedule.js`) in `sv1btl/psdr/lib/` are PhantomSDR-Plus's too (GPL v3).
- **Receive Diversity**: the combiner, the receiver connections and the audio module in
  `sv1btl/psdr/` and the WebSDR relay (`relay/websdr_relay.py`) come from PhantomSDR-Plus
  and, with `sv1btl/diversity-ui.js`, are under the **GNU GPL v3**.
- Adaptation to UberSDR, the audio tools, spectrum, tuning features, installer and this
  guide: **SV1BTL** (2026).

SV1BTL's own work in this package is released under the **MIT licence** (see `LICENSE`).
The third-party parts listed above keep their own terms; `LICENSE` lists them too.

Questions and problem reports: https://github.com/sv1btl/WebSDR-emulation-for-UberSDR/issues
